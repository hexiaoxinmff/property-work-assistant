import { describe, it, expect, vi, beforeEach } from 'vitest';
import { runInstallFromLock } from '../src/install.ts';
import * as localLock from '../src/local-lock.ts';
import * as add from '../src/add.ts';

vi.mock('../src/local-lock.ts');
vi.mock('../src/add.ts');
vi.mock('../src/sync.ts', () => ({
  runSync: vi.fn(),
  parseSyncOptions: vi.fn().mockReturnValue({ options: {} }),
}));
vi.mock('../src/agents.ts', async (importOriginal) => ({
  ...(await importOriginal<typeof import('../src/agents.ts')>()),
  agents: { cursor: { displayName: 'Cursor', skillsDir: '.agents/skills' } },
  detectInstalledAgents: vi.fn().mockResolvedValue([]),
  getUniversalAgents: vi.fn().mockReturnValue(['cursor']),
  isUniversalAgent: vi.fn().mockReturnValue(true),
}));
vi.mock('../src/skill-lock.ts', () => ({
  getLastSelectedAgents: vi.fn().mockResolvedValue(undefined),
}));
// The suite itself runs in CI, where --frozen-lockfile would otherwise default on
vi.mock('../src/ci.ts', () => ({ isCI: () => false }));

describe('runInstallFromLock', () => {
  beforeEach(() => {
    vi.clearAllMocks();
    vi.mocked(add.fetchSources).mockImplementation(async (requests) =>
      requests.map(({ parsed }) => ({ parsed, resolved: null, error: 'not fetched' }))
    );
    vi.mocked(add.installFromSource).mockResolvedValue({ installed: ['skill-a'], failed: [] });
  });

  it('restores self-hosted GitLab project locks from sourceUrl', async () => {
    vi.mocked(localLock.readLocalLock).mockResolvedValue({
      version: 1,
      skills: {
        'skill-a': {
          source: 'acme/skills',
          sourceUrl: 'https://gitlab.example.com/acme/skills.git',
          sourceType: 'git',
          skillPath: 'skills/skill-a/SKILL.md',
          computedHash: 'hash',
        },
      },
    });

    await runInstallFromLock([]);

    expect(add.installFromSource).toHaveBeenCalledWith(
      expect.objectContaining({
        parsed: expect.objectContaining({ url: 'https://gitlab.example.com/acme/skills.git' }),
      }),
      { skills: ['skill-a'], agents: ['cursor'] }
    );
  });

  it('does not restore generic git shorthands as GitHub without sourceUrl', async () => {
    vi.mocked(localLock.readLocalLock).mockResolvedValue({
      version: 1,
      skills: {
        'skill-a': {
          source: 'acme/skills',
          sourceType: 'git',
          skillPath: 'skills/skill-a/SKILL.md',
          computedHash: 'hash',
        },
      },
    });

    await runInstallFromLock([]);

    expect(add.installFromSource).not.toHaveBeenCalled();
  });
});
