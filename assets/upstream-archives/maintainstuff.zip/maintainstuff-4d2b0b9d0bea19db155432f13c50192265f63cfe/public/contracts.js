export const ALL_ROLES = Object.freeze([
  "Maintenance manager",
  "Planner",
  "Technician",
  "Storeroom",
  "Administrator"
]);

const allCollections = Object.freeze(["assets", "workOrders", "preventiveSchedules", "inspections", "parts", "meterReadings"]);
const allActions = Object.freeze([
  "mark-asset-down", "return-asset-service", "approve-work-order", "schedule-work-order",
  "start-work-order", "hold-work-order", "complete-work-order", "cancel-work-order",
  "issue-part-to-work", "generate-pm-work", "pause-pm", "resume-pm",
  "raise-inspection-follow-up", "restock-part", "issue-part", "apply-meter-reading"
]);

const roleMatrix = Object.freeze({
  "Maintenance manager": fullAccess(),
  Administrator: fullAccess(),
  Planner: Object.freeze({
    workspace: true,
    fullData: false,
    create: ["assets", "workOrders", "preventiveSchedules"],
    edit: ["assets", "workOrders", "preventiveSchedules"],
    lifecycle: ["assets", "workOrders", "preventiveSchedules"],
    export: allCollections,
    actions: [
      "mark-asset-down", "return-asset-service", "approve-work-order", "schedule-work-order",
      "cancel-work-order", "generate-pm-work", "pause-pm", "resume-pm"
    ]
  }),
  Technician: Object.freeze({
    workspace: false,
    fullData: false,
    create: ["inspections", "meterReadings"],
    edit: ["inspections", "meterReadings"],
    lifecycle: [],
    export: ["workOrders", "inspections", "meterReadings"],
    actions: ["start-work-order", "hold-work-order", "complete-work-order", "issue-part-to-work", "raise-inspection-follow-up", "apply-meter-reading"]
  }),
  Storeroom: Object.freeze({
    workspace: false,
    fullData: false,
    create: ["parts"],
    edit: ["parts"],
    lifecycle: ["parts"],
    export: ["parts"],
    actions: ["restock-part", "issue-part", "issue-part-to-work"]
  })
});

export function roleCan(role, capability) {
  return Boolean(roleMatrix[role]?.[capability]);
}

export function roleCanCollection(role, capability, collectionKey) {
  return Boolean(roleMatrix[role]?.[capability]?.includes(collectionKey));
}

export function roleCanAction(role, actionKey) {
  return Boolean(roleMatrix[role]?.actions?.includes(actionKey));
}

export function rolesFor(capability) {
  return ALL_ROLES.filter((role) => roleCan(role, capability));
}

export function rolesForCollection(capability, collectionKey) {
  return ALL_ROLES.filter((role) => roleCanCollection(role, capability, collectionKey));
}

export function rolesForAction(actionKey) {
  return ALL_ROLES.filter((role) => roleCanAction(role, actionKey));
}

export function recordSearchText(data, collections, row) {
  const references = new Set(Object.values(row || {}).flatMap((value) => Array.isArray(value) ? value : [value]));
  const related = [];
  for (const collection of collections || []) {
    const match = (data?.[collection.key] || []).find((item) => references.has(item.id));
    if (match) related.push(relationLabel(collection, match));
  }
  return `${JSON.stringify(row)} ${related.join(" ")}`;
}

export function compareFieldValues(left, right, field) {
  const ranks = {
    criticality: { Low: 1, Medium: 2, High: 3, Critical: 4 },
    priority: { Low: 1, Medium: 2, High: 3, Emergency: 4 }
  }[field];
  if (ranks) return (ranks[left] || 0) - (ranks[right] || 0);
  if (typeof left === "number" || typeof right === "number") return Number(left || 0) - Number(right || 0);
  return String(left ?? "").localeCompare(String(right ?? ""), undefined, { numeric: true, sensitivity: "base" });
}

export function compareRecords(left, right, field, direction = "asc") {
  const multiplier = direction === "desc" ? -1 : 1;
  return compareFieldValues(left?.[field], right?.[field], field) * multiplier
    || compareFieldValues(left?.id, right?.id, "id");
}

export function compareMeterRecords(left, right) {
  return String(left?.readingDate || "").localeCompare(String(right?.readingDate || ""))
    || String(left?.createdAt || "").localeCompare(String(right?.createdAt || ""))
    || String(left?.id || "").localeCompare(String(right?.id || ""));
}

function fullAccess() {
  return Object.freeze({
    workspace: true,
    fullData: true,
    create: allCollections,
    edit: allCollections,
    lifecycle: allCollections,
    export: allCollections,
    actions: allActions
  });
}

function relationLabel(collection, row) {
  if (row.number) return `${row.number} · ${row[collection.displayField]}`;
  if (row.assetTag) return `${row.assetTag} · ${row[collection.displayField]}`;
  if (row.sku) return `${row.sku} · ${row[collection.displayField]}`;
  return row[collection.displayField] || row.id;
}
