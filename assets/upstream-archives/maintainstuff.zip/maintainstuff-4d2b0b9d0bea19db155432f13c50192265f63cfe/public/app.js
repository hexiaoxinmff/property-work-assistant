import {
  compareMeterRecords,
  compareRecords,
  recordSearchText,
  roleCan,
  roleCanAction,
  roleCanCollection
} from "./contracts.js";

const app = document.querySelector("#app");

const ui = {
  data: null,
  view: "dashboard",
  selected: null,
  search: "",
  filterField: "",
  filterValue: "",
  sort: "",
  showArchived: false,
  busy: false
};

loadState();

document.addEventListener("click", async (event) => {
  const target = event.target.closest("[data-action]");
  if (!target || ui.busy) return;
  const action = target.dataset.action;
  const value = target.dataset.value || "";
  if (action === "nav") {
    ui.view = value;
    ui.selected = null;
    resetControls();
    render();
  } else if (action === "select-row") {
    ui.selected = { collection: target.dataset.collection, id: target.dataset.id };
    renderCollection(ui.view);
  } else if (action === "open-record") {
    ui.view = target.dataset.collection;
    ui.selected = { collection: target.dataset.collection, id: target.dataset.id };
    resetControls();
    render();
  } else if (action === "new") {
    openEditor(value);
  } else if (action === "edit") {
    openEditor(target.dataset.collection, target.dataset.id);
  } else if (action === "close-modal") {
    closeModal();
  } else if (action === "archive") {
    if (window.confirm("Archive this record? Related active records may block the action.")) {
      await mutate(`/api/${encodeURIComponent(target.dataset.collection)}/${encodeURIComponent(target.dataset.id)}/archive`, { method: "POST" }, "Record archived.");
    }
  } else if (action === "restore") {
    await mutate(`/api/${encodeURIComponent(target.dataset.collection)}/${encodeURIComponent(target.dataset.id)}/restore`, { method: "POST" }, "Record restored.");
  } else if (action === "workflow") {
    const workflow = ui.data.config.actions.find((item) => item.key === value);
    if (workflow?.fields?.length) openWorkflow(workflow, target.dataset.id);
    else await mutate(`/api/actions/${value}`, { method: "POST", body: { id: target.dataset.id } }, `${workflow?.label || "Workflow"} saved.`);
  } else if (action === "export-all") {
    window.location.href = "/api/export/all.json";
  } else if (action === "export-json") {
    window.location.href = exportUrl(value, "json");
  } else if (action === "export-csv") {
    window.location.href = exportUrl(value, "csv");
  } else if (action === "import") {
    openImport();
  } else if (action === "clear-filters") {
    resetControls();
    renderCollection(ui.view);
  }
});

document.addEventListener("keydown", (event) => {
  if ((event.key === "Enter" || event.key === " ") && event.target.matches("tr[data-action='select-row']")) {
    event.preventDefault();
    event.target.click();
  }
  if (event.key === "Escape") closeModal();
});

document.addEventListener("input", (event) => {
  const target = event.target;
  if (target.matches("[data-search]")) {
    ui.search = target.value;
    const cursor = target.selectionStart;
    renderCollection(ui.view);
    const replacement = document.querySelector("[data-search]");
    replacement?.focus();
    replacement?.setSelectionRange(cursor, cursor);
  } else if (target.matches("[data-filter-field]")) {
    ui.filterField = target.value;
    ui.filterValue = "";
    renderCollection(ui.view);
  } else if (target.matches("[data-filter-value]")) {
    ui.filterValue = target.value;
    renderCollection(ui.view);
  } else if (target.matches("[data-sort]")) {
    ui.sort = target.value;
    renderCollection(ui.view);
  } else if (target.matches("[data-show-archived]")) {
    ui.showArchived = target.checked;
    ui.selected = null;
    renderCollection(ui.view);
  }
});

document.addEventListener("submit", async (event) => {
  event.preventDefault();
  const form = event.target;
  if (form.matches("[data-entity-form]")) await submitEntityForm(form);
  else if (form.matches("[data-settings-form]")) await submitSettingsForm(form);
  else if (form.matches("[data-session-form]")) await submitSessionForm(form);
  else if (form.matches("[data-import-form]")) await submitImportForm(form);
  else if (form.matches("[data-workflow-form]")) await submitWorkflowForm(form);
});

async function loadState() {
  setBusy(true);
  try {
    const response = await fetch("/api/state");
    const payload = await response.json();
    if (!response.ok) throw new Error((payload.errors || ["State request failed."]).join(" "));
    ui.data = payload;
    document.title = `${ui.data.config.name} · Maintenance control`;
    render();
  } catch (error) {
    app.innerHTML = `<main class="boot-panel"><div class="brand-mark large">${icon("wrench")}</div><h1>MaintainStuff is offline</h1><p>${escapeHtml(error.message)}</p><p class="small">Start the local server, then reload this page.</p></main>`;
  } finally {
    setBusy(false);
  }
}

async function mutate(path, options, successMessage) {
  setBusy(true);
  try {
    const response = await fetch(path, {
      method: options.method || "POST",
      headers: { "content-type": "application/json" },
      body: options.body ? JSON.stringify(options.body) : undefined
    });
    const payload = await response.json();
    if (!response.ok) throw new Error((payload.errors || ["Request failed."]).join(" "));
    ui.data = payload;
    showToast(successMessage);
    render();
    return true;
  } catch (error) {
    showToast(error.message, true);
    return false;
  } finally {
    setBusy(false);
  }
}

function render() {
  if (!ui.data) return;
  applyTheme(ui.data.config.theme);
  app.className = `app-shell${ui.busy ? " is-busy" : ""}`;
  app.innerHTML = `
    <aside class="sidebar">
      <div class="brand">
        <div class="brand-mark">${icon("wrench")}</div>
        <div><h1>${escapeHtml(ui.data.config.name)}</h1><p>Local maintenance control</p></div>
      </div>
      <div class="workspace-chip"><span>${escapeHtml(ui.data.workspace.organizationName)}</span><small>${activeRows("assets").length} active assets · ${escapeHtml(ui.data.session.role)}</small></div>
      <nav class="nav" aria-label="Product navigation">
        ${navButton("dashboard", "Control room", "dashboard")}
        ${ui.data.config.collections.map((collection) => navButton(collection.key, collection.navLabel || collection.label, collection.icon || "table")).join("")}
        ${navButton("activity", "Activity", "activity")}
        ${navButton("settings", "Settings & data", "settings")}
      </nav>
      <div class="sidebar-foot">
        ${canUseFullData() ? `<button class="sidebar-action" data-action="export-all">${icon("download")} Export workspace</button>` : ""}
        <span>Self-hosted · SQLite-free JSON store · MIT</span>
      </div>
    </aside>
    <main class="main"><div id="view-root"></div></main>
  `;
  if (ui.view === "dashboard") renderDashboard();
  else if (ui.view === "settings") renderSettings();
  else if (ui.view === "activity") renderActivityView();
  else renderCollection(ui.view);
}

function renderDashboard() {
  const root = document.querySelector("#view-root");
  const config = ui.data.config;
  const metrics = config.metrics.map((metric) => {
    const value = ui.data.analytics.metrics[metric.key] ?? 0;
    const tone = metricTone(metric.key, value);
    return `<article class="metric ${tone}"><div class="metric-top"><span>${escapeHtml(metric.label)}</span>${icon(metricIcon(metric.key))}</div><strong>${formatMetric(value, metric)}</strong><small>${escapeHtml(metric.helper || "")}</small></article>`;
  }).join("");
  const queue = ui.data.analytics.priorityQueue || [];
  const alerts = ui.data.analytics.alerts || [];
  root.innerHTML = `
    <section class="topbar dashboard-head">
      <div><span class="eyebrow">Maintenance operations · ${escapeHtml(todayLabel())}</span><h2>Control room</h2><p>Live priorities, reliability exposure, labor, inventory, and asset availability from your local maintenance history.</p></div>
      <div class="toolbar">
        ${canCreateCollection("workOrders") ? `<button class="btn primary" data-action="new" data-value="workOrders">${icon("plus")} New work order</button>` : ""}
        ${canCreateCollection("meterReadings") ? `<button class="btn" data-action="new" data-value="meterReadings">${icon("meter")} Record meter</button>` : ""}
      </div>
    </section>
    <section class="quick-actions" aria-label="Common actions">
      ${canCreateCollection("assets") ? quickAction("assets", "Register asset", "asset") : ""}
      ${canCreateCollection("inspections") ? quickAction("inspections", "Record inspection", "inspection") : ""}
      ${canCreateCollection("preventiveSchedules") ? quickAction("preventiveSchedules", "Create PM plan", "calendar") : ""}
      ${canCreateCollection("parts") ? quickAction("parts", "Add stocked part", "parts") : ""}
    </section>
    <section class="grid metrics">${metrics}</section>
    <section class="grid dashboard-grid">
      <article class="panel span-two">
        <div class="panel-header"><div><span class="eyebrow">Execution</span><h3>Priority work queue</h3><p>Open work ranked by overdue exposure and priority.</p></div><button class="btn compact" data-action="nav" data-value="workOrders">View all ${icon("arrow")}</button></div>
        <div class="queue-table">
          ${queue.map((row) => `<button data-action="open-record" data-collection="workOrders" data-id="${escapeAttr(row.id)}"><span><b>${escapeHtml(row.number)}</b><small>${escapeHtml(row.assetName)}</small></span><strong>${escapeHtml(row.title)}</strong><span class="pill ${statusTone(row.priority)}">${escapeHtml(row.priority)}</span><span class="pill ${statusTone(row.status)}">${escapeHtml(row.status)}</span><time>${formatDate(row.dueDate)}</time></button>`).join("") || `<div class="empty-state">${icon("check")}<strong>No open work</strong><span>The maintenance queue is clear.</span></div>`}
        </div>
      </article>
      <article class="panel alerts-panel">
        <div class="panel-header"><div><span class="eyebrow">Attention</span><h3>Operational alerts</h3><p>Conditions that need a decision.</p></div><span class="count-badge">${alerts.length}</span></div>
        <div class="alert-list">${alerts.map((alert) => `<button class="alert ${escapeAttr(alert.type)}" data-action="open-record" data-collection="${escapeAttr(alert.collection)}" data-id="${escapeAttr(alert.id)}"><span class="alert-dot"></span><span><b>${escapeHtml(alert.title)}</b><small>${escapeHtml(alert.detail)}</small></span>${icon("arrow")}</button>`).join("") || `<div class="empty-state small-empty">${icon("check")}<strong>No active alerts</strong></div>`}</div>
      </article>
      <article class="panel">
        <div class="panel-header"><div><span class="eyebrow">Flow</span><h3>Work by status</h3><p>Computed across active work orders.</p></div></div>
        <div class="chart">${renderBreakdown(ui.data.analytics.primaryBreakdown)}</div>
      </article>
      <article class="panel">
        <div class="panel-header"><div><span class="eyebrow">Audit</span><h3>Recent activity</h3><p>Who changed what, and when.</p></div><button class="btn compact" data-action="nav" data-value="activity">Full log ${icon("arrow")}</button></div>
        <ul class="activity-list">${renderActivity(7)}</ul>
      </article>
    </section>
  `;
}

function renderCollection(collectionKey) {
  const root = document.querySelector("#view-root");
  if (!root) return;
  const collection = collectionConfig(collectionKey);
  if (!collection) {
    ui.view = "dashboard";
    return render();
  }
  if (!ui.sort) ui.sort = collection.defaultSort || `${collection.displayField}:asc`;
  const rows = filteredRows(collection);
  const selected = selectedRow(collection.key);
  const activeCount = activeRows(collection.key).length;
  const archivedCount = (ui.data[collection.key] || []).length - activeCount;
  root.innerHTML = `
    <section class="topbar">
      <div><span class="eyebrow">Maintenance records</span><h2>${escapeHtml(collection.label)}</h2><p>${escapeHtml(collection.description)}</p></div>
      <div class="toolbar">
        ${canCreateCollection(collection.key) ? `<button class="btn primary" data-action="new" data-value="${escapeAttr(collection.key)}">${icon("plus")} New ${escapeHtml(collection.singular.toLowerCase())}</button>` : ""}
        ${canExportCollection(collection.key) ? `<button class="btn" data-action="export-csv" data-value="${escapeAttr(collection.key)}">${icon("download")} CSV</button><button class="btn" data-action="export-json" data-value="${escapeAttr(collection.key)}">JSON</button>` : ""}
      </div>
    </section>
    <section class="record-summary"><span><b>${activeCount}</b> active</span><span><b>${archivedCount}</b> archived</span><span><b>${rows.length}</b> shown</span></section>
    <section class="workbench">
      <div class="records-pane">
        ${renderTableTools(collection)}
        <div class="table-wrap">
          <table>
            <thead><tr>${tableFields(collection).map((field) => `<th>${escapeHtml(field.label)}</th>`).join("")}<th>Updated</th></tr></thead>
            <tbody>${rows.map((row) => renderTableRow(collection, row)).join("") || `<tr><td colspan="${tableFields(collection).length + 1}"><div class="empty-state"><strong>No matching records</strong><span>Adjust the search, filter, or archive view.</span><button class="btn" data-action="clear-filters">Clear controls</button></div></td></tr>`}</tbody>
          </table>
        </div>
      </div>
      <aside class="panel inspector">
        ${selected ? renderInspector(collection, selected) : `<div class="inspector-empty">${icon(collection.icon || "table")}<h3>${escapeHtml(collection.singular)} details</h3><p>Select a row to inspect its complete record, relationships, audit events, and available workflow actions.</p></div>`}
      </aside>
    </section>
  `;
}

function renderTableTools(collection) {
  const filterFields = collection.filters.map((name) => collection.fields.find((field) => field.name === name)).filter(Boolean);
  const activeFilter = filterFields.find((field) => field.name === ui.filterField) || filterFields[0];
  if (!ui.filterField && activeFilter) ui.filterField = activeFilter.name;
  const filterOptions = activeFilter ? uniqueValues(collection.key, activeFilter.name) : [];
  const controlsActive = ui.search || ui.filterValue;
  return `
    <div class="table-tools">
      <label class="field search-field"><span>Search all fields</span><div class="input-with-icon">${icon("search")}<input data-search value="${escapeAttr(ui.search)}" autocomplete="off"></div></label>
      <label class="field"><span>Filter</span><select data-filter-field>${filterFields.map((field) => `<option value="${field.name}" ${field.name === ui.filterField ? "selected" : ""}>${escapeHtml(field.label)}</option>`).join("")}</select></label>
      <label class="field"><span>Value</span><select data-filter-value><option value="">All values</option>${filterOptions.map((value) => `<option value="${escapeAttr(value)}" ${value === ui.filterValue ? "selected" : ""}>${escapeHtml(activeFilter?.type === "relation" ? displayRelated(activeFilter, value) : value)}</option>`).join("")}</select></label>
      <label class="field"><span>Sort</span><select data-sort>${tableFields(collection).flatMap((field) => [`${field.name}:asc`, `${field.name}:desc`].map((sortValue) => `<option value="${sortValue}" ${sortValue === ui.sort ? "selected" : ""}>${escapeHtml(field.label)} · ${sortValue.endsWith(":asc") ? "ascending" : "descending"}</option>`)).join("")}</select></label>
      <label class="archive-toggle"><input type="checkbox" data-show-archived ${ui.showArchived ? "checked" : ""}><span>Archived</span></label>
      ${controlsActive ? `<button class="btn compact" data-action="clear-filters">Clear</button>` : ""}
    </div>
  `;
}

function renderTableRow(collection, row) {
  const selected = ui.selected?.collection === collection.key && ui.selected?.id === row.id;
  return `
    <tr class="${selected ? "selected" : ""} ${row.archivedAt ? "archived" : ""}" tabindex="0" data-action="select-row" data-collection="${escapeAttr(collection.key)}" data-id="${escapeAttr(row.id)}" aria-selected="${selected}">
      ${tableFields(collection).map((field, index) => `<td>${index === 0 && row.archivedAt ? `<span class="archive-mark">Archived</span>` : ""}${formatField(field, row[field.name])}</td>`).join("")}
      <td><span class="small">${formatDateTime(row.updatedAt)}</span></td>
    </tr>
  `;
}

function renderInspector(collection, row) {
  const status = collection.key === "inspections" ? row.result : row.status;
  const actions = ui.data.config.actions.filter((action) => action.collection === collection.key && !row.archivedAt && canUseWorkflow(action) && actionAvailable(action, row) && (!action.allowedStatuses || action.allowedStatuses.includes(status)));
  const entityActivity = ui.data.activity.filter((item) => item.entityType === collection.key && item.entityId === row.id).slice(0, 5);
  return `
    <div class="inspector-heading">
      <div><span class="eyebrow">${escapeHtml(collection.singular)} record</span><h3>${escapeHtml(row[collection.displayField] || collection.singular)}</h3><p>${escapeHtml(summaryLine(collection, row))}</p></div>
      ${row.archivedAt ? `<span class="pill muted">Archived</span>` : status ? `<span class="pill ${statusTone(status)}">${escapeHtml(status)}</span>` : ""}
    </div>
    <div class="actions primary-actions">
      ${row.archivedAt ? canLifecycleCollection(collection.key) ? `<button class="btn primary" data-action="restore" data-collection="${escapeAttr(collection.key)}" data-id="${escapeAttr(row.id)}">${icon("refresh")} Restore</button>` : "" : `${canEditCollection(collection.key) ? `<button class="btn primary" data-action="edit" data-collection="${escapeAttr(collection.key)}" data-id="${escapeAttr(row.id)}">${icon("edit")} Edit record</button>` : ""}${canLifecycleCollection(collection.key) ? `<button class="btn danger-quiet" data-action="archive" data-collection="${escapeAttr(collection.key)}" data-id="${escapeAttr(row.id)}">${icon("archive")} Archive</button>` : ""}`}
    </div>
      ${actions.length ? `<section class="inspector-section"><h4>Available actions</h4><div class="actions">${actions.map((action) => `<button class="btn workflow" data-action="workflow" data-value="${escapeAttr(action.key)}" data-id="${escapeAttr(row.id)}">${icon(actionIcon(action.type))} ${escapeHtml(action.label)}</button>`).join("")}</div></section>` : ""}
    ${renderRelated(collection.key, row)}
    <section class="inspector-section"><h4>Record details</h4><dl class="detail-list">${collection.fields.map((field) => `<div><dt>${escapeHtml(field.label)}</dt><dd>${formatField(field, row[field.name]) || `<span class="small">Not recorded</span>`}</dd></div>`).join("")}</dl></section>
    ${entityActivity.length ? `<section class="inspector-section"><h4>Recent audit events</h4><ul class="mini-activity">${entityActivity.map(activityItem).join("")}</ul></section>` : ""}
    <p class="record-stamp">Created ${formatDateTime(row.createdAt)} · Updated ${formatDateTime(row.updatedAt)}</p>
  `;
}

function renderRelated(collectionKey, row) {
  const links = [];
  if (collectionKey === "assets") {
    links.push(...activeRows("workOrders").filter((item) => item.assetId === row.id).slice(0, 4).map((item) => relatedLink("workOrders", item, `${item.number} · ${item.status}`)));
    links.push(...activeRows("preventiveSchedules").filter((item) => item.assetId === row.id).slice(0, 3).map((item) => relatedLink("preventiveSchedules", item, `PM · ${item.status}`)));
  } else if (collectionKey === "workOrders") {
    const asset = findRecord("assets", row.assetId);
    if (asset) links.push(relatedLink("assets", asset, asset.assetTag));
    const schedule = findRecord("preventiveSchedules", row.preventiveScheduleId);
    if (schedule) links.push(relatedLink("preventiveSchedules", schedule, "Preventive plan"));
  } else if (collectionKey === "preventiveSchedules") {
    const asset = findRecord("assets", row.assetId);
    if (asset) links.push(relatedLink("assets", asset, asset.assetTag));
    links.push(...activeRows("workOrders").filter((item) => item.preventiveScheduleId === row.id).slice(0, 4).map((item) => relatedLink("workOrders", item, `${item.number} · ${item.status}`)));
  } else if (collectionKey === "inspections") {
    for (const id of [row.assetId, row.workOrderId, row.followUpWorkOrderId]) {
      const relatedCollection = id === row.assetId ? "assets" : "workOrders";
      const record = findRecord(relatedCollection, id);
      if (record) links.push(relatedLink(relatedCollection, record, relatedCollection === "assets" ? record.assetTag : record.number));
    }
  } else if (collectionKey === "parts") {
    for (const work of activeRows("workOrders")) {
      const usage = (work.partsUsed || []).filter((item) => item.partId === row.id);
      if (usage.length) links.push(relatedLink("workOrders", work, `${work.number} · ${usage.reduce((sum, item) => sum + Number(item.quantity), 0)} issued`));
    }
  } else if (collectionKey === "meterReadings") {
    const asset = findRecord("assets", row.assetId);
    if (asset) links.push(relatedLink("assets", asset, `${asset.assetTag} · current ${asset.meterValue} ${asset.meterUnit}`));
  }
  const partsUsed = collectionKey === "workOrders" && row.partsUsed?.length ? `<div class="parts-used"><h4>Issued parts</h4>${row.partsUsed.map((use) => { const part = findRecord("parts", use.partId); return `<div><span><b>${escapeHtml(part?.name || use.partId)}</b><small>${escapeHtml(part?.sku || "Archived part")} · ${formatDateTime(use.issuedAt)}</small></span><strong>${formatNumber(use.quantity)} × ${formatCurrency(use.unitCost)}</strong></div>`; }).join("")}</div>` : "";
  if (!links.length && !partsUsed) return "";
  return `<section class="inspector-section related-section">${links.length ? `<h4>Related records</h4><div class="related-list">${links.join("")}</div>` : ""}${partsUsed}</section>`;
}

function renderActivityView() {
  const root = document.querySelector("#view-root");
  const activity = ui.data.analytics.activity || [];
  root.innerHTML = `
    <section class="topbar"><div><span class="eyebrow">Accountability</span><h2>Activity history</h2><p>A durable, newest-first audit trail for local maintenance and data changes.</p></div><div class="toolbar">${canUseFullData() ? `<button class="btn" data-action="export-all">${icon("download")} Export with workspace</button>` : ""}</div></section>
    <section class="panel activity-ledger">
      <div class="ledger-head"><span>Event</span><span>Record</span><span>Actor</span><span>Time</span></div>
      ${activity.map((item) => `<article><span class="activity-icon">${icon(activityIcon(item.entityType))}</span><div><b>${escapeHtml(sentenceCase(item.action))}</b><small>${escapeHtml(metadataSummary(item.metadata))}</small></div><code>${escapeHtml(item.entityType)} / ${escapeHtml(item.entityId)}</code><span>${escapeHtml(item.actor || "Local Admin")}</span><time>${formatDateTime(item.createdAt)}</time></article>`).join("") || `<div class="empty-state"><strong>No activity recorded</strong></div>`}
    </section>
  `;
}

function renderSettings() {
  const root = document.querySelector("#view-root");
  const config = ui.data.config;
  root.innerHTML = `
    <section class="topbar"><div><span class="eyebrow">Administration</span><h2>Settings & data</h2><p>Define operating rules, sites, labor costing, identifiers, and open-format data exits.</p></div></section>
    <section class="settings-layout">
      <article class="panel settings-card">
        <div class="panel-header"><div><h3>Workspace policy</h3><p>Changes are validated against active records and written to the audit trail.</p></div></div>
        ${canChangeWorkspace() ? `<form data-settings-form class="settings-form"><div class="form-grid">${config.workspaceFields.map((field) => renderFieldInput(field, ui.data.workspace[field.name])).join("")}</div><div class="form-footer"><span>Local changes persist atomically on disk.</span><button class="btn primary" type="submit">${icon("save")} Save settings</button></div></form>` : `<p class="empty-state">A planner, maintenance manager, or administrator is required to change workspace policy.</p>`}
      </article>
      <aside class="settings-side">
        ${config.proxyIdentityActive ? `<article class="panel data-card"><span class="eyebrow">Trusted proxy</span><h3>${escapeHtml(ui.data.session.userName)}</h3><p>Identity and the ${escapeHtml(ui.data.session.role)} role are supplied by the trusted access proxy.</p></article>` : `<article class="panel data-card"><span class="eyebrow">Local session</span><h3>Audit identity</h3><p>Choose the local operator recorded on later events. This identity is a trusted-machine convenience, not internet authentication.</p><form data-session-form class="session-form">${config.sessionFields.map((field) => renderFieldInput(field, ui.data.session[field.name])).join("")}<button class="btn primary" type="submit">${icon("save")} Update operator</button></form></article>`}
        ${canUseFullData() ? `<article class="panel data-card"><span class="eyebrow">No lock-in</span><h3>Your maintenance history stays portable.</h3><p>Export one complete workspace snapshot for backup or migration, or download a filtered record set as JSON or CSV.</p><div class="stack-actions"><button class="btn primary" data-action="export-all">${icon("download")} Export complete workspace</button><button class="btn" data-action="import">${icon("upload")} Validate & import JSON</button></div></article>` : ""}
        <article class="panel data-card"><span class="eyebrow">Storage</span><h3>Self-hosted by default</h3><dl class="compact-dl"><div><dt>Data engine</dt><dd>Atomic JSON file</dd></div><div><dt>Credentials</dt><dd>None required</dd></div><div><dt>Core limits</dt><dd>Unlimited</dd></div><div><dt>License</dt><dd>MIT</dd></div></dl></article>
      </aside>
    </section>
  `;
}

function openEditor(collectionKey, id = "") {
  const collection = collectionConfig(collectionKey);
  const row = id ? findRecord(collectionKey, id) : {};
  openModal(`
    <header><div><span class="eyebrow">${id ? "Update record" : "Create record"}</span><h3>${id ? "Edit" : "New"} ${escapeHtml(collection.singular.toLowerCase())}</h3></div><button class="icon-btn" data-action="close-modal" type="button" aria-label="Close">${icon("close")}</button></header>
    <form data-entity-form data-collection="${escapeAttr(collection.key)}" data-id="${escapeAttr(id)}">
      <div class="form-grid">${collection.fields.map((field) => renderFieldInput(field, row?.[field.name] ?? field.default ?? "", { editing: Boolean(id) })).join("")}</div>
      <div class="form-footer"><span>* Required fields</span><div class="actions"><button class="btn" data-action="close-modal" type="button">Cancel</button><button class="btn primary" type="submit">${icon("save")} Save ${escapeHtml(collection.singular.toLowerCase())}</button></div></div>
    </form>
  `, "modal wide-modal");
}

function openWorkflow(workflow, id) {
  const row = findRecord(workflow.collection, id);
  const collection = collectionConfig(workflow.collection);
  openModal(`
    <header><div><span class="eyebrow">Workflow action</span><h3>${escapeHtml(workflow.label)}</h3><p>${escapeHtml(row?.[collection.displayField] || collection.singular)}</p></div><button class="icon-btn" data-action="close-modal" type="button" aria-label="Close">${icon("close")}</button></header>
    <form data-workflow-form data-workflow="${escapeAttr(workflow.key)}" data-id="${escapeAttr(id)}">
      <div class="form-grid">${workflow.fields.map((field) => renderFieldInput(field, field.hidden ? crypto.randomUUID() : "")).join("")}</div>
      <div class="form-footer"><span>This action updates related records and the audit trail.</span><div class="actions"><button class="btn" data-action="close-modal" type="button">Cancel</button><button class="btn primary" type="submit">${icon(actionIcon(workflow.type))} ${escapeHtml(workflow.label)}</button></div></div>
    </form>
  `);
}

function openImport() {
  openModal(`
    <header><div><span class="eyebrow">Data portability</span><h3>Import workspace snapshot</h3><p>All records and relationships are validated before anything is replaced.</p></div><button class="icon-btn" data-action="close-modal" type="button" aria-label="Close">${icon("close")}</button></header>
    <form data-import-form><label class="field wide"><span>Complete MaintainStuff JSON</span><textarea class="import-box" name="snapshot" required spellcheck="false"></textarea><small>Use a complete MaintainStuff export. The validated snapshot replaces operational records; durable activity is merged and never deleted.</small></label><label class="field wide"><span>Destructive confirmation</span><input name="confirmation" required autocomplete="off" aria-label="Type REPLACE"><small>Type REPLACE to confirm replacement of current records.</small></label><label class="field wide"><span><input type="checkbox" name="acknowledge" required> I exported a current backup and understand this replaces operational records.</span></label><div class="form-footer"><span>Import is all-or-nothing after complete graph validation.</span><div class="actions"><button class="btn" data-action="close-modal" type="button">Cancel</button><button class="btn primary" type="submit">${icon("upload")} Validate & replace</button></div></div></form>
  `);
}

function openModal(content, className = "modal") {
  closeModal();
  document.body.insertAdjacentHTML("beforeend", `<div class="modal-backdrop" role="dialog" aria-modal="true"><article class="${className}">${content}</article></div>`);
  document.querySelector(".modal input:not([readonly]), .modal select, .modal textarea, .wide-modal input:not([readonly]), .wide-modal select, .wide-modal textarea")?.focus();
}

async function submitEntityForm(form) {
  const collectionKey = form.dataset.collection;
  const id = form.dataset.id;
  const collection = collectionConfig(collectionKey);
  const body = Object.fromEntries(collection.fields.map((field) => [field.name, readFieldValue(form, field)]));
  const success = await mutate(id ? `/api/${encodeURIComponent(collectionKey)}/${encodeURIComponent(id)}` : `/api/${encodeURIComponent(collectionKey)}`, { method: id ? "PATCH" : "POST", body }, id ? "Record updated." : "Record created.");
  if (success) closeModal();
}

async function submitSettingsForm(form) {
  const body = Object.fromEntries(ui.data.config.workspaceFields.map((field) => [field.name, readFieldValue(form, field)]));
  await mutate("/api/workspace", { method: "PATCH", body }, "Workspace settings saved.");
}

async function submitSessionForm(form) {
  const body = Object.fromEntries(ui.data.config.sessionFields.map((field) => [field.name, readFieldValue(form, field)]));
  await mutate("/api/session", { method: "PATCH", body }, "Local operator updated.");
}

async function submitWorkflowForm(form) {
  const workflow = ui.data.config.actions.find((item) => item.key === form.dataset.workflow);
  const body = { id: form.dataset.id, ...Object.fromEntries(workflow.fields.map((field) => [field.name, readFieldValue(form, field)])) };
  const success = await mutate(`/api/actions/${workflow.key}`, { method: "POST", body }, `${workflow.label} saved.`);
  if (success) closeModal();
}

async function submitImportForm(form) {
  try {
    if (form.elements.confirmation.value !== "REPLACE" || !form.elements.acknowledge.checked) throw new Error("Type REPLACE and acknowledge the backup requirement before importing.");
    const snapshot = JSON.parse(form.elements.snapshot.value);
    const success = await mutate("/api/import", { method: "POST", body: snapshot }, "Workspace imported and validated.");
    if (success) closeModal();
  } catch (error) {
    showToast(error.message || "The import text is not valid JSON.", true);
  }
}

function renderFieldInput(field, value, context = {}) {
  const name = escapeAttr(field.name);
  const label = `<span>${escapeHtml(field.label)}${field.required ? " *" : ""}${field.computed ? `<em>Computed</em>` : field.generated ? `<em>Generated</em>` : ""}</span>`;
  const wide = ["textarea", "relationMany", "tags"].includes(field.type) ? " wide" : "";
  const readOnly = field.computed || field.generated || field.workflowControlled;
  const help = field.generated && !value ? `<small>Assigned automatically when saved.</small>` : field.computed ? `<small>Updated by maintenance workflows.</small>` : "";
  if (field.hidden) return `<input type="hidden" name="${name}" value="${escapeAttr(value)}">`;
  if (field.type === "textarea") return `<label class="field${wide}">${label}<textarea name="${name}" maxlength="${field.maxLength || ""}" ${readOnly ? "readonly" : ""}>${escapeHtml(value ?? "")}</textarea>${help}</label>`;
  if (field.type === "select") {
    const options = field.options.map((option) => `<option value="${escapeAttr(option)}" ${option === value ? "selected" : ""}>${escapeHtml(option)}</option>`).join("");
    return `<label class="field${wide}">${label}<select name="${name}" ${readOnly ? "disabled" : ""}>${!field.required ? `<option value="">None</option>` : ""}${options}</select>${readOnly ? `<input type="hidden" name="${name}" value="${escapeAttr(value || field.options[0] || "")}">` : ""}${help}</label>`;
  }
  if (field.type === "workspaceOption") {
    const options = ui.data.workspace[field.workspaceField] || [];
    return `<label class="field${wide}">${label}<select name="${name}">${options.map((option) => `<option value="${escapeAttr(option)}" ${option === value ? "selected" : ""}>${escapeHtml(option)}</option>`).join("")}</select></label>`;
  }
  if (field.type === "relation") return `<label class="field${wide}">${label}<select name="${name}" ${readOnly ? "disabled" : ""}><option value="">${field.required ? "Select a record" : "None"}</option>${relationOptions(field, value)}</select>${readOnly ? `<input type="hidden" name="${name}" value="${escapeAttr(value || "")}">` : ""}${help}</label>`;
  if (field.type === "relationMany") return `<label class="field${wide}">${label}<select name="${name}" multiple size="5">${relationOptions(field, value)}</select></label>`;
  if (field.type === "tags" || field.type === "multiselect") return `<label class="field${wide}">${label}<input name="${name}" value="${escapeAttr(Array.isArray(value) ? value.join(", ") : value || "")}"><small>Separate values with commas.</small></label>`;
  if (field.type === "boolean") return `<label class="field${wide}">${label}<select name="${name}"><option value="true" ${value ? "selected" : ""}>Yes</option><option value="false" ${!value ? "selected" : ""}>No</option></select></label>`;
  const htmlType = field.type === "date" ? "date" : field.type === "email" ? "email" : field.type === "number" ? "number" : "text";
  const min = field.minExclusive !== undefined ? Number(field.minExclusive) + Number(field.step || 0.01) : field.min;
  const attributes = [field.required && !readOnly ? "required" : "", field.maxLength ? `maxlength="${field.maxLength}"` : "", min !== undefined ? `min="${min}"` : "", field.max !== undefined ? `max="${field.max}"` : "", field.step !== undefined ? `step="${field.step}"` : "", field.pattern ? `pattern="${escapeAttr(field.pattern)}"` : "", readOnly ? "readonly" : ""].filter(Boolean).join(" ");
  return `<label class="field${wide}">${label}<input type="${htmlType}" name="${name}" value="${escapeAttr(value ?? "")}" ${attributes}>${help}</label>`;
}

function readFieldValue(form, field) {
  const element = form.elements[field.name];
  if (!element) return "";
  const control = typeof RadioNodeList !== "undefined" && element instanceof RadioNodeList ? element[0] : element;
  if (field.type === "relationMany") return Array.from(control.selectedOptions).map((option) => option.value);
  if (field.type === "tags" || field.type === "multiselect") return control.value.split(",").map((item) => item.trim()).filter(Boolean);
  if (field.type === "number") return control.value === "" ? "" : Number(control.value);
  if (field.type === "boolean") return control.value === "true";
  return control.value;
}

function relationOptions(field, value) {
  const selected = new Set(Array.isArray(value) ? value : [value]);
  const collection = collectionConfig(field.collection);
  return activeRows(field.collection).map((row) => `<option value="${escapeAttr(row.id)}" ${selected.has(row.id) ? "selected" : ""}>${escapeHtml(relationOptionLabel(collection, row))}</option>`).join("");
}

function relationOptionLabel(collection, row) {
  if (row.number) return `${row.number} · ${row[collection.displayField]}`;
  if (row.assetTag) return `${row.assetTag} · ${row[collection.displayField]}`;
  if (row.sku) return `${row.sku} · ${row[collection.displayField]}`;
  return row[collection.displayField] || row.id;
}

function filteredRows(collection) {
  const terms = ui.search.toLowerCase().split(/\s+/).filter(Boolean);
  const rows = (ui.data[collection.key] || []).filter((row) => {
    if (ui.showArchived ? !row.archivedAt : row.archivedAt) return false;
    const haystack = recordSearchText(ui.data, ui.data.config.collections, row).toLowerCase();
    const matchesSearch = terms.every((term) => haystack.includes(term));
    const fieldValue = row[ui.filterField];
    const matchesFilter = !ui.filterField || !ui.filterValue || (Array.isArray(fieldValue) ? fieldValue.includes(ui.filterValue) : String(fieldValue ?? "") === ui.filterValue);
    return matchesSearch && matchesFilter;
  });
  const [field, direction] = (ui.sort || collection.defaultSort || `${collection.displayField}:asc`).split(":");
  return rows.sort((left, right) => compareRecords(left, right, field, direction));
}

function exportUrl(collectionKey, format) {
  const params = new URLSearchParams({ archive: ui.showArchived ? "archived" : "active" });
  if (ui.search) params.set("search", ui.search);
  if (ui.filterField && ui.filterValue) {
    params.set("filterField", ui.filterField);
    params.set("filterValue", ui.filterValue);
  }
  const [sortField, direction] = (ui.sort || "").split(":");
  if (sortField) params.set("sortField", sortField);
  if (direction) params.set("direction", direction);
  return `/api/export/${encodeURIComponent(collectionKey)}.${format}?${params}`;
}

function canUseFullData() {
  return roleCan(ui.data?.session?.role, "fullData");
}

function canChangeWorkspace() {
  return roleCan(ui.data?.session?.role, "workspace");
}

function canCreateCollection(collectionKey) {
  return roleCanCollection(ui.data?.session?.role, "create", collectionKey);
}

function canEditCollection(collectionKey) {
  return roleCanCollection(ui.data?.session?.role, "edit", collectionKey);
}

function canLifecycleCollection(collectionKey) {
  return roleCanCollection(ui.data?.session?.role, "lifecycle", collectionKey);
}

function canExportCollection(collectionKey) {
  return roleCanCollection(ui.data?.session?.role, "export", collectionKey);
}

function canUseWorkflow(action) {
  return roleCanAction(ui.data?.session?.role, action.key);
}

function actionAvailable(action, row) {
  if (action.key === "raise-inspection-follow-up") return !row.followUpWorkOrderId;
  if (action.key === "generate-pm-work") return !activeRows("workOrders").some((work) => work.preventiveScheduleId === row.id && !["Completed", "Cancelled"].includes(work.status));
  if (action.key === "apply-meter-reading") {
    const latest = activeRows("meterReadings").filter((reading) => reading.assetId === row.assetId).sort((left, right) => compareMeterRecords(right, left))[0];
    return latest?.id === row.id;
  }
  return true;
}

function tableFields(collection) {
  const names = collection.tableFields || collection.fields.slice(0, 5).map((field) => field.name);
  return names.map((name) => collection.fields.find((field) => field.name === name)).filter(Boolean);
}

function activeRows(collectionKey) {
  return (ui.data?.[collectionKey] || []).filter((row) => !row.archivedAt);
}

function selectedRow(collectionKey) {
  if (ui.selected?.collection !== collectionKey) return null;
  return findRecord(collectionKey, ui.selected.id);
}

function findRecord(collectionKey, id) {
  return (ui.data?.[collectionKey] || []).find((row) => row.id === id) || null;
}

function collectionConfig(collectionKey) {
  return ui.data?.config.collections.find((collection) => collection.key === collectionKey);
}

function uniqueValues(collectionKey, field) {
  const values = new Set();
  for (const row of ui.showArchived ? (ui.data[collectionKey] || []).filter((item) => item.archivedAt) : activeRows(collectionKey)) {
    const value = row[field];
    if (Array.isArray(value)) value.forEach((item) => values.add(item));
    else if (value !== "" && value !== undefined && value !== null) values.add(String(value));
  }
  return [...values].sort((left, right) => left.localeCompare(right, undefined, { numeric: true }));
}

function formatField(field, value) {
  if (Array.isArray(value)) return value.length ? `<span class="pill-row">${value.map((item) => `<span class="pill muted">${escapeHtml(displayRelated(field, item))}</span>`).join("")}</span>` : "";
  if (field.type === "relation") return value ? `<span class="relation-value">${escapeHtml(displayRelated(field, value))}</span>` : "";
  if (field.type === "url" && value) return /^https?:\/\//.test(value) ? `<a href="${escapeAttr(value)}" target="_blank" rel="noreferrer">${escapeHtml(value)} ${icon("external")}</a>` : `<code>${escapeHtml(value)}</code>`;
  if (field.type === "date" && value) return formatDate(value);
  if (field.type === "number") {
    if (["laborCost", "partsCost", "unitCost"].includes(field.name)) return formatCurrency(value);
    if (field.name.toLowerCase().includes("hours")) return `${formatNumber(value)} h`;
    return formatNumber(value);
  }
  if (field.name === "status" || field.name === "result" || field.name === "priority" || field.name === "criticality") return `<span class="pill ${statusTone(value)}">${escapeHtml(value || "None")}</span>`;
  return escapeHtml(value ?? "");
}

function displayRelated(field, value) {
  if (!value) return "";
  if (!field.collection) return value;
  const collection = collectionConfig(field.collection);
  const row = findRecord(field.collection, value);
  return row ? relationOptionLabel(collection, row) : value;
}

function displayPlain(field, value) {
  if (Array.isArray(value)) return value.join(", ") || "None";
  if (field.type === "relation") return displayRelated(field, value) || "None";
  return value === 0 ? "0" : value || "None";
}

function summaryLine(collection, row) {
  return tableFields(collection).slice(1, 4).map((field) => `${field.label}: ${displayPlain(field, row[field.name])}`).join(" · ");
}

function renderBreakdown(counts) {
  const entries = Object.entries(counts);
  const total = entries.reduce((sum, [, count]) => sum + count, 0);
  return entries.map(([label, count]) => `<div class="bar-row"><span><b>${escapeHtml(label)}</b><small>${total ? Math.round((count / total) * 100) : 0}%</small></span><div class="bar-track"><div class="bar-fill ${statusTone(label)}" style="width:${Math.max(5, total ? (count / total) * 100 : 0)}%"></div></div><strong>${count}</strong></div>`).join("") || `<div class="empty-state"><strong>No active work</strong></div>`;
}

function renderActivity(limit = 8) {
  return (ui.data.analytics.activity || []).slice(0, limit).map(activityItem).join("") || `<li class="empty-state small-empty"><strong>No activity recorded</strong></li>`;
}

function activityItem(item) {
  return `<li><span class="activity-icon">${icon(activityIcon(item.entityType))}</span><span><b>${escapeHtml(sentenceCase(item.action))}</b><small>${escapeHtml(item.actor || "Local Admin")} · ${formatDateTime(item.createdAt)}</small></span></li>`;
}

function relatedLink(collectionKey, row, context) {
  const collection = collectionConfig(collectionKey);
  return `<button data-action="open-record" data-collection="${escapeAttr(collectionKey)}" data-id="${escapeAttr(row.id)}"><span><b>${escapeHtml(row[collection.displayField] || collection.singular)}</b><small>${escapeHtml(context)}</small></span>${icon("arrow")}</button>`;
}

function quickAction(collectionKey, label, iconName) {
  return `<button data-action="new" data-value="${escapeAttr(collectionKey)}">${icon(iconName)}<span><b>${escapeHtml(label)}</b><small>${escapeHtml(collectionConfig(collectionKey).singular)}</small></span>${icon("plus")}</button>`;
}

function navButton(view, label, iconName) {
  const count = collectionConfig(view) ? activeRows(view).length : "";
  return `<button class="${ui.view === view ? "active" : ""}" data-action="nav" data-value="${escapeAttr(view)}">${icon(iconName)}<span>${escapeHtml(label)}</span>${count !== "" ? `<small>${count}</small>` : ""}</button>`;
}

function closeModal() {
  document.querySelector(".modal-backdrop")?.remove();
}

function resetControls() {
  ui.search = "";
  ui.filterField = "";
  ui.filterValue = "";
  ui.sort = "";
  ui.showArchived = false;
}

function setBusy(isBusy) {
  ui.busy = isBusy;
  document.body.classList.toggle("busy", isBusy);
  app.setAttribute("aria-busy", String(isBusy));
}

function showToast(message, error = false) {
  document.querySelector(".toast")?.remove();
  const element = document.createElement("div");
  element.className = `toast ${error ? "error" : "success"}`;
  element.innerHTML = `${icon(error ? "alert" : "check")}<span>${escapeHtml(message)}</span>`;
  document.body.append(element);
  setTimeout(() => element.remove(), 4500);
}

function formatMetric(value, metric) {
  if (metric.format === "currency") return formatCurrency(value, 0);
  if (metric.format === "percent") return `${value}%`;
  if (metric.format === "hours") return `${formatNumber(value)} h`;
  return formatNumber(value);
}

function formatCurrency(value, digits = 2) {
  return new Intl.NumberFormat(undefined, { style: "currency", currency: ui.data?.workspace?.currency || "USD", minimumFractionDigits: digits, maximumFractionDigits: digits }).format(Number(value || 0));
}

function formatNumber(value) {
  return new Intl.NumberFormat(undefined, { maximumFractionDigits: 2 }).format(Number(value || 0));
}

function formatDate(value) {
  if (!value) return "Not recorded";
  return new Date(`${value}T12:00:00`).toLocaleDateString([], { month: "short", day: "numeric", year: "numeric" });
}

function formatDateTime(value) {
  if (!value) return "Not recorded";
  return new Date(value).toLocaleString([], { dateStyle: "medium", timeStyle: "short" });
}

function todayLabel() {
  return new Date().toLocaleDateString([], { weekday: "long", month: "long", day: "numeric" });
}

function metricTone(key, value) {
  if (["overdueWorkOrders", "lowStockParts"].includes(key) && value > 0) return "metric-risk";
  if (["preventiveCompliance", "assetAvailability"].includes(key) && value < 80) return "metric-warn";
  return "";
}

function metricIcon(key) {
  return ({ openWorkOrders: "work", overdueWorkOrders: "alert", preventiveCompliance: "calendar", downtimeHours: "clock", maintenanceCost: "cost", lowStockParts: "parts", assetAvailability: "asset" })[key] || "dashboard";
}

function actionIcon(type) {
  if (type.includes("complete") || type.includes("Status")) return "check";
  if (type.includes("Part") || type.includes("part")) return "parts";
  if (type.includes("Meter") || type.includes("meter")) return "meter";
  if (type.includes("Preventive")) return "calendar";
  return "workflow";
}

function activityIcon(entityType) {
  return ({ assets: "asset", workOrders: "work", preventiveSchedules: "calendar", inspections: "inspection", parts: "parts", meterReadings: "meter", workspace: "settings" })[entityType] || "activity";
}

function statusTone(value) {
  const text = String(value || "").toLowerCase();
  if (["emergency", "critical", "down", "fail", "out of stock", "cancelled"].some((item) => text.includes(item))) return "danger";
  if (["high", "waiting", "limited", "conditional", "low stock", "paused", "requested"].some((item) => text.includes(item))) return "warning";
  if (["operational", "completed", "pass", "in stock", "active", "approved"].some((item) => text.includes(item))) return "success";
  if (["in progress", "scheduled", "preventive"].some((item) => text.includes(item))) return "info";
  return "muted";
}

function metadataSummary(metadata = {}) {
  return Object.entries(metadata).slice(0, 4).map(([key, value]) => `${sentenceCase(key)}: ${String(value)}`).join(" · ") || "No additional details";
}

function sentenceCase(value) {
  const text = String(value || "").replace(/([a-z])([A-Z])/g, "$1 $2").replaceAll("_", " ");
  return text.charAt(0).toUpperCase() + text.slice(1);
}

function applyTheme(theme = {}) {
  const root = document.documentElement;
  if (theme.accent) root.style.setProperty("--accent", theme.accent);
  if (theme.accentDark) root.style.setProperty("--nav", theme.accentDark);
  if (theme.highlight) root.style.setProperty("--highlight", theme.highlight);
  if (theme.danger) root.style.setProperty("--danger", theme.danger);
}

function escapeHtml(value) {
  return String(value ?? "").replace(/[&<>"']/g, (char) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#039;" })[char]);
}

function escapeAttr(value) {
  return escapeHtml(value).replace(/`/g, "&#096;");
}

function icon(name) {
  const paths = {
    wrench: "<path d='m14.7 6.3 3-3a4.2 4.2 0 0 0-5.4 5.4L4 17v3h3l8.3-8.3a4.2 4.2 0 0 0 5.4-5.4l-3 3-3-3Z'/>",
    dashboard: "<rect x='3' y='3' width='7' height='7' rx='1'/><rect x='14' y='3' width='7' height='4' rx='1'/><rect x='14' y='11' width='7' height='10' rx='1'/><rect x='3' y='14' width='7' height='7' rx='1'/>",
    table: "<path d='M4 5h16v14H4z'/><path d='M4 10h16M10 5v14'/>",
    asset: "<path d='M5 8h14v10H5z'/><path d='M8 8V5h8v3M8 18v2m8-2v2M3 12h2m14 0h2'/>",
    work: "<path d='M4 7h16v13H4z'/><path d='M9 7V4h6v3M4 12h16M10 12v2h4v-2'/>",
    calendar: "<rect x='3' y='5' width='18' height='16' rx='2'/><path d='M16 3v4M8 3v4M3 10h18M8 14h2M14 14h2M8 18h2'/>",
    inspection: "<path d='M9 5h6l1 2h3v14H5V7h3l1-2Z'/><path d='m8 14 2 2 5-5'/>",
    parts: "<path d='M12 2v6M4.2 6.5l5.2 3M4.2 17.5l5.2-3M12 22v-6m7.8 1.5-5.2-3m5.2-8-5.2 3'/><circle cx='12' cy='12' r='4'/>",
    meter: "<path d='M4 18a8 8 0 1 1 16 0'/><path d='m12 15 4-5M6 18h12'/>",
    activity: "<path d='M3 12h4l2-7 4 14 2-7h6'/>",
    settings: "<circle cx='12' cy='12' r='3'/><path d='M19 12a7 7 0 0 0-.1-1l2-1.5-2-3.4-2.4 1a7 7 0 0 0-1.8-1L12.4 3H8.6l-.4 3a7 7 0 0 0-1.8 1L4 6 2 9.5 4 11a7 7 0 0 0 0 2l-2 1.5L4 18l2.4-1a7 7 0 0 0 1.8 1l.4 3h3.8l.4-3a7 7 0 0 0 1.8-1l2.4 1 2-3.5-2-1.5c.1-.3.1-.6.1-1Z'/>",
    download: "<path d='M12 3v12m-5-5 5 5 5-5M5 21h14'/>",
    upload: "<path d='M12 21V9m-5 5 5-5 5 5M5 3h14'/>",
    plus: "<path d='M12 5v14M5 12h14'/>",
    edit: "<path d='M4 20h4L19 9l-4-4L4 16v4Zm9-13 4 4'/>",
    archive: "<path d='M4 7h16M6 7v13h12V7M9 11h6M5 4h14v3H5z'/>",
    refresh: "<path d='M20 12a8 8 0 0 1-14 5M4 17h6v-6M4 12A8 8 0 0 1 18 7m2 0h-6v6'/>",
    check: "<path d='m5 12 4 4L19 6'/>",
    save: "<path d='M5 4h12l2 2v14H5zM8 4v6h8V4M8 20v-6h8v6'/>",
    close: "<path d='m6 6 12 12m0-12L6 18'/>",
    search: "<circle cx='11' cy='11' r='7'/><path d='m20 20-4-4'/>",
    arrow: "<path d='M5 12h14m-5-5 5 5-5 5'/>",
    external: "<path d='M14 4h6v6m0-6-9 9'/><path d='M19 13v7H4V5h7'/>",
    alert: "<path d='M12 3 2 21h20L12 3Zm0 6v5m0 3v.1'/>",
    clock: "<circle cx='12' cy='12' r='9'/><path d='M12 7v5l3 2'/>",
    cost: "<circle cx='12' cy='12' r='9'/><path d='M15 8.5c-.6-.7-1.5-1-3-1-1.7 0-3 .8-3 2s1 1.8 3 2.2 3 1 3 2.3-1.3 2.2-3 2.2c-1.5 0-2.7-.4-3.4-1.2M12 5v14'/>",
    workflow: "<path d='M6 4v10a4 4 0 0 0 4 4h8'/><path d='m14 14 4 4-4 4'/>"
  };
  return `<svg viewBox="0 0 24 24" aria-hidden="true" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">${paths[name] || paths.table}</svg>`;
}
