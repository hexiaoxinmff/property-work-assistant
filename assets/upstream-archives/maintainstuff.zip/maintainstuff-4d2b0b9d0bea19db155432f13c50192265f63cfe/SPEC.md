# MaintainStuff product specification

## Product position

MaintainStuff is a free, self-hosted alternative to UpKeep, MaintainX, Fiix, and similar computerized maintenance management systems (CMMS).

Commercial CMMS products commonly charge per technician, reserve historical exports and analytics for premium tiers, and make full-fidelity workspace restoration difficult. Maintenance history, preventive schedules, inspection results, meter readings, downtime, and parts usage are operational records that facilities should own outright.

**Anti-lock-in headline: Own every asset, work order, maintenance interval, and service record—without per-technician or export fees.**

## Users and exact workflows

### Maintenance planner

1. Configure the organization, sites, default labor rate, criticality policy, and work-order numbering convention.
2. Create, edit, search, filter, sort, inspect, archive, and restore assets with site, location, category, owner, criticality, status, serial number, install date, meter value, warranty date, and documentation URI.
3. Create corrective or preventive work orders, assign priority and technician, schedule due dates, estimate hours/cost, link an asset, and control requested, approved, scheduled, or cancelled planning states. Execution states remain technician actions.
4. Build preventive-maintenance schedules by calendar interval or meter threshold and record the next due date/value.
5. Review overdue work, downtime, maintenance cost, preventive compliance, low-stock parts, and asset availability from computed dashboard data.

### Technician

1. Filter assigned, scheduled, overdue, or high-priority work.
2. Start work, record labor, findings, completion notes, downtime, meter readings, evidence, and parts used.
3. Complete a work order only after required fields are present; the action persists and creates an actor-attributed audit event.
4. Submit inspection results and raise follow-up work when a check fails.

### Storeroom

1. Maintain parts, on-hand quantity, reorder point, unit cost, supplier, storage location, and status.
2. Issue or restock parts with validated nonnegative inventory and auditable history.
3. Export the parts collection in open JSON/CSV formats without gaining maintenance-planning or work-execution authority.

### Maintenance manager / administrator

1. Operate every collection and workflow when covering another role.
2. Import/export the full workspace or individual collections in open JSON/CSV formats.
3. Manage workspace policy and deployment-facing operating settings.

## Data model

- `session`: local user ID, display name, and role.
- `workspace`: organization, sites, default labor rate, criticality policy, work-order convention, timestamps.
- `assets`: ID, name, asset tag, site, location, category, manufacturer, model, serial, owner, criticality, status, install date, warranty date, meter value/unit, documentation URI, timestamps, archive state.
- `workOrders`: ID, number, title, asset relation, work type, priority, status, requester, technician, requested date, due date, started/completed dates, estimated/actual hours, labor cost, parts cost, downtime hours, findings, resolution, evidence URI, timestamps, archive state.
- `preventiveSchedules`: ID, name, asset relation, trigger type, interval days, meter interval, last/next due date, last/next meter, owner, status, procedure, timestamps, archive state.
- `inspections`: ID, work-order relation, asset relation, template, inspector, inspection date, result, score, failed checks, notes, evidence URI, timestamps, archive state.
- `parts`: ID, SKU, name, category, site, bin, supplier, on-hand, reorder point, unit cost, status, timestamps, archive state.
- `meterReadings`: ID, asset relation, reading date, value, unit, source, recorded by, notes, timestamps, archive state.
- `activity`: immutable event ID, actor, action, entity type, entity ID, metadata, created timestamp; durable history is never truncated or replaced by import.

Relations must resolve to active records. Quantities, money, hours, scores, and meters reject invalid negative or non-finite values. Stable IDs, timestamps, and archive state preserve service history.

## Must-have screens

- Maintenance control center with computed open/overdue work, preventive compliance, downtime, cost, low-stock, and asset-status metrics.
- Asset registry and asset detail/history inspector.
- Work-order planning and technician workbench with search, filters, sorting, editing, archive/restore, and workflow actions.
- Preventive schedule, inspection, parts, and meter-reading workbenches.
- Activity history, settings, and import/export controls.
- Useful loading, empty, validation, and error states at 1280px desktop and 390px mobile.

## Local and self-hosted behavior

- Runs on Node.js 24+ with no external CMMS, identity provider, or paid credential required.
- Persists data durably using atomic local writes and a configurable data path.
- Supports unlimited assets, technicians, work orders, schedules, inspections, parts, readings, sites, and activity history; complete imports default to a configurable 100 MiB request limit.
- Includes realistic replaceable seed data plus complete JSON workspace backup/restore and collection JSON/CSV exports.
- Ships with an MIT license and documents reverse-proxy authentication plus transactional/multi-writer deployment options.

## Acceptance criteria

- Every core collection supports create, view, edit, search, filter, sort, detail inspection, archive, restore, JSON export, and CSV export; screen exports honor the current result set.
- UI and API share one exact role contract: planners plan, technicians execute, storeroom operators control parts, and managers/administrators have complete authority.
- Server-side validation covers required fields, numbers/ranges, dates, URLs/paths, statuses, and active relationships.
- Work-order start/complete, preventive scheduling, inspection follow-up, meter update, and part stock actions persist and append audit entries.
- Completing work records actual labor/cost/downtime and updates meaningful computed analytics; metrics are never hard-coded.
- Low-stock and overdue states derive from stored values and current dates.
- Workspace import requires explicit destructive confirmation, a nonempty audit ledger, globally unique stock-operation keys, complete active/archived graph validation, preservation of existing activity, and a new import event.
- No visible navigation or action is dead; consequential actions provide explicit feedback.
- Browser QA verifies at least one persisted work-order action, clean console, and overflow-free 1280px/390px layouts.
- Focused tests cover workflow transitions, numeric validation, analytics, exports, persistence, and API mutations.
- README documents setup, architecture, scripts, capabilities, storage, backup/restore, and deployment.

## Validation commands

```bash
npm install
npm run typecheck
npm run lint
npm test
npm run build
npm run secret-scan
```

Also run unfinished-marker, credential/private-key, and embedded-secret scans plus rendered workflow and responsive checks.

## GitHub publishing expectations

After validation and a clean secret scan, initialize a standalone repository, set `JoshuaStorm1017 <JoshuaStorm1017@gmail.com>` locally, commit the complete product, create public `JoshuaStorm1017/maintainstuff` if absent, push `main`, verify public visibility and upstream tracking, and leave the worktree clean.
