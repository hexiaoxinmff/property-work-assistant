# MaintainStuff

MaintainStuff is a free, self-hosted computerized maintenance management system for teams that need reliable asset history without per-technician pricing or export restrictions. It replaces the core workflows of UpKeep, MaintainX, Fiix, and similar paid CMMS products with durable local persistence and open JSON/CSV data exits.

**Own every asset, work order, maintenance interval, and service record—without per-technician or export fees.**

## What it does

- Maintains an unlimited asset registry with tags, sites, locations, owners, criticality, operating state, warranty dates, documentation, and live meter values.
- Plans corrective, preventive, inspection, calibration, and safety work through requested, approved, scheduled, in-progress, waiting, completed, and cancelled states.
- Generates sequential work-order numbers, attributes every event to the active operator, and preserves the complete append-only activity ledger without truncation.
- Calculates labor from the workspace rate, issues parts against work, rolls up actual parts cost, records findings/evidence/downtime, and requires completion notes.
- Runs calendar, meter, or combined preventive plans; prevents duplicate open PM work and advances the next due thresholds only after completion.
- Records scored inspections and turns conditional or failed findings into traceable corrective work.
- Controls storeroom quantities, derived low/out-of-stock status, reorder exposure, receipt costs, suppliers, sites, and bins; workspace-wide operation keys make part-issue retries idempotent even after work closes.
- Preserves monotonic meter history and prevents older readings from rolling an asset backward.
- Computes open and overdue work, PM compliance, downtime, maintenance cost, low-stock exposure, asset availability, alerts, and a ranked work queue from stored records.
- Supports full create/view/edit/search/filter/sort/detail/archive/restore workflows for every core collection.
- Exports complete or UI-filtered collections as JSON/CSV and performs all-or-nothing validation before a complete workspace restore.

## Run locally

Requirements: Node.js 24 or newer. The core app has no third-party runtime packages and requires no cloud credentials.

```bash
npm install
npm run dev
```

Open [http://127.0.0.1:4221](http://127.0.0.1:4221). The first request creates a realistic Harborline Components workspace in `data/maintainstuff.json`.

To use a different data location or import limit (100 MiB by default):

```bash
MAINTAINSTUFF_DATA=/absolute/path/maintenance.json npm start
MAINTAINSTUFF_MAX_IMPORT_MB=250 npm start
```

You can also set `PORT` and `HOST`. The default bind address is `127.0.0.1`, which keeps the server local unless you intentionally expose it.

## Core operating flows

### Execute a work order

1. Create work from the Work Orders page and link an active asset.
2. Approve/schedule it or start work directly when policy allows.
3. Issue stocked parts; inventory and actual parts cost update together.
4. Complete the work with labor hours, downtime, findings, resolution, and optional evidence URI.
5. MaintainStuff calculates labor cost, advances a linked PM plan, updates the asset when no other open work remains, recomputes analytics, and records audit events.

### Run preventive maintenance

Create a calendar, meter, or combined plan with accountable next-due thresholds. “Generate work order” refuses to create a second active work order for the same plan. Completing the generated work advances the schedule from the actual completion date and current asset meter.

### Recover failed inspections

Record an inspection result and its failed checks. Conditional and failed inspections expose “Raise follow-up work,” which creates one linked corrective/safety work order with findings, priority, owner, due date, and evidence carried forward.

### Back up and restore

Use **Settings & data → Export complete workspace** before upgrades or migrations. The JSON contains workspace policy, local session, every active/archived record, relationships, parts usage, and complete activity history. Import requires a matching product and schema plus a nonempty audit ledger; it validates safe IDs, timestamps, every active and archived relation graph, meter history, canonical costs/statuses, globally unique stock-operation keys, and activity shape before replacing operational records. The UI requires explicit destructive confirmation. Existing durable activity is merged and conflicting event IDs are rejected, so restore cannot erase or rewrite recorded history. Request bodies default to 100 MiB and can be adjusted with `MAINTAINSTUFF_MAX_IMPORT_MB`.

Collection-level API exports include archived records by default so historical data remains portable; exports launched from a collection screen honor its active/archived, search, filter, and sort state. Formula-like CSV text is escaped even when preceded by whitespace or a byte-order mark.

## Architecture

MaintainStuff is intentionally small and inspectable:

- `server/config.js` defines the CMMS schema, fields, filters, workflows, metrics, and replaceable seed data.
- `server/domain.js` owns validation, entity lifecycle, dependency checks, workflow transactions, analytics, imports, and exports.
- `server/store.js` provides atomic write-then-rename persistence.
- `server/routes.js` exposes the JSON API, serializes mutations to prevent lost updates, enforces same-origin JSON mutations and server-side roles, rejects malformed/oversized JSON, and serves downloads.
- `server/index.js` serves the browser application with path containment and defensive HTTP headers.
- `public/contracts.js` is the shared browser/server permission, search, and ordering contract; `public/app.js` contains the responsive operator interface with no frontend build dependency.
- `tests/` covers domain rules, API persistence, concurrent writes, security boundaries, analytics, and cross-entity workflows.

The JSON store is a strong fit for a single Node process and local/server deployments with one writer. For clustered processes or sustained concurrent multi-host use, keep the domain layer and replace `server/store.js` with a transactional database adapter.

## Identity, roles, and internet deployment

The default local session is a trusted-machine convenience, not an authentication system: anyone with same-origin browser access or data-file access can select a local operator and role. Local role checks are workflow guardrails, not a security boundary. Browser mutations must be same-origin and use the exact `application/json` media type (parameters such as `charset=utf-8` are accepted).

The same permission contract controls visible UI actions and API authorization:

| Role | Authority |
| --- | --- |
| Maintenance manager / Administrator | All collections, workflow actions, workspace policy, complete backup/restore, and collection exports. |
| Planner | Asset, work-order, and preventive-plan CRUD/lifecycle; planning actions; workspace policy; every collection export. No execution, stock mutation, or complete restore. |
| Technician | Inspection and meter CRUD; work execution, inspection follow-up, meter application, and issue-to-work; work-order/inspection/meter exports. |
| Storeroom | Part CRUD/lifecycle, restock/issue/issue-to-work, and part export only. |

For internet access, terminate TLS and authenticate at a reverse proxy or private access gateway. Keep the Node service on an internal interface and have the proxy strip client-supplied identity headers. Then opt in explicitly:

```bash
MAINTAINSTUFF_TRUST_PROXY_IDENTITY=true npm start
```

Every API request must then include valid `X-MaintainStuff-User` and `X-MaintainStuff-Role` headers; missing or invalid identity fails closed. `X-Forwarded-Host` and `X-Forwarded-Proto` are trusted only in this mode for origin validation. Local session changes are disabled while proxy identity is active. Never enable this mode on a port reachable without the trusted proxy.

Static responses include a content-security policy, frame protection, content-type protection, and a no-referrer policy. API responses and downloads are marked `no-store`. These controls complement, but do not replace, proxy authentication, TLS, network isolation, and data-file permissions.

## Validation

```bash
npm run typecheck
npm run lint
npm test
npm run build
npm run secret-scan
```

`npm run build` performs syntax and unfinished-marker checks before copying the deployable server and browser files to `dist/`. `npm run secret-scan` looks for common private-key, token, and credential-bearing URL patterns. The test suite also verifies formula-safe CSV, malformed/oversized request handling, path-safe static serving, serialized mutation writes, validated import, and reference-safe archive/restore.

## API overview

- `GET /api/state` — complete shaped workspace and computed analytics
- `POST /api/:collection` — create a validated record
- `PATCH /api/:collection/:id` — edit a record
- `POST /api/:collection/:id/archive` and `/restore` — relation-safe lifecycle controls
- `POST /api/actions/:action` — maintenance workflow action
- `PATCH /api/workspace` and `/api/session` — operating policy and local audit identity
- `GET /api/export/all.json` — complete backup
- `GET /api/export/:collection.json|csv` — collection export
- `POST /api/import` — validate and restore a complete backup

See `SPEC.md` for the full product contract and acceptance criteria.

## License

MIT © 2026 JoshuaStorm1017
