import { cp, mkdir, rm, stat, writeFile } from "node:fs/promises";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { APP_CONFIG } from "../server/config.js";

const rootDir = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const distDir = path.join(rootDir, "dist");
const manifest = {
  product: APP_CONFIG.slug,
  builtAt: new Date().toISOString(),
  publicFiles: ["index.html", "styles.css", "app.js", "contracts.js"],
  collections: APP_CONFIG.collections.map((collection) => collection.key),
  api: ["/api/state", "/api/export/all.json", "/api/import", "/api/workspace", "/api/session", "/api/actions/:action"]
};

await rm(distDir, { recursive: true, force: true });
await mkdir(distDir, { recursive: true });
for (const entry of ["public", "server", "scripts", "tests", "package.json", "package-lock.json", "README.md", "SPEC.md", "LICENSE", ".gitignore"]) {
  const source = path.join(rootDir, entry);
  try {
    await stat(source);
    await cp(source, path.join(distDir, entry), { recursive: true });
  } catch (error) {
    if (error.code !== "ENOENT") throw error;
  }
}
await writeFile(path.join(distDir, "build-manifest.json"), `${JSON.stringify(manifest, null, 2)}\n`);
console.log(`${APP_CONFIG.name} deployable build written to dist/.`);
