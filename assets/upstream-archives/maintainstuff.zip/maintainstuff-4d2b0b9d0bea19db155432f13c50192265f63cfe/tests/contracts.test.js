import assert from "node:assert/strict";
import test from "node:test";
import { APP_CONFIG } from "../server/config.js";
import { createDefaultState } from "../server/domain.js";
import {
  compareMeterRecords,
  compareRecords,
  recordSearchText,
  roleCan,
  roleCanAction,
  roleCanCollection
} from "../public/contracts.js";

test("shared role contract matches the four operational personas", () => {
  assert.equal(roleCan("Planner", "workspace"), true);
  assert.equal(roleCanCollection("Planner", "create", "workOrders"), true);
  assert.equal(roleCanCollection("Planner", "create", "parts"), false);
  assert.equal(roleCanCollection("Technician", "create", "inspections"), true);
  assert.equal(roleCanAction("Technician", "start-work-order"), true);
  assert.equal(roleCanAction("Storeroom", "start-work-order"), false);
  assert.equal(roleCanCollection("Storeroom", "edit", "parts"), true);
  assert.equal(roleCanCollection("Storeroom", "export", "workOrders"), false);
  assert.equal(roleCan("Maintenance manager", "fullData"), true);
  assert.equal(roleCan("Administrator", "fullData"), true);
});

test("shared search and ranked sorting are deterministic for UI and exports", () => {
  const state = createDefaultState();
  const work = state.workOrders.find((row) => row.assetId === "ast_compressor_7");
  const search = recordSearchText(state, APP_CONFIG.collections, work).toLowerCase();
  assert.match(search, /air compressor ac-7/);
  assert.doesNotMatch(search, /utility mezzanine/);

  const rows = [
    { id: "medium", priority: "Medium" },
    { id: "emergency", priority: "Emergency" },
    { id: "high", priority: "High" }
  ].sort((left, right) => compareRecords(left, right, "priority", "desc"));
  assert.deepEqual(rows.map((row) => row.priority), ["Emergency", "High", "Medium"]);
});

test("shared meter ordering resolves exact timestamps by stable id", () => {
  const common = { readingDate: "2026-07-16", createdAt: "2026-07-16T12:00:00.000Z" };
  const rows = [{ ...common, id: "mtr_exact_a" }, { ...common, id: "mtr_exact_z" }]
    .sort((left, right) => compareMeterRecords(right, left));
  assert.equal(rows[0].id, "mtr_exact_z");
});
