import assert from "node:assert/strict";
import test from "node:test";
import { APP_CONFIG } from "../server/config.js";
import {
  applyWorkflowAction,
  addActivity,
  addDays as domainAddDays,
  archiveEntity,
  createDefaultState,
  createEntity,
  exportSnapshot,
  importSnapshot,
  restoreEntity,
  shapeState,
  todayIso,
  toCsv,
  updateEntity,
  updateSession,
  updateWorkspace
} from "../server/domain.js";

test("seed analytics are computed from maintenance records", () => {
  const state = createDefaultState();
  const analytics = shapeState(state).analytics;
  const open = state.workOrders.filter((row) => !row.archivedAt && !["Completed", "Cancelled"].includes(row.status));
  const overdue = open.filter((row) => row.dueDate < todayIso());
  const cost = state.workOrders.reduce((sum, row) => sum + row.laborCost + row.partsCost, 0);
  const lowStock = state.parts.filter((row) => row.status !== "Discontinued" && row.onHand <= row.reorderPoint);
  assert.equal(analytics.metrics.openWorkOrders, open.length);
  assert.equal(analytics.metrics.overdueWorkOrders, overdue.length);
  assert.equal(analytics.metrics.maintenanceCost, cost);
  assert.equal(analytics.metrics.lowStockParts, lowStock.length);
  assert.equal(Object.keys(analytics.metrics).length, APP_CONFIG.metrics.length);
  assert.ok(analytics.priorityQueue.length > 0);
  assert.ok(Array.isArray(analytics.alerts));
});

test("entity validation rejects invalid ranges, options, sites, and relations", () => {
  const state = createDefaultState();
  const negativePart = createEntity(state, "parts", {
    sku: "BAD-NEGATIVE",
    name: "Invalid stock",
    onHand: -1,
    reorderPoint: 2,
    category: "Mechanical",
    site: "Detroit Plant",
    bin: "M-1",
    supplier: "Local",
    unitCost: 4
  });
  assert.equal(negativePart.ok, false);
  assert.match(negativePart.errors.join(" "), /at least 0/);

  const badInspection = createEntity(state, "inspections", {
    template: "Unsafe score",
    assetId: "ast_compressor_7",
    workOrderId: "",
    followUpWorkOrderId: "",
    inspector: "Avery Morgan",
    inspectionDate: todayIso(),
    result: "Pass",
    score: 101,
    failedChecks: "",
    notes: "",
    evidenceUri: ""
  });
  assert.equal(badInspection.ok, false);
  assert.match(badInspection.errors.join(" "), /no more than 100/);

  const badDate = createEntity(state, "workOrders", makeWorkOrder({ requestedDate: "2026-02-31", dueDate: "2026-03-02" }));
  assert.equal(badDate.ok, false);
  assert.match(badDate.errors.join(" "), /valid date/);

  const badWork = createEntity(state, "workOrders", makeWorkOrder({ assetId: "ast_unknown" }));
  assert.equal(badWork.ok, false);
  assert.match(badWork.errors.join(" "), /active asset/);

  const badAsset = createEntity(state, "assets", {
    ...state.assets[0],
    id: undefined,
    assetTag: "REMOTE-001",
    site: "Unknown site",
    meterValue: Number.NaN
  });
  assert.equal(badAsset.ok, false);
  assert.match(badAsset.errors.join(" "), /workspace option|finite number/);
});

test("work orders receive durable sequential numbers", () => {
  const state = createDefaultState();
  const result = createEntity(state, "workOrders", makeWorkOrder({ title: "Inspect cooling fan" }));
  assert.equal(result.ok, true);
  const created = state.workOrders.at(-1);
  assert.equal(created.number, "MNT-1047");
  assert.equal(state.workspace.nextWorkOrderNumber, 1048);
  assert.deepEqual(created.partsUsed, []);
  assert.equal(result.status, 201);
  const bypass = updateEntity(state, "workOrders", created.id, { status: "Completed", laborCost: 1 });
  assert.equal(bypass.ok, false);
  assert.equal(created.status, "Requested");
  assert.equal(created.laborCost, 0);
});

test("technician workflow updates inventory, costs, asset state, and audit history", () => {
  const state = createDefaultState();
  assert.equal(createEntity(state, "workOrders", makeWorkOrder({ title: "Replace drive belts" })).ok, true);
  const work = state.workOrders.at(-1);
  assert.equal(applyWorkflowAction(state, "start-work-order", { id: work.id }).ok, true);
  assert.equal(work.status, "In progress");
  assert.ok(work.startedDate);
  assert.equal(applyWorkflowAction(state, "hold-work-order", { id: work.id, resolution: "Waiting for lockout window." }).ok, true);
  assert.equal(work.status, "Waiting");
  assert.equal(applyWorkflowAction(state, "start-work-order", { id: work.id }).ok, true);

  const part = state.parts.find((row) => row.id === "prt_vbelt_b62");
  const stockBefore = part.onHand;
  const issued = applyWorkflowAction(state, "issue-part-to-work", { id: work.id, partId: part.id, quantity: 2, operationKey: "issue-belts-1" });
  assert.equal(issued.ok, true);
  assert.equal(part.onHand, stockBefore - 2);
  assert.equal(work.partsCost, 69.5);
  assert.equal(work.partsUsed.length, 1);

  const completed = applyWorkflowAction(state, "complete-work-order", {
    id: work.id,
    actualHours: 2.5,
    downtimeHours: 1.25,
    findings: "Matched belts were glazed.",
    resolution: "Installed and tensioned a matched belt pair.",
    evidenceUri: "/evidence/belt-repair"
  });
  assert.equal(completed.ok, true);
  assert.equal(work.status, "Completed");
  assert.equal(work.laborCost, 237.5);
  assert.equal(work.downtimeHours, 1.25);
  assert.ok(state.activity.some((row) => row.action === "completed work order" && row.entityId === work.id));
  assert.equal(shapeState(state).analytics.metrics.maintenanceCost, 807.5);
});

test("preventive work generation prevents duplicates and completion advances both triggers", () => {
  const state = createDefaultState();
  const schedule = state.preventiveSchedules.find((row) => row.id === "pm_packaging_weekly");
  const generated = applyWorkflowAction(state, "generate-pm-work", { id: schedule.id });
  assert.equal(generated.ok, true);
  const work = state.workOrders.at(-1);
  assert.equal(work.preventiveScheduleId, schedule.id);
  assert.equal(work.workType, "Preventive");
  const countAfterGenerate = state.workOrders.length;
  assert.equal(applyWorkflowAction(state, "generate-pm-work", { id: schedule.id }).ok, true);
  assert.equal(state.workOrders.length, countAfterGenerate);

  assert.equal(applyWorkflowAction(state, "start-work-order", { id: work.id }).ok, true);

  const completed = applyWorkflowAction(state, "complete-work-order", {
    id: work.id,
    actualHours: 1.5,
    downtimeHours: 0.5,
    findings: "Guarding verified after corrective work.",
    resolution: "All guards and interlocks passed functional challenge.",
    evidenceUri: "/evidence/packaging-pm"
  });
  assert.equal(completed.ok, true);
  assert.equal(schedule.lastDueDate, todayIso());
  assert.equal(schedule.nextDueDate, addDays(todayIso(), 7));
  assert.equal(schedule.lastMeter, 412840);
  assert.equal(schedule.nextMeter, 422840);
});

test("failed inspections create one traceable corrective work order", () => {
  const state = createDefaultState();
  const inspection = state.inspections.find((row) => row.id === "ins_pack_guard");
  const result = applyWorkflowAction(state, "raise-inspection-follow-up", { id: inspection.id });
  assert.equal(result.ok, true);
  const work = state.workOrders.find((row) => row.id === inspection.followUpWorkOrderId);
  assert.ok(work);
  assert.equal(work.priority, "Emergency");
  assert.equal(work.status, "Requested");
  assert.match(work.findings, /guard/i);
  const countAfterFollowUp = state.workOrders.length;
  assert.equal(applyWorkflowAction(state, "raise-inspection-follow-up", { id: inspection.id }).ok, true);
  assert.equal(state.workOrders.length, countAfterFollowUp);
});

test("meter readings advance assets without permitting rollback", () => {
  const state = createDefaultState();
  const asset = state.assets.find((row) => row.id === "ast_compressor_7");
  const latestDate = state.meterReadings.filter((row) => row.assetId === asset.id).map((row) => row.readingDate).sort().at(-1);
  const readingDate = addDays(latestDate > todayIso() ? latestDate : todayIso(), 1);
  const advancedValue = asset.meterValue + 5;
  const created = createEntity(state, "meterReadings", {
    assetId: asset.id,
    value: advancedValue,
    unit: asset.meterUnit,
    readingDate,
    source: "Manual",
    recordedBy: "Avery Morgan",
    notes: "End-of-shift reading."
  });
  assert.equal(created.ok, true);
  assert.equal(asset.meterValue, advancedValue);

  const rollback = createEntity(state, "meterReadings", {
    assetId: asset.id,
    value: advancedValue - 1,
    unit: asset.meterUnit,
    readingDate: addDays(readingDate, 1),
    source: "Manual",
    recordedBy: "Avery Morgan",
    notes: "Incorrect lower reading."
  });
  assert.equal(rollback.ok, false);
  assert.match(rollback.errors.join(" "), /cannot roll|cannot be below/);
  assert.equal(applyWorkflowAction(state, "apply-meter-reading", { id: "mtr_comp_0715" }).ok, false);
});

test("archive and restore preserve history while protecting active references", () => {
  const state = createDefaultState();
  const blocked = archiveEntity(state, "assets", "ast_compressor_7");
  assert.equal(blocked.ok, false);
  assert.match(blocked.errors.join(" "), /references it/);

  const partResult = createEntity(state, "parts", {
    sku: "TEST-SPARE-001",
    name: "Unassigned test spare",
    onHand: 3,
    reorderPoint: 1,
    category: "Mechanical",
    site: "Detroit Plant",
    bin: "T-01",
    supplier: "Local machine shop",
    unitCost: 12.5
  });
  assert.equal(partResult.ok, true);
  const part = state.parts.at(-1);
  assert.equal(archiveEntity(state, "parts", part.id).ok, true);
  assert.ok(part.archivedAt);
  assert.equal(restoreEntity(state, "parts", part.id).ok, true);
  assert.equal(part.archivedAt, null);
});

test("workspace import validates the entire relation graph before replacement", () => {
  const state = createDefaultState();
  const snapshot = exportSnapshot(state);
  snapshot.workOrders[0].assetId = "ast_missing";
  const invalid = importSnapshot(state, snapshot);
  assert.equal(invalid.ok, false);
  assert.match(invalid.errors.join(" "), /active asset/);
  assert.equal(state.workOrders[0].assetId, "ast_compressor_7");

  const valid = exportSnapshot(state);
  valid.workspace.organizationName = "Imported Maintenance Operations";
  const imported = importSnapshot(state, valid);
  assert.equal(imported.ok, true);
  assert.equal(state.workspace.organizationName, "Imported Maintenance Operations");
  assert.equal(state.activity[0].action, "imported workspace snapshot");
});

test("workspace settings protect assigned sites and exports remain open and safe", () => {
  const state = createDefaultState();
  const blocked = updateWorkspace(state, { ...state.workspace, sites: ["Detroit Plant"] });
  assert.equal(blocked.ok, false);
  assert.match(blocked.errors.join(" "), /Ann Arbor Warehouse/);
  const updated = updateWorkspace(state, { ...state.workspace, organizationName: "Harborline Reliability" });
  assert.equal(updated.ok, true);
  assert.equal(state.activity[0].action, "updated workspace settings");
  assert.equal(updateSession(state, { userName: "Jordan Kim", role: "Technician" }).ok, true);
  assert.equal(state.session.userName, "Jordan Kim");
  assert.equal(state.activity[0].actor, "Jordan Kim");

  const csv = toCsv([{ name: "=2+2", note: "portable" }]);
  assert.match(csv, /'=2\+2/);
  assert.match(csv, /name,note/);
  const snapshot = exportSnapshot(state);
  assert.equal(snapshot.product, "maintainstuff");
  assert.equal(snapshot.schemaVersion, 1);
});

test("activity is append-only, untruncated, and conflicting imported history is rejected", () => {
  const state = createDefaultState();
  const originalIds = new Set(state.activity.map((event) => event.id));
  for (let index = 0; index < 600; index += 1) addActivity(state, `retention event ${index}`, "workspace", state.workspace.id);
  assert.equal(state.activity.length, 605);
  assert.equal(shapeState(state).analytics.activity.length, 605);

  const backup = exportSnapshot(state);
  backup.activity = [];
  const emptyLedger = importSnapshot(state, backup);
  assert.equal(emptyLedger.ok, false);
  assert.match(emptyLedger.errors.join(" "), /at least one durable event/);
  for (const id of originalIds) assert.ok(state.activity.some((event) => event.id === id));

  const olderBackup = exportSnapshot(state);
  olderBackup.activity = olderBackup.activity.slice(-1);
  assert.equal(importSnapshot(state, olderBackup).ok, true);
  for (const id of originalIds) assert.ok(state.activity.some((event) => event.id === id));

  const conflict = exportSnapshot(state);
  conflict.activity[0].actor = "Forged actor";
  assert.equal(importSnapshot(state, conflict).ok, false);
  assert.match(importSnapshot(state, conflict).errors.join(" "), /conflicts with durable history/);
});

test("imports validate archived graphs and identifiers while recomputing canonical values", () => {
  const state = createDefaultState();
  const unsafe = exportSnapshot(state);
  unsafe.parts[0].id = `bad\"><img`;
  assert.equal(importSnapshot(state, unsafe).ok, false);

  const archived = exportSnapshot(state);
  archived.workOrders.push({
    ...archived.workOrders[0],
    id: "archived_broken",
    number: "MNT-ARCHIVED",
    assetId: "missing_asset",
    archivedAt: "2026-07-16T00:00:00.000Z"
  });
  assert.equal(importSnapshot(state, archived).ok, false);
  assert.match(importSnapshot(state, archived).errors.join(" "), /existing asset/);

  const canonical = exportSnapshot(state);
  const completed = canonical.workOrders.find((row) => row.status === "Completed");
  completed.laborCost = 999999999;
  completed.partsCost = 888888888;
  canonical.parts.find((row) => row.id === "prt_guard_switch").status = "Discontinued";
  assert.equal(importSnapshot(state, canonical).ok, true);
  const restored = state.workOrders.find((row) => row.id === completed.id);
  assert.equal(restored.laborCost, 332.5);
  assert.equal(restored.partsCost, 168);
  assert.equal(state.parts.find((row) => row.id === "prt_guard_switch").status, "Out of stock");
});

test("part issue operation keys prevent replay and preserve canonical cost", () => {
  const state = createDefaultState();
  const work = state.workOrders.find((row) => row.id === "wo_compressor_leak");
  const part = state.parts.find((row) => row.id === "prt_vbelt_b62");
  const before = part.onHand;
  const legacyCollision = applyWorkflowAction(state, "issue-part-to-work", {
    id: work.id,
    partId: part.id,
    quantity: 1,
    operationKey: "legacy:wo_compressor_filter:0"
  });
  assert.equal(legacyCollision.ok, false);
  assert.match(legacyCollision.errors.join(" "), /already used/);
  assert.equal(part.onHand, before);

  const payload = { id: work.id, partId: part.id, quantity: 2, operationKey: "retry-safe-issue" };
  assert.equal(applyWorkflowAction(state, "issue-part-to-work", payload).ok, true);
  assert.equal(applyWorkflowAction(state, "issue-part-to-work", payload).ok, true);
  assert.equal(part.onHand, before - 2);
  assert.equal(work.partsUsed.filter((usage) => usage.operationKey === payload.operationKey).length, 1);
  assert.equal(work.partsCost, 69.5);
  assert.equal(applyWorkflowAction(state, "issue-part-to-work", { ...payload, quantity: 1 }).ok, false);

  const completion = applyWorkflowAction(state, "complete-work-order", {
    id: work.id,
    actualHours: 2,
    downtimeHours: 1,
    findings: "Belt inspected during repair.",
    resolution: "Repair completed and verified.",
    evidenceUri: ""
  });
  assert.equal(completion.ok, true);
  const activityCount = state.activity.length;
  assert.equal(applyWorkflowAction(state, "issue-part-to-work", payload).ok, true);
  assert.equal(part.onHand, before - 2);
  assert.equal(state.activity.length, activityCount);

  part.archivedAt = "2026-07-16T00:00:00.000Z";
  assert.equal(applyWorkflowAction(state, "issue-part-to-work", payload).ok, true);
  assert.equal(part.onHand, before - 2);
  assert.equal(state.activity.length, activityCount);

  const selfBackup = exportSnapshot(state);
  const historical = selfBackup.workOrders.find((row) => row.id === "wo_compressor_filter").partsUsed[0];
  assert.equal(historical.operationKey, "legacy:wo_compressor_filter:0");
  assert.equal(importSnapshot(state, selfBackup).ok, true);

  const duplicateSnapshot = exportSnapshot(state);
  const otherWork = duplicateSnapshot.workOrders.find((row) => row.id !== work.id);
  otherWork.partsUsed.push({ ...work.partsUsed[0] });
  assert.equal(importSnapshot(state, duplicateSnapshot).ok, false);
  assert.match(importSnapshot(state, duplicateSnapshot).errors.join(" "), /duplicated across the workspace/);
});

test("workflow completion requires a started work order", () => {
  const state = createDefaultState();
  const work = state.workOrders.find((row) => row.id === "wo_boiler_pm");
  const completion = { id: work.id, actualHours: 1, downtimeHours: 0, findings: "", resolution: "Completed", evidenceUri: "" };
  assert.equal(applyWorkflowAction(state, "complete-work-order", completion).ok, false);
  assert.equal(work.status, "Scheduled");
  assert.equal(applyWorkflowAction(state, "start-work-order", { id: work.id }).ok, true);
  assert.equal(applyWorkflowAction(state, "complete-work-order", completion).ok, true);
});

test("same-day meters advance in timestamp order and dates honor workspace timezone", () => {
  const state = createDefaultState();
  const asset = state.assets.find((row) => row.id === "ast_compressor_7");
  const created = createEntity(state, "meterReadings", {
    assetId: asset.id,
    value: asset.meterValue + 1,
    unit: asset.meterUnit,
    readingDate: "2026-07-15",
    source: "Manual",
    recordedBy: "Avery Morgan",
    notes: "Later same-day reading"
  });
  assert.equal(created.ok, true);
  assert.equal(asset.meterValue, 18421.5);
  const instant = new Date("2026-07-16T04:00:00.000Z");
  assert.equal(todayIso("Pacific/Honolulu", instant), "2026-07-15");
  assert.equal(todayIso("America/Detroit", instant), "2026-07-16");
  assert.equal(domainAddDays("2024-02-28", 1), "2024-02-29");
  assert.equal(domainAddDays("2024-02-29", 365), "2025-02-28");
});

test("archived completed work remains in historical cost and downtime metrics", () => {
  const state = createDefaultState();
  const before = shapeState(state).analytics.metrics;
  assert.equal(archiveEntity(state, "workOrders", "wo_compressor_filter").ok, true);
  const after = shapeState(state).analytics.metrics;
  assert.equal(after.maintenanceCost, before.maintenanceCost);
  assert.equal(after.downtimeHours, before.downtimeHours);
  assert.equal(after.openWorkOrders, before.openWorkOrders);
});

test("CSV formula protection covers leading whitespace and byte-order marks", () => {
  const csv = toCsv([{ direct: "=2+2", spaced: " =2+2", bom: "\ufeff=2+2", tabbed: "\t=2+2" }]);
  assert.match(csv, /'=2\+2/);
  assert.match(csv, /' =2\+2/);
  assert.match(csv, /'﻿=2\+2/);
  assert.match(csv, /'\t=2\+2/);
});

function makeWorkOrder(overrides = {}) {
  return {
    title: "Inspect auxiliary cooling fan",
    assetId: "ast_compressor_7",
    preventiveScheduleId: "",
    workType: "Corrective",
    priority: "Medium",
    status: "Requested",
    requester: "Avery Morgan",
    technician: "Morgan Lee",
    requestedDate: todayIso(),
    dueDate: addDays(todayIso(), 2),
    startedDate: "",
    completedDate: "",
    estimatedHours: 2,
    actualHours: 0,
    laborCost: 0,
    partsCost: 0,
    downtimeHours: 0,
    findings: "",
    resolution: "",
    evidenceUri: "",
    ...overrides
  };
}

function addDays(value, days) {
  const date = new Date(`${value}T12:00:00Z`);
  date.setUTCDate(date.getUTCDate() + days);
  return date.toISOString().slice(0, 10);
}
