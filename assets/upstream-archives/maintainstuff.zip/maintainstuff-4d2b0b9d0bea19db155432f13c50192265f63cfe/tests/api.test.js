import assert from "node:assert/strict";
import { rm } from "node:fs/promises";
import http from "node:http";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { Readable } from "node:stream";
import test from "node:test";
import { APP_CONFIG } from "../server/config.js";
import { createAppServer } from "../server/index.js";
import { handleApi } from "../server/routes.js";

const projectRoot = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");

test("API persists a complete work-order execution and exports it", async () => {
  await withTestDb("workflow", async () => {
    const stateResponse = await callApi("GET", "/api/state");
    assert.equal(stateResponse.status, 200);
    assert.equal(stateResponse.body.config.name, "MaintainStuff");
    assert.equal(stateResponse.body.config.port, 4221);
    assert.equal(stateResponse.body.config.dataEnv, "MAINTAINSTUFF_DATA");

    const title = "Replace exhaust fan contactor";
    const createdResponse = await callApi("POST", "/api/workOrders", makeWorkOrder({ title }));
    assert.equal(createdResponse.status, 201);
    const created = createdResponse.body.workOrders.find((row) => row.title === title);
    assert.ok(created);
    assert.equal(created.number, "MNT-1047");

    const started = await callApi("POST", "/api/actions/start-work-order", { id: created.id });
    assert.equal(started.status, 200);
    assert.equal(started.body.workOrders.find((row) => row.id === created.id).status, "In progress");

    const issued = await callApi("POST", "/api/actions/issue-part-to-work", { id: created.id, partId: "prt_vbelt_b62", quantity: 1, operationKey: "api-issue-1" });
    assert.equal(issued.status, 200);
    assert.equal(issued.body.workOrders.find((row) => row.id === created.id).partsCost, 34.75);

    const completed = await callApi("POST", "/api/actions/complete-work-order", {
      id: created.id,
      actualHours: 2,
      downtimeHours: 1,
      findings: "Contactor coil failed continuity test.",
      resolution: "Replaced contactor and verified fan rotation.",
      evidenceUri: "/evidence/exhaust-fan-contactor"
    });
    assert.equal(completed.status, 200);
    assert.equal(completed.body.workOrders.find((row) => row.id === created.id).laborCost, 190);

    const reloaded = await callApi("GET", "/api/state");
    assert.equal(reloaded.body.workOrders.find((row) => row.id === created.id).status, "Completed");
    assert.ok(reloaded.body.activity.some((row) => row.action === "completed work order" && row.entityId === created.id));

    const csv = await callApi("GET", "/api/export/workOrders.csv");
    assert.equal(csv.status, 200);
    assert.match(csv.headers["content-disposition"], /maintainstuff-workOrders\.csv/);
    assert.match(csv.text, /Replace exhaust fan contactor/);
  });
});

test("serialized API writes retain concurrent work orders and unique numbers", async () => {
  await withTestDb("concurrent", async () => {
    await callApi("GET", "/api/state");
    const [first, second] = await Promise.all([
      callApi("POST", "/api/workOrders", makeWorkOrder({ title: "Concurrent alpha work" })),
      callApi("POST", "/api/workOrders", makeWorkOrder({ title: "Concurrent beta work" }))
    ]);
    assert.equal(first.status, 201);
    assert.equal(second.status, 201);
    const reloaded = await callApi("GET", "/api/state");
    const rows = reloaded.body.workOrders.filter((row) => row.title.startsWith("Concurrent"));
    assert.equal(rows.length, 2);
    assert.equal(new Set(rows.map((row) => row.number)).size, 2);
  });
});

test("API validates snapshots before replacing durable data", async () => {
  await withTestDb("import", async () => {
    const exported = await callApi("GET", "/api/export/all.json");
    assert.equal(exported.status, 200);
    const invalidSnapshot = JSON.parse(exported.text);
    invalidSnapshot.workOrders[0].assetId = "ast_invalid";
    const invalid = await callApi("POST", "/api/import", invalidSnapshot);
    assert.equal(invalid.status, 400);
    assert.match(invalid.body.errors.join(" "), /active asset/);

    const unchanged = await callApi("GET", "/api/state");
    assert.equal(unchanged.body.workOrders[0].assetId, "ast_compressor_7");

    const validSnapshot = JSON.parse(exported.text);
    validSnapshot.workspace.organizationName = "Restored Reliability Team";
    const imported = await callApi("POST", "/api/import", validSnapshot);
    assert.equal(imported.status, 200);
    assert.equal(imported.body.workspace.organizationName, "Restored Reliability Team");
    assert.equal(imported.body.activity[0].action, "imported workspace snapshot");
  });
});

test("API reports malformed and oversized JSON as client errors", async () => {
  await withTestDb("requests", async () => {
    const malformed = await callRawApi("POST", "/api/import", "{broken-json");
    assert.equal(malformed.status, 400);
    assert.deepEqual(malformed.body.errors, ["Request body must be valid JSON."]);

    process.env.MAINTAINSTUFF_MAX_IMPORT_MB = "1";
    const oversized = await callRawApi("POST", "/api/import", `{"data":"${"x".repeat(1024 * 1024)}"}`);
    assert.equal(oversized.status, 413);
    assert.match(oversized.body.errors[0], /1 MiB/);
    delete process.env.MAINTAINSTUFF_MAX_IMPORT_MB;
  });
});

test("static server returns security headers and does not expose files outside public", async () => {
  const server = createAppServer();
  await new Promise((resolve) => server.listen(0, "127.0.0.1", resolve));
  try {
    const address = server.address();
    const home = await httpGet(address.port, "/");
    assert.equal(home.status, 200);
    assert.match(home.text, /MaintainStuff/);
    assert.match(home.headers["content-security-policy"], /frame-ancestors 'none'/);
    assert.equal(home.headers["x-frame-options"], "DENY");

    const contracts = await httpGet(address.port, "/contracts.js");
    assert.equal(contracts.status, 200);
    assert.match(contracts.text, /export function roleCanAction/);

    const traversal = await httpGet(address.port, "/%2e%2e%2fserver%2fconfig.js");
    assert.ok([400, 403, 404].includes(traversal.status));
    assert.doesNotMatch(traversal.text, /APP_CONFIG/);
  } finally {
    await new Promise((resolve, reject) => server.close((error) => error ? reject(error) : resolve()));
  }
});

test("HTTP mutations reject cross-origin and non-JSON form requests", async () => {
  await withTestDb("origin-guard", async () => {
    await callApi("GET", "/api/state");
    const formBody = '{"id":"wo_compressor_leak","resolution":"=cross-site cancellation"}\r\n';
    const form = await callRawApi("POST", "/api/actions/cancel-work-order", formBody, {
      origin: "https://attacker.example",
      "content-type": "text/plain"
    });
    assert.equal(form.status, 415);
    const jsonp = await callRawApi("POST", "/api/actions/cancel-work-order", formBody, {
      "content-type": "application/jsonp"
    });
    assert.equal(jsonp.status, 415);
    const json = await callApi("POST", "/api/actions/cancel-work-order", { id: "wo_compressor_leak", resolution: "Cross-site" }, {
      origin: "https://attacker.example",
      "sec-fetch-site": "cross-site"
    });
    assert.equal(json.status, 403);
    const unchanged = await callApi("GET", "/api/workOrders/wo_compressor_leak");
    assert.equal(unchanged.body.status, "In progress");
  });
});

test("planner, technician, storeroom, manager, and administrator permissions are enforced end to end", async () => {
  await withTestDb("roles", async () => {
    await callApi("GET", "/api/state");

    assert.equal((await callApi("PATCH", "/api/session", { userName: "Parker Planner", role: "Planner" })).status, 200);
    assert.equal((await callApi("GET", "/api/export/all.json")).status, 403);
    assert.equal((await callApi("PATCH", "/api/workspace", { organizationName: "Planner Managed" })).status, 200);
    const planned = await callApi("POST", "/api/workOrders", makeWorkOrder({ title: "Role matrix planned work" }));
    assert.equal(planned.status, 201);
    const plannedWork = planned.body.workOrders.find((row) => row.title === "Role matrix planned work");
    assert.ok(plannedWork);
    assert.equal((await callApi("POST", "/api/parts", makePart({ sku: "NO-PLANNER" }))).status, 403);
    assert.equal((await callApi("POST", "/api/actions/start-work-order", { id: plannedWork.id })).status, 403);
    assert.equal((await callApi("POST", "/api/actions/approve-work-order", { id: plannedWork.id })).status, 200);

    assert.equal((await callApi("PATCH", "/api/session", { userName: "Taylor Tech", role: "Technician" })).status, 200);
    assert.equal((await callApi("GET", "/api/export/all.json")).status, 403);
    assert.equal((await callApi("PATCH", "/api/workspace", { organizationName: "Unauthorized" })).status, 403);
    const meter = await callApi("POST", "/api/meterReadings", {
      assetId: "ast_compressor_7", value: 18421, unit: "Hours", readingDate: "2026-07-16",
      source: "Manual", recordedBy: "Taylor Tech", notes: "Authorized technician reading"
    });
    assert.equal(meter.status, 201);
    assert.equal((await callApi("POST", "/api/parts", makePart({ sku: "NO-TECH" }))).status, 403);
    assert.equal((await callApi("POST", "/api/actions/schedule-work-order", { id: plannedWork.id })).status, 403);
    assert.equal((await callApi("POST", "/api/actions/start-work-order", { id: plannedWork.id })).status, 200);
    assert.equal((await callApi("GET", "/api/export/workOrders.json")).status, 200);
    assert.equal((await callApi("GET", "/api/export/parts.json")).status, 403);

    assert.equal((await callApi("PATCH", "/api/session", { userName: "Robin Stores", role: "Storeroom" })).status, 200);
    const partResponse = await callApi("POST", "/api/parts", makePart());
    assert.equal(partResponse.status, 201);
    const part = partResponse.body.parts.find((row) => row.sku === "ROLE-MATRIX-001");
    assert.ok(part);
    assert.equal((await callApi("PATCH", `/api/parts/${part.id}`, { ...part, bin: "R-02-B" })).status, 200);
    assert.equal((await callApi("POST", "/api/actions/restock-part", { id: part.id, quantity: 4, unitCost: 15.5, note: "Role test receipt" })).status, 200);
    assert.equal((await callApi("POST", "/api/actions/issue-part-to-work", {
      id: plannedWork.id, partId: part.id, quantity: 1, operationKey: "role-matrix-stock-1"
    })).status, 200);
    assert.equal((await callApi("POST", "/api/actions/start-work-order", { id: "wo_boiler_pm" })).status, 403);
    assert.equal((await callApi("GET", "/api/export/parts.json")).status, 200);
    assert.equal((await callApi("GET", "/api/export/workOrders.json")).status, 403);
    assert.equal((await callApi("GET", "/api/export/all.json")).status, 403);

    assert.equal((await callApi("PATCH", "/api/session", { userName: "Avery Morgan", role: "Maintenance manager" })).status, 200);
    assert.equal((await callApi("GET", "/api/export/all.json")).status, 200);
    assert.equal((await callApi("PATCH", "/api/session", { userName: "Alex Admin", role: "Administrator" })).status, 200);
    assert.equal((await callApi("GET", "/api/export/all.json")).status, 200);
    assert.equal((await callApi("POST", "/api/assets", {
      assetTag: "ROLE-ADMIN-001", name: "Admin-created asset", site: "Detroit Plant", status: "Operational",
      criticality: "Low", location: "Role test bay", category: "Facilities", manufacturer: "Internal",
      model: "N/A", serialNumber: "ROLE-001", owner: "Alex Admin", installDate: "2026-07-16",
      warrantyDate: "", meterValue: 0, meterUnit: "Hours", documentationUri: ""
    })).status, 201);
  });
});

test("trusted proxy identity is explicit, fail-closed, and actor-attributed", async () => {
  await withTestDb("proxy", async () => {
    process.env.MAINTAINSTUFF_TRUST_PROXY_IDENTITY = "true";
    try {
      assert.equal((await callApi("GET", "/api/state")).status, 401);
      const headers = { "x-maintainstuff-user": "Proxy Manager", "x-maintainstuff-role": "Maintenance manager" };
      const state = await callApi("GET", "/api/state", undefined, headers);
      assert.equal(state.status, 200);
      assert.equal(state.body.session.userName, "Proxy Manager");
      const updated = await callApi("PATCH", "/api/workspace", { organizationName: "Proxy Managed" }, headers);
      assert.equal(updated.status, 200);
      assert.equal(updated.body.activity[0].actor, "Proxy Manager");
      assert.equal((await callApi("PATCH", "/api/session", { userName: "No", role: "Administrator" }, headers)).status, 403);
    } finally {
      delete process.env.MAINTAINSTUFF_TRUST_PROXY_IDENTITY;
    }
  });
});

test("a valid self-export larger than 5 MiB restores under the default limit", async () => {
  await withTestDb("large-roundtrip", async () => {
    const exported = await callApi("GET", "/api/export/all.json");
    const snapshot = JSON.parse(exported.text);
    const base = snapshot.preventiveSchedules[0];
    for (let index = 0; index < 1400; index += 1) {
      snapshot.preventiveSchedules.push({
        ...base,
        id: `archived_pm_${index}`,
        name: `Archived maintenance plan ${index}`,
        procedure: "x".repeat(4000),
        archivedAt: "2026-07-01T00:00:00.000Z"
      });
    }
    const bytes = Buffer.byteLength(JSON.stringify(snapshot));
    assert.ok(bytes > 5 * 1024 * 1024);
    const imported = await callApi("POST", "/api/import", snapshot);
    assert.equal(imported.status, 200);
    assert.equal(imported.body.preventiveSchedules.length, snapshot.preventiveSchedules.length);
  });
});

test("collection exports honor active filters", async () => {
  await withTestDb("filtered-export", async () => {
    const exported = await callApi("GET", "/api/export/workOrders.json?archive=active&filterField=priority&filterValue=Emergency");
    assert.equal(exported.status, 200);
    const rows = JSON.parse(exported.text);
    assert.ok(rows.length > 0);
    assert.ok(rows.every((row) => row.priority === "Emergency" && !row.archivedAt));

    const relationLeak = await callApi("GET", "/api/export/workOrders.json?archive=active&search=Utility%20mezzanine");
    assert.equal(relationLeak.status, 200);
    assert.deepEqual(JSON.parse(relationLeak.text), []);

    const ranked = await callApi("GET", "/api/export/workOrders.json?archive=active&sortField=priority&direction=desc");
    assert.equal(ranked.status, 200);
    const priorities = JSON.parse(ranked.text).map((row) => row.priority);
    assert.deepEqual(priorities, ["Emergency", "Emergency", "High", "Medium", "Medium"]);
  });
});

async function withTestDb(label, run) {
  const filePath = path.join(projectRoot, "data", `test-${label}-${process.pid}-${Date.now()}.json`);
  process.env[APP_CONFIG.dataEnv] = filePath;
  try {
    await run();
  } finally {
    delete process.env[APP_CONFIG.dataEnv];
    await rm(filePath, { force: true });
  }
}

function makeWorkOrder(overrides = {}) {
  const date = new Date().toISOString().slice(0, 10);
  return {
    title: "Service ventilation equipment",
    assetId: "ast_boiler_pump_4",
    preventiveScheduleId: "",
    workType: "Corrective",
    priority: "High",
    status: "Requested",
    requester: "Avery Morgan",
    technician: "Morgan Lee",
    requestedDate: date,
    dueDate: date,
    startedDate: "",
    completedDate: "",
    estimatedHours: 3,
    actualHours: 0,
    laborCost: 0,
    partsCost: 0,
    downtimeHours: 0,
    findings: "",
    resolution: "",
    evidenceUri: "",
    ...overrides
  };
}

function makePart(overrides = {}) {
  return {
    sku: "ROLE-MATRIX-001",
    name: "Role matrix bearing",
    onHand: 2,
    reorderPoint: 1,
    category: "Mechanical",
    site: "Detroit Plant",
    bin: "R-02-A",
    supplier: "Internal stores",
    unitCost: 15,
    ...overrides
  };
}

async function callApi(method, pathname, body, headers = {}) {
  return finishCall(new MockRequest(method, body === undefined ? "" : JSON.stringify(body), headers), pathname);
}

async function callRawApi(method, pathname, text, headers = {}) {
  return finishCall(new MockRequest(method, text, headers), pathname);
}

async function finishCall(req, pathname) {
  const res = new MockResponse();
  await handleApi(req, res, new URL(pathname, "http://local.test"));
  return { status: res.status, headers: res.headers, text: res.text, body: parseJson(res.text) };
}

function httpGet(port, requestPath) {
  return new Promise((resolve, reject) => {
    http.get({ host: "127.0.0.1", port, path: requestPath }, (response) => {
      let text = "";
      response.setEncoding("utf8");
      response.on("data", (chunk) => { text += chunk; });
      response.on("end", () => resolve({ status: response.statusCode, headers: response.headers, text }));
    }).on("error", reject);
  });
}

class MockRequest extends Readable {
  constructor(method, bodyText, headers = {}) {
    super();
    this.method = method;
    this.headers = { host: "local.test", "content-type": "application/json", ...headers };
    this.socket = { encrypted: false };
    this.bodyText = bodyText;
    this.sent = false;
  }

  _read() {
    if (this.sent) return this.push(null);
    this.sent = true;
    this.push(this.bodyText);
  }
}

class MockResponse {
  constructor() {
    this.status = 200;
    this.headers = {};
    this.text = "";
  }

  writeHead(status, headers = {}) {
    this.status = status;
    this.headers = headers;
  }

  end(chunk = "") {
    this.text += chunk;
  }
}

function parseJson(text) {
  try {
    return JSON.parse(text);
  } catch {
    return null;
  }
}
