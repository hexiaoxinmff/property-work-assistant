import { APP_CONFIG } from "./config.js";

const isoDatePattern = /^\d{4}-\d{2}-\d{2}$/;
const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
const safeIdPattern = /^[A-Za-z0-9][A-Za-z0-9._:-]{0,127}$/;
const activityEntityTypes = new Set(["workspace", ...APP_CONFIG.collections.map((collection) => collection.key)]);

export function nowIso() {
  return new Date().toISOString();
}

export function todayIso(stateOrTimezone = null, clock = new Date()) {
  const timeZone = typeof stateOrTimezone === "string" ? stateOrTimezone : stateOrTimezone?.workspace?.timezone || "UTC";
  const parts = new Intl.DateTimeFormat("en-US", {
    timeZone,
    year: "numeric",
    month: "2-digit",
    day: "2-digit"
  }).formatToParts(clock);
  const value = Object.fromEntries(parts.map((part) => [part.type, part.value]));
  return `${value.year}-${value.month}-${value.day}`;
}

export function uid(prefix = "id") {
  return `${prefix}_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 9)}`;
}

export function clean(value) {
  return String(value ?? "").trim();
}

export function clone(value) {
  return JSON.parse(JSON.stringify(value));
}

export function publicConfig() {
  const { seeds: _seeds, ...config } = APP_CONFIG;
  return clone(config);
}

export function collectionKeys() {
  return APP_CONFIG.collections.map((collection) => collection.key);
}

export function getCollectionConfig(key) {
  const config = APP_CONFIG.collections.find((collection) => collection.key === key);
  if (!config) throw new Error(`Unknown collection: ${key}`);
  return config;
}

export function createDefaultState() {
  const state = clone(APP_CONFIG.seeds);
  for (const collection of APP_CONFIG.collections) {
    state[collection.key] = Array.isArray(state[collection.key]) ? state[collection.key] : [];
  }
  state.activity = Array.isArray(state.activity) ? state.activity : [];
  state.workspace ||= { id: `workspace_${APP_CONFIG.slug}` };
  state.session ||= { userId: "usr_local", userName: "Local Admin", role: "Administrator" };
  return state;
}

export function normalizeState(input) {
  const base = createDefaultState();
  const source = input && typeof input === "object" ? clone(input) : {};
  const state = { ...base, ...source };
  state.workspace = { ...base.workspace, ...(source.workspace || {}) };
  state.session = { ...base.session, ...(source.session || {}) };
  for (const collection of APP_CONFIG.collections) {
    state[collection.key] = Array.isArray(source[collection.key]) ? source[collection.key] : base[collection.key];
  }
  state.activity = Array.isArray(source.activity) ? source.activity : base.activity;
  delete state.analytics;
  delete state.config;
  delete state.product;
  delete state.exportedAt;
  return state;
}

export function activeRows(state, collectionKey) {
  return (state[collectionKey] || []).filter((row) => !row.archivedAt);
}

export function addActivity(state, action, entityType, entityId, metadata = {}) {
  state.activity.unshift({
    id: uid("act"),
    actor: state.session?.userName || "Local Admin",
    action,
    entityType,
    entityId,
    metadata,
    createdAt: nowIso()
  });
}

export function validateWorkspace(input) {
  const value = {};
  const errors = [];
  const validationState = createDefaultState();
  for (const field of APP_CONFIG.workspaceFields) {
    value[field.name] = normalizeField(field, input?.[field.name], null, validationState, errors);
    validateRequired(field, value[field.name], errors);
  }
  if (Array.isArray(value.sites) && new Set(value.sites.map((site) => site.toLowerCase())).size !== value.sites.length) {
    errors.push("Sites must be unique.");
  }
  try {
    new Intl.DateTimeFormat("en-US", { timeZone: value.timezone }).format(new Date());
  } catch {
    errors.push("Operating timezone must be a valid IANA timezone.");
  }
  return result(errors, value);
}

export function updateWorkspace(state, patch) {
  const validation = validateWorkspace({ ...state.workspace, ...patch });
  if (!validation.ok) return validation;
  const removedSites = (state.workspace.sites || []).filter((site) => !validation.value.sites.includes(site));
  for (const site of removedSites) {
    const dependent = ["assets", "parts"].flatMap((key) => activeRows(state, key).filter((row) => row.site === site));
    if (dependent.length) return result([`Site ${site} is still assigned to ${dependent.length} active record${dependent.length === 1 ? "" : "s"}.`]);
  }
  state.workspace = { ...state.workspace, ...validation.value, updatedAt: nowIso() };
  addActivity(state, "updated workspace settings", "workspace", state.workspace.id, { organizationName: state.workspace.organizationName });
  return result([], shapeState(state));
}

export function validateSession(input) {
  const value = {};
  const errors = [];
  const validationState = createDefaultState();
  for (const field of APP_CONFIG.sessionFields || []) {
    value[field.name] = normalizeField(field, input?.[field.name], null, validationState, errors);
    validateRequired(field, value[field.name], errors);
  }
  return result(errors, value);
}

export function updateSession(state, patch) {
  const validation = validateSession({ ...state.session, ...patch });
  if (!validation.ok) return validation;
  state.session = { ...state.session, ...validation.value };
  addActivity(state, "updated local operator", "workspace", state.workspace.id, { role: state.session.role });
  return result([], shapeState(state));
}

export function validateEntity(state, collectionKey, input, existing = null, options = {}) {
  const collection = getCollectionConfig(collectionKey);
  const errors = [];
  const value = {};
  for (const field of collection.fields) {
    const hasInput = input && Object.hasOwn(input, field.name);
    const protectedValue = existing && (field.computed || field.generated) && !options.importing;
    const raw = protectedValue ? existing[field.name] : hasInput ? input[field.name] : existing?.[field.name] ?? field.default ?? "";
    value[field.name] = normalizeField(field, raw, collectionKey, state, errors, existing, options);
    validateRequired(field, value[field.name], errors);
    if (field.unique && !isEmptyValue(value[field.name])) {
      const duplicate = activeRows(state, collectionKey).find((row) => row.id !== existing?.id && comparable(row[field.name]) === comparable(value[field.name]));
      if (duplicate) errors.push(`${field.label} must be unique.`);
    }
  }
  applyDerivedFields(collectionKey, value, existing, options);
  validateDomainRules(state, collectionKey, value, existing, errors);
  return result(errors, value);
}

export function createEntity(state, collectionKey, input, options = {}) {
  const collection = getCollectionConfig(collectionKey);
  const candidate = { ...(input || {}) };
  if (collectionKey === "workOrders" && !options.allowPlannedStatus && candidate.status && candidate.status !== "Requested") {
    return result(["New work orders must begin in Requested status."]);
  }
  if (collectionKey === "workOrders" && !clean(candidate.number)) candidate.number = nextWorkOrderNumber(state);
  if (collectionKey === "workOrders") {
    candidate.laborCost = 0;
    candidate.partsCost = 0;
    if (candidate.actualHours === "" || candidate.actualHours === undefined) candidate.actualHours = 0;
    if (candidate.downtimeHours === "" || candidate.downtimeHours === undefined) candidate.downtimeHours = 0;
  }
  if (collectionKey === "parts") candidate.status = derivePartStatus(candidate);
  if (collectionKey === "inspections") candidate.followUpWorkOrderId = "";
  const validation = validateEntity(state, collectionKey, candidate);
  if (!validation.ok) return validation;
  const timestamp = nowIso();
  const row = {
    id: uid(collection.prefix),
    ...validation.value,
    ...(collectionKey === "workOrders" ? { partsUsed: [] } : {}),
    archivedAt: null,
    createdAt: timestamp,
    updatedAt: timestamp
  };
  state[collectionKey].push(row);
  if (collectionKey === "workOrders") state.workspace.nextWorkOrderNumber = Number(state.workspace.nextWorkOrderNumber) + 1;
  if (collectionKey === "meterReadings") synchronizeAssetMeter(state, row);
  addActivity(state, `created ${collection.singular.toLowerCase()}`, collectionKey, row.id, rowSummary(collection, row));
  return result([], shapeState(state), 201);
}

export function updateEntity(state, collectionKey, id, input) {
  const collection = getCollectionConfig(collectionKey);
  const row = findRow(state, collectionKey, id);
  if (!row) return result([`${collection.singular} was not found.`], null, 404);
  if (collectionKey === "workOrders" && input && Object.hasOwn(input, "number") && clean(input.number) !== row.number) {
    return result(["Work-order number cannot be changed after creation."]);
  }
  if (collectionKey === "workOrders" && input && Object.hasOwn(input, "status") && input.status !== row.status) {
    return result(["Work-order status can only be changed with workflow actions."]);
  }
  const validation = validateEntity(state, collectionKey, input, row);
  if (!validation.ok) return validation;
  Object.assign(row, validation.value, { updatedAt: nowIso() });
  if (collectionKey === "meterReadings") synchronizeAssetMeter(state, row);
  addActivity(state, `updated ${collection.singular.toLowerCase()}`, collectionKey, row.id, rowSummary(collection, row));
  return result([], shapeState(state));
}

export function archiveEntity(state, collectionKey, id) {
  const collection = getCollectionConfig(collectionKey);
  const row = findRow(state, collectionKey, id);
  if (!row) return result([`${collection.singular} was not found.`], null, 404);
  const dependent = findActiveDependent(state, collectionKey, id);
  if (dependent) {
    return result([`${collection.singular} cannot be archived while active ${dependent.collection.singular.toLowerCase()} “${dependent.label}” references it.`]);
  }
  row.archivedAt = nowIso();
  row.updatedAt = nowIso();
  addActivity(state, `archived ${collection.singular.toLowerCase()}`, collectionKey, row.id, rowSummary(collection, row));
  return result([], shapeState(state));
}

export function restoreEntity(state, collectionKey, id) {
  const collection = getCollectionConfig(collectionKey);
  const row = (state[collectionKey] || []).find((item) => item.id === id);
  if (!row) return result([`${collection.singular} was not found.`], null, 404);
  if (!row.archivedAt) return result([`${collection.singular} is already active.`]);
  const validation = validateEntity(state, collectionKey, row, row);
  if (!validation.ok) return result([`Restore blocked: ${validation.errors.join(" ")}`]);
  Object.assign(row, validation.value, { archivedAt: null, updatedAt: nowIso() });
  addActivity(state, `restored ${collection.singular.toLowerCase()}`, collectionKey, row.id, rowSummary(collection, row));
  return result([], shapeState(state));
}

export function applyWorkflowAction(state, actionKey, payload = {}) {
  const action = APP_CONFIG.actions.find((item) => item.key === actionKey);
  if (!action) return result(["Workflow action is not supported."], null, 404);
  const priorPartOperation = findPriorPartOperation(state, action, payload);
  if (priorPartOperation) {
    if (!priorPartOperation.ok) return priorPartOperation;
    return result([], shapeState(state));
  }
  const collection = getCollectionConfig(action.collection);
  const row = findRow(state, action.collection, clean(payload.id));
  if (!row) return result([`${collection.singular} was not found.`], null, 404);
  const actionInput = validateActionFields(state, action, payload);
  if (!actionInput.ok) return actionInput;
  const actionPayload = actionInput.value;
  const status = actionStatus(action.collection, row);
  if (action.allowedStatuses && !action.allowedStatuses.includes(status)) {
    return result([`${action.label} is not available while ${collection.singular.toLowerCase()} status is ${status}.`]);
  }
  let outcome = null;
  if (action.type === "assetStatus") row.status = action.value;
  else if (action.type === "workOrderStatus") row.status = action.value;
  else if (action.type === "scheduleStatus") row.status = action.value;
  else if (action.type === "startWorkOrder") startWorkOrder(state, row);
  else if (action.type === "holdWorkOrder") holdWorkOrder(row, actionPayload);
  else if (action.type === "completeWorkOrder") completeWorkOrder(state, row, actionPayload);
  else if (action.type === "cancelWorkOrder") cancelWorkOrder(state, row, actionPayload);
  else if (action.type === "issuePartToWork") outcome = issuePartToWorkOrder(state, row, actionPayload.partId, actionPayload.quantity, actionPayload.operationKey);
  else if (action.type === "generatePreventiveWork") outcome = generatePreventiveWork(state, row);
  else if (action.type === "inspectionFollowUp") outcome = raiseInspectionFollowUp(state, row);
  else if (action.type === "restockPart") restockPart(row, actionPayload);
  else if (action.type === "issuePart") outcome = issuePartToWorkOrder(state, findRow(state, "workOrders", actionPayload.workOrderId), row.id, actionPayload.quantity, actionPayload.operationKey);
  else if (action.type === "applyMeter") outcome = applyExistingMeter(state, row);
  else return result(["Workflow action type is not implemented."]);
  if (outcome && !outcome.ok) return outcome;
  if (outcome?.idempotent) return result([], shapeState(state));
  row.updatedAt = nowIso();
  addActivity(state, action.activity, action.collection, row.id, {
    ...rowSummary(collection, row),
    ...actionPayload,
    ...(outcome?.metadata || {})
  });
  return result([], shapeState(state));
}

export function computeAnalytics(state) {
  const metrics = Object.fromEntries(APP_CONFIG.metrics.map((metric) => [metric.key, computeMetric(state, metric)]));
  const workOrders = activeRows(state, "workOrders");
  const priorityQueue = workOrders
    .filter((row) => !["Completed", "Cancelled"].includes(row.status))
    .sort((left, right) => priorityScore(state, right) - priorityScore(state, left) || dateTime(left.dueDate) - dateTime(right.dueDate))
    .slice(0, 8)
    .map((row) => ({ ...clone(row), assetName: relationLabel(state, "assets", row.assetId) }));
  const alerts = buildAlerts(state);
  return {
    metrics,
    primaryBreakdown: countBy(workOrders, "status"),
    priorityQueue,
    alerts,
    activity: [...state.activity].sort((a, b) => b.createdAt.localeCompare(a.createdAt))
  };
}

export function shapeState(state) {
  const normalized = normalizeState(state);
  return {
    ...clone(normalized),
    analytics: computeAnalytics(normalized),
    config: publicConfig()
  };
}

export function toCsv(rows) {
  const normalizedRows = rows.map((row) => flatten(row));
  const columns = Array.from(normalizedRows.reduce((set, row) => {
    for (const key of Object.keys(row)) set.add(key);
    return set;
  }, new Set()));
  if (!columns.length) return "\n";
  const lines = [columns.map(csvCell).join(",")];
  for (const row of normalizedRows) lines.push(columns.map((column) => csvCell(row[column])).join(","));
  return `${lines.join("\n")}\n`;
}

export function exportSnapshot(state) {
  const snapshot = clone(normalizeState(state));
  for (const workOrder of snapshot.workOrders || []) {
    workOrder.partsUsed = (workOrder.partsUsed || []).map((usage, index) => ({
      ...usage,
      operationKey: effectiveOperationKey(workOrder.id, usage, index)
    }));
  }
  return { ...snapshot, exportedAt: nowIso(), product: APP_CONFIG.slug, schemaVersion: 1 };
}

export function importSnapshot(state, snapshot) {
  const importActor = { ...state.session };
  const validation = validateSnapshot(snapshot);
  if (!validation.ok) return validation;
  const incoming = validation.value;
  const mergedActivity = mergeActivity(state.activity, incoming.activity);
  if (!mergedActivity.ok) return mergedActivity;
  for (const collectionKey of collectionKeys()) state[collectionKey] = incoming[collectionKey];
  state.workspace = incoming.workspace;
  state.session = { ...state.session, ...incoming.session };
  state.activity = mergedActivity.value;
  const importedSession = state.session;
  state.session = importActor;
  addActivity(state, "imported workspace snapshot", "workspace", state.workspace.id, { product: APP_CONFIG.slug });
  state.session = importedSession;
  return result([], shapeState(state));
}

function normalizeField(field, raw, currentCollection, state, errors, existing = null, options = {}) {
  if (field.type === "number") {
    if (raw === null || raw === undefined || (typeof raw === "string" && !raw.trim())) return "";
    if (!["number", "string"].includes(typeof raw)) {
      errors.push(`${field.label} must be a finite number.`);
      return 0;
    }
    const number = Number(raw);
    if (!Number.isFinite(number)) {
      errors.push(`${field.label} must be a finite number.`);
      return 0;
    }
    if (field.min !== undefined && number < field.min) errors.push(`${field.label} must be at least ${field.min}.`);
    if (field.minExclusive !== undefined && number <= field.minExclusive) errors.push(`${field.label} must be greater than ${field.minExclusive}.`);
    if (field.max !== undefined && number > field.max) errors.push(`${field.label} must be no more than ${field.max}.`);
    if (field.integer && !Number.isInteger(number)) errors.push(`${field.label} must be a whole number.`);
    return number;
  }
  if (field.type === "boolean") return raw === true || raw === "true" || raw === "on";
  if (field.type === "tags" || field.type === "multiselect") {
    const values = arrayValue(raw).map(clean).filter(Boolean);
    return [...new Set(values)];
  }
  if (field.type === "select") {
    const value = clean(raw);
    if (value && !field.options.includes(value)) errors.push(`${field.label} must be one of: ${field.options.join(", ")}.`);
    return value;
  }
  if (field.type === "workspaceOption") {
    const value = clean(raw);
    const options = state.workspace?.[field.workspaceField] || [];
    if (value && !options.includes(value)) errors.push(`${field.label} must match an active workspace option.`);
    return value;
  }
  if (field.type === "date") {
    const value = clean(raw);
    if (value && !validDate(value)) {
      errors.push(`${field.label} must be a valid date in YYYY-MM-DD format.`);
    }
    return value;
  }
  if (field.type === "email") {
    const value = clean(raw).toLowerCase();
    if (value && !emailPattern.test(value)) errors.push(`${field.label} must be a valid email address.`);
    return value;
  }
  if (field.type === "url") {
    const value = clean(raw);
    if (value && !isReasonableUrlOrPath(value)) errors.push(`${field.label} must be an http(s) URL or local path.`);
    return value;
  }
  if (field.type === "relation") {
    const value = clean(raw);
    const candidates = options.allowArchivedRelations ? state[field.collection] || [] : activeRows(state, field.collection);
    if (value && !candidates.some((row) => row.id === value)) {
      errors.push(`${field.label} must reference ${options.allowArchivedRelations ? "an existing" : "an active"} ${getCollectionConfig(field.collection).singular.toLowerCase()}.`);
    }
    return value;
  }
  if (field.type === "relationMany") {
    const values = [...new Set(arrayValue(raw).map(clean).filter(Boolean))];
    const candidates = options.allowArchivedRelations ? state[field.collection] || [] : activeRows(state, field.collection);
    const allowed = new Set(candidates.map((row) => row.id));
    const invalid = values.filter((value) => !allowed.has(value));
    if (invalid.length) errors.push(`${field.label} contains inactive or unknown records.`);
    return values;
  }
  const value = clean(raw);
  if (field.maxLength && value.length > field.maxLength) errors.push(`${field.label} must be ${field.maxLength} characters or fewer.`);
  if (field.pattern && value && !new RegExp(field.pattern).test(value)) errors.push(field.patternMessage || `${field.label} has an invalid format.`);
  if (field.generated && existing && value !== clean(existing[field.name])) errors.push(`${field.label} cannot be changed.`);
  return value;
}

function validateRequired(field, value, errors) {
  if (field.required && isEmptyValue(value)) errors.push(`${field.label} is required.`);
}

function applyDerivedFields(collectionKey, value, existing, options = {}) {
  if (collectionKey === "parts") value.status = options.importing ? derivePartStatus({ ...value, status: "" }) : existing?.status === "Discontinued" ? "Discontinued" : derivePartStatus(value);
  if (collectionKey === "workOrders") {
    value.laborCost = roundMoney(value.laborCost || 0);
    value.partsCost = roundMoney(value.partsCost || 0);
  }
}

function validateDomainRules(state, collectionKey, value, existing, errors) {
  if (collectionKey === "assets" && value.installDate && value.warrantyDate && value.warrantyDate < value.installDate) {
    errors.push("Warranty date cannot precede the installation date.");
  }
  if (collectionKey === "workOrders") {
    if (value.requestedDate && value.dueDate && value.dueDate < value.requestedDate) errors.push("Due date cannot precede the requested date.");
    if (value.completedDate && value.startedDate && value.completedDate < value.startedDate) errors.push("Completed date cannot precede the started date.");
    if (value.status === "Completed" && (!(Number(value.actualHours) > 0) || !clean(value.resolution))) errors.push("Completed work requires labor hours and resolution notes.");
    if (value.status === "Cancelled" && !clean(value.resolution)) errors.push("Cancelled work requires a cancellation reason.");
  }
  if (collectionKey === "preventiveSchedules") {
    const calendar = value.triggerType.includes("Calendar");
    const meter = value.triggerType.includes("meter") || value.triggerType === "Meter";
    if (calendar && (!(Number(value.intervalDays) > 0) || !value.nextDueDate)) errors.push("Calendar schedules require a positive day interval and next due date.");
    if (meter && (!(Number(value.meterInterval) > 0) || !(Number(value.nextMeter) > Number(value.lastMeter)))) errors.push("Meter schedules require a positive interval and next meter above the last meter.");
  }
  if (collectionKey === "inspections" && ["Conditional", "Fail"].includes(value.result) && !clean(value.failedChecks)) {
    errors.push(`${value.result} inspections require failed-check details.`);
  }
  if (collectionKey === "meterReadings") validateMeterReading(state, value, existing, errors);
}

function validateMeterReading(state, value, existing, errors) {
  const asset = activeRows(state, "assets").find((row) => row.id === value.assetId);
  if (!asset) return;
  if (value.unit !== asset.meterUnit) errors.push(`Reading unit must match the asset meter unit (${asset.meterUnit}).`);
  const readings = activeRows(state, "meterReadings")
    .filter((row) => row.assetId === value.assetId && row.id !== existing?.id)
    .sort(compareMeterReadings);
  const candidate = {
    ...value,
    id: existing?.id || "~new",
    createdAt: existing?.createdAt || nowIso()
  };
  const previous = readings.filter((row) => compareMeterReadings(row, candidate) < 0).at(-1);
  const next = readings.find((row) => compareMeterReadings(row, candidate) > 0);
  if (previous && Number(value.value) < Number(previous.value)) errors.push(`Reading cannot be below the prior ${previous.readingDate} value of ${previous.value}.`);
  if (next && Number(value.value) > Number(next.value)) errors.push(`Reading cannot exceed the later ${next.readingDate} value of ${next.value}.`);
  if (!next && Number(value.value) < Number(asset.meterValue)) errors.push(`Latest reading cannot roll the asset meter back below ${asset.meterValue}.`);
}

function validateActionFields(state, action, payload) {
  const errors = [];
  const value = {};
  for (const field of action.fields || []) {
    value[field.name] = normalizeField(field, payload[field.name], action.collection, state, errors);
    validateRequired(field, value[field.name], errors);
  }
  return result(errors, value);
}

function startWorkOrder(state, row) {
  row.status = "In progress";
  row.startedDate ||= todayIso(state);
  const asset = findRow(state, "assets", row.assetId);
  if (asset?.status === "Operational") {
    asset.status = "Limited service";
    asset.updatedAt = nowIso();
  }
}

function holdWorkOrder(row, payload) {
  row.status = "Waiting";
  row.resolution = payload.resolution;
}

function completeWorkOrder(state, row, payload) {
  row.status = "Completed";
  row.startedDate ||= todayIso(state);
  row.completedDate = todayIso(state);
  row.actualHours = payload.actualHours;
  row.downtimeHours = payload.downtimeHours;
  row.findings = payload.findings;
  row.resolution = payload.resolution;
  row.evidenceUri = payload.evidenceUri;
  row.laborCost = roundMoney(Number(payload.actualHours) * Number(state.workspace.defaultLaborRate));
  const schedule = row.preventiveScheduleId ? findRow(state, "preventiveSchedules", row.preventiveScheduleId) : null;
  if (schedule) advancePreventiveSchedule(state, schedule, row.completedDate);
  const asset = findRow(state, "assets", row.assetId);
  if (asset) {
    const otherOpen = activeRows(state, "workOrders").some((work) => work.id !== row.id && work.assetId === asset.id && !["Completed", "Cancelled"].includes(work.status));
    if (!otherOpen && asset.status !== "Retired") {
      asset.status = "Operational";
      asset.updatedAt = nowIso();
    }
  }
}

function cancelWorkOrder(state, row, payload) {
  row.status = "Cancelled";
  row.completedDate = todayIso(state);
  row.resolution = payload.resolution;
}

function issuePartToWorkOrder(state, workOrder, partId, quantity, operationKey) {
  if (!workOrder) return result(["Work order was not found."], null, 404);
  workOrder.partsUsed = Array.isArray(workOrder.partsUsed) ? workOrder.partsUsed : [];
  const priorMatch = findPartOperation(state, operationKey);
  if (priorMatch) {
    if (priorMatch.workOrder.id !== workOrder.id || priorMatch.usage.partId !== partId || Number(priorMatch.usage.quantity) !== Number(quantity)) return result(["Operation key was already used for a different part issue."]);
    return { ok: true, idempotent: true, metadata: { operationKey, workOrder: workOrder.number } };
  }
  if (["Completed", "Cancelled"].includes(workOrder.status)) return result(["Parts cannot be issued to closed work."]);
  const part = findRow(state, "parts", partId);
  if (!part) return result(["Part was not found."], null, 404);
  const amount = Number(quantity);
  if (!(amount > 0) || amount > Number(part.onHand)) return result([`Issue quantity must be greater than zero and no more than ${part.onHand}.`]);
  const issuedAt = nowIso();
  const cost = roundMoney(amount * Number(part.unitCost));
  const remaining = roundQuantity(Number(part.onHand) - amount);
  if (remaining < 0) return result(["Part stock cannot become negative."]);
  part.onHand = remaining;
  part.status = derivePartStatus(part);
  part.updatedAt = issuedAt;
  workOrder.partsUsed.push({ partId: part.id, quantity: amount, unitCost: part.unitCost, issuedAt, actor: state.session?.userName || "Local Admin", operationKey });
  workOrder.partsCost = canonicalPartsCost(workOrder.partsUsed);
  workOrder.updatedAt = issuedAt;
  addActivity(state, "decremented part inventory", "parts", part.id, { sku: part.sku, quantity: amount, workOrder: workOrder.number });
  return { ok: true, metadata: { part: part.sku, quantity: amount, workOrder: workOrder.number, cost } };
}

function generatePreventiveWork(state, schedule) {
  const duplicate = activeRows(state, "workOrders").find((row) => row.preventiveScheduleId === schedule.id && !["Completed", "Cancelled"].includes(row.status));
  if (duplicate) return { ok: true, idempotent: true, metadata: { workOrder: duplicate.number } };
  const asset = findRow(state, "assets", schedule.assetId);
  const created = createEntity(state, "workOrders", {
    title: schedule.name,
    assetId: schedule.assetId,
    preventiveScheduleId: schedule.id,
    workType: "Preventive",
    priority: asset?.criticality === "Critical" ? "High" : "Medium",
    status: "Scheduled",
    requester: state.session?.userName || "Local Admin",
    technician: schedule.owner,
    requestedDate: todayIso(state),
    dueDate: preventiveDueDate(state, schedule),
    startedDate: "",
    completedDate: "",
    estimatedHours: 2,
    actualHours: 0,
    laborCost: 0,
    partsCost: 0,
    downtimeHours: 0,
    findings: "",
    resolution: "",
    evidenceUri: ""
  }, { allowPlannedStatus: true });
  if (!created.ok) return created;
  const workOrder = activeRows(state, "workOrders").at(-1);
  return { ok: true, metadata: { workOrder: workOrder.number } };
}

function raiseInspectionFollowUp(state, inspection) {
  if (inspection.followUpWorkOrderId && findRow(state, "workOrders", inspection.followUpWorkOrderId)) {
    const existing = findRow(state, "workOrders", inspection.followUpWorkOrderId);
    return { ok: true, idempotent: true, metadata: { workOrder: existing.number } };
  }
  const asset = findRow(state, "assets", inspection.assetId);
  const created = createEntity(state, "workOrders", {
    title: `Correct ${inspection.template} findings`,
    assetId: inspection.assetId,
    preventiveScheduleId: "",
    workType: inspection.result === "Fail" ? "Safety" : "Corrective",
    priority: inspection.result === "Fail" ? "Emergency" : "High",
    status: "Requested",
    requester: inspection.inspector,
    technician: asset?.owner || state.session?.userName || "Local Admin",
    requestedDate: todayIso(state),
    dueDate: inspection.result === "Fail" ? todayIso(state) : addDays(todayIso(state), 3),
    startedDate: "",
    completedDate: "",
    estimatedHours: 2,
    actualHours: 0,
    laborCost: 0,
    partsCost: 0,
    downtimeHours: 0,
    findings: inspection.failedChecks,
    resolution: "",
    evidenceUri: inspection.evidenceUri
  });
  if (!created.ok) return created;
  const workOrder = activeRows(state, "workOrders").at(-1);
  inspection.followUpWorkOrderId = workOrder.id;
  inspection.updatedAt = nowIso();
  return { ok: true, metadata: { workOrder: workOrder.number } };
}

function restockPart(row, payload) {
  row.onHand = roundQuantity(Number(row.onHand) + Number(payload.quantity));
  if (payload.unitCost !== "" && payload.unitCost !== undefined) row.unitCost = roundMoney(payload.unitCost);
  row.status = derivePartStatus(row);
}

function synchronizeAssetMeter(state, reading, force = false) {
  const asset = findRow(state, "assets", reading.assetId);
  if (!asset) return;
  const latest = activeRows(state, "meterReadings")
    .filter((row) => row.assetId === reading.assetId)
    .sort((left, right) => compareMeterReadings(right, left))[0];
  if (force || latest?.id === reading.id) {
    asset.meterValue = Number(reading.value);
    asset.meterUnit = reading.unit;
    asset.updatedAt = nowIso();
  }
}

function applyExistingMeter(state, reading) {
  const latest = activeRows(state, "meterReadings")
    .filter((row) => row.assetId === reading.assetId)
    .sort((left, right) => compareMeterReadings(right, left))[0];
  if (latest?.id !== reading.id) return result(["Only the latest reading for an asset can be applied."]);
  const asset = findRow(state, "assets", reading.assetId);
  if (!asset) return result(["Asset was not found."], null, 404);
  if (reading.unit !== asset.meterUnit) return result([`Reading unit must match the asset meter unit (${asset.meterUnit}).`]);
  if (Number(reading.value) < Number(asset.meterValue)) return result([`Reading cannot roll the asset meter back below ${asset.meterValue}.`]);
  synchronizeAssetMeter(state, reading, true);
  return { ok: true, metadata: { asset: asset.assetTag, value: reading.value, unit: reading.unit } };
}

function advancePreventiveSchedule(state, schedule, completedDate) {
  if (schedule.lastDueDate && schedule.lastDueDate >= completedDate) return;
  schedule.lastDueDate = completedDate;
  if (schedule.triggerType.includes("Calendar")) schedule.nextDueDate = addDays(completedDate, Number(schedule.intervalDays));
  if (schedule.triggerType.includes("meter") || schedule.triggerType === "Meter") {
    const asset = findRow(state, "assets", schedule.assetId);
    schedule.lastMeter = Number(asset?.meterValue || schedule.lastMeter);
    schedule.nextMeter = Number(schedule.lastMeter) + Number(schedule.meterInterval);
  }
  schedule.updatedAt = nowIso();
}

function validateSnapshot(snapshot) {
  if (!snapshot || typeof snapshot !== "object" || Array.isArray(snapshot)) return result(["Import must be a JSON object."]);
  if (snapshot.product !== APP_CONFIG.slug) return result([`Import must declare product ${APP_CONFIG.slug}.`]);
  if (snapshot.schemaVersion !== 1) return result(["Import schemaVersion must be 1."]);
  if (!validTimestamp(snapshot.exportedAt)) return result(["Import exportedAt must be a valid ISO timestamp."]);
  if (!snapshot.workspace || typeof snapshot.workspace !== "object") return result(["Import is missing workspace settings."]);
  const errors = [];
  for (const key of collectionKeys()) if (!Array.isArray(snapshot[key])) errors.push(`Import must include a ${key} array.`);
  if (!Array.isArray(snapshot.activity)) errors.push("Import must include an activity array.");
  else if (snapshot.activity.length === 0) errors.push("Import activity must contain at least one durable event.");
  if (errors.length) return result(errors);
  const workspaceValidation = validateWorkspace(snapshot.workspace);
  if (!workspaceValidation.ok) errors.push(...workspaceValidation.errors.map((error) => `Workspace: ${error}`));
  const sessionValidation = validateSession(snapshot.session || {});
  if (!sessionValidation.ok) errors.push(...sessionValidation.errors.map((error) => `Session: ${error}`));
  if (!safeId(snapshot.workspace.id)) errors.push("Workspace id must be a safe identifier between 1 and 128 characters.");
  if (!validTimestamp(snapshot.workspace.createdAt) || !validTimestamp(snapshot.workspace.updatedAt)) errors.push("Workspace timestamps must be valid ISO timestamps.");
  if (!safeId(snapshot.session?.userId)) errors.push("Session userId must be a safe identifier between 1 and 128 characters.");
  const incoming = normalizeState(snapshot);
  incoming.workspace = {
    id: snapshot.workspace.id,
    ...(workspaceValidation.ok ? workspaceValidation.value : {}),
    createdAt: snapshot.workspace.createdAt,
    updatedAt: snapshot.workspace.updatedAt
  };
  incoming.session = {
    userId: snapshot.session?.userId,
    ...(sessionValidation.ok ? sessionValidation.value : {})
  };
  for (const key of collectionKeys()) {
    const ids = new Set();
    for (const row of incoming[key]) {
      if (!row || typeof row !== "object" || Array.isArray(row)) {
        errors.push(`${key} contains a non-object record.`);
        continue;
      }
      if (!safeId(row.id)) errors.push(`${key} contains an unsafe id; ids must be 1–128 characters using letters, numbers, dot, underscore, colon, or hyphen.`);
      else if (ids.has(row.id)) errors.push(`${key} contains duplicate id ${row.id}.`);
      ids.add(row.id);
      if (!validTimestamp(row.createdAt) || !validTimestamp(row.updatedAt) || (row.archivedAt !== null && !validTimestamp(row.archivedAt))) {
        errors.push(`${key}/${row.id || "unknown"} must have valid createdAt, updatedAt, and archive timestamps.`);
      }
    }
  }
  if (errors.length) return result(errors);
  const normalizedCollections = {};
  const operationKeys = new Set();
  for (const key of collectionKeys()) {
    normalizedCollections[key] = [];
    for (const row of incoming[key]) {
      const candidate = { ...row };
      let partsUsed;
      if (key === "workOrders") {
        const partsValidation = validatePartsUsed(incoming, row.partsUsed, row.id, operationKeys);
        if (!partsValidation.ok) errors.push(...partsValidation.errors);
        partsUsed = partsValidation.ok ? partsValidation.value : [];
        candidate.partsCost = canonicalPartsCost(partsUsed);
        candidate.laborCost = row.status === "Completed"
          ? roundMoney(Number(row.actualHours || 0) * Number(incoming.workspace.defaultLaborRate || 0))
          : 0;
      }
      const validation = validateEntity(incoming, key, candidate, row, {
        importing: true,
        allowArchivedRelations: Boolean(row.archivedAt)
      });
      if (!validation.ok) {
        errors.push(`${key}/${row.id}: ${validation.errors.join(" ")}`);
        continue;
      }
      normalizedCollections[key].push({
        id: row.id,
        ...validation.value,
        ...(key === "workOrders" ? { partsUsed } : {}),
        archivedAt: row.archivedAt,
        createdAt: row.createdAt,
        updatedAt: row.updatedAt
      });
    }
  }
  const activityValidation = validateActivity(snapshot.activity, incoming);
  if (!activityValidation.ok) errors.push(...activityValidation.errors);
  if (errors.length) return result(errors);
  for (const key of collectionKeys()) incoming[key] = normalizedCollections[key];
  for (const asset of activeRows(incoming, "assets")) {
    const latest = activeRows(incoming, "meterReadings")
      .filter((reading) => reading.assetId === asset.id)
      .sort((left, right) => compareMeterReadings(right, left))[0];
    if (latest) {
      asset.meterValue = Number(latest.value);
      asset.meterUnit = latest.unit;
    }
  }
  incoming.activity = activityValidation.value;
  return result([], incoming);
}

function computeMetric(state, metric) {
  const active = activeRows(state, metric.collection);
  const rows = metric.collection === "workOrders" && ["sum", "sumFields"].includes(metric.type)
    ? [...active, ...(state.workOrders || []).filter((row) => row.archivedAt && row.status === "Completed")]
    : active;
  if (metric.type === "count") return rows.length;
  if (metric.type === "countWhere") return rows.filter((row) => matchesWhere(row, metric.where)).length;
  if (metric.type === "overdue") {
    return rows.filter((row) => matchesWhere(row, metric.where) && validDate(row[metric.dateField]) && row[metric.dateField] < todayIso(state)).length;
  }
  if (metric.type === "sum") return roundQuantity(rows.reduce((sum, row) => sum + Number(row[metric.field] || 0), 0));
  if (metric.type === "sumFields") return roundMoney(rows.reduce((sum, row) => sum + metric.fields.reduce((subtotal, field) => subtotal + Number(row[field] || 0), 0), 0));
  if (metric.type === "preventiveCompliance") {
    const active = rows.filter((row) => row.status === "Active");
    if (!active.length) return 100;
    return Math.round((active.filter((row) => !preventiveOverdue(state, row)).length / active.length) * 100);
  }
  if (metric.type === "lowStock") return rows.filter((row) => row.status !== "Discontinued" && Number(row.onHand) <= Number(row.reorderPoint)).length;
  if (metric.type === "assetAvailability") {
    const eligible = rows.filter((row) => row.status !== "Retired");
    if (!eligible.length) return 100;
    return Math.round((eligible.filter((row) => row.status === "Operational").length / eligible.length) * 100);
  }
  return 0;
}

function preventiveOverdue(state, schedule) {
  const calendarDue = schedule.triggerType.includes("Calendar") && validDate(schedule.nextDueDate) && schedule.nextDueDate < todayIso(state);
  const asset = activeRows(state, "assets").find((row) => row.id === schedule.assetId);
  const meterDue = (schedule.triggerType.includes("meter") || schedule.triggerType === "Meter") && Number(schedule.nextMeter) > 0 && Number(asset?.meterValue || 0) >= Number(schedule.nextMeter);
  return calendarDue || meterDue;
}

function buildAlerts(state) {
  const alerts = [];
  for (const work of activeRows(state, "workOrders")) {
    if (!["Completed", "Cancelled"].includes(work.status) && work.dueDate < todayIso(state)) {
      alerts.push({ type: "danger", collection: "workOrders", id: work.id, title: `${work.number} is overdue`, detail: `${work.title} was due ${work.dueDate}.` });
    }
  }
  for (const schedule of activeRows(state, "preventiveSchedules")) {
    if (schedule.status === "Active" && preventiveOverdue(state, schedule)) {
      alerts.push({ type: "warning", collection: "preventiveSchedules", id: schedule.id, title: `${schedule.name} is due`, detail: relationLabel(state, "assets", schedule.assetId) });
    }
  }
  for (const part of activeRows(state, "parts")) {
    if (part.status === "Out of stock") alerts.push({ type: "danger", collection: "parts", id: part.id, title: `${part.sku} is out of stock`, detail: part.name });
  }
  return alerts.slice(0, 12);
}

function findActiveDependent(state, targetCollection, targetId) {
  for (const collection of APP_CONFIG.collections) {
    for (const field of collection.fields.filter((item) => ["relation", "relationMany"].includes(item.type) && item.collection === targetCollection)) {
      const row = activeRows(state, collection.key).find((item) => {
        if (collection.key === targetCollection && item.id === targetId) return false;
        return field.type === "relation" ? item[field.name] === targetId : (item[field.name] || []).includes(targetId);
      });
      if (row) return { collection, label: row[collection.displayField] || row.id };
    }
  }
  return null;
}

function actionStatus(collectionKey, row) {
  if (collectionKey === "inspections") return row.result;
  return row.status || "";
}

function nextWorkOrderNumber(state) {
  const prefix = clean(state.workspace.workOrderPrefix).toUpperCase();
  return `${prefix}-${Number(state.workspace.nextWorkOrderNumber)}`;
}

function preventiveDueDate(state, schedule) {
  if (schedule.nextDueDate && schedule.nextDueDate >= todayIso(state)) return schedule.nextDueDate;
  return todayIso(state);
}

function derivePartStatus(part) {
  if (part?.status === "Discontinued") return "Discontinued";
  const onHand = Number(part?.onHand || 0);
  if (onHand <= 0) return "Out of stock";
  if (onHand <= Number(part?.reorderPoint || 0)) return "Low stock";
  return "In stock";
}

function relationLabel(state, collectionKey, id) {
  const collection = getCollectionConfig(collectionKey);
  const row = (state[collectionKey] || []).find((item) => item.id === id);
  return row?.[collection.displayField] || id || "Unassigned";
}

function priorityScore(state, row) {
  const priority = { Emergency: 400, High: 300, Medium: 200, Low: 100 }[row.priority] || 0;
  const overdue = row.dueDate < todayIso(state) ? 1000 : 0;
  return overdue + priority;
}

function matchesWhere(row, where = {}) {
  for (const [field, expected] of Object.entries(where || {})) {
    const actual = row[field];
    if (Array.isArray(expected) && !expected.includes(actual)) return false;
    if (expected && typeof expected === "object" && !Array.isArray(expected)) {
      if ("not" in expected && actual === expected.not) return false;
      if ("notIn" in expected && expected.notIn.includes(actual)) return false;
      if ("in" in expected && !expected.in.includes(actual)) return false;
    } else if (!Array.isArray(expected) && actual !== expected) return false;
  }
  return true;
}

function findRow(state, collectionKey, id) {
  return activeRows(state, collectionKey).find((row) => row.id === id);
}

function validatePartsUsed(state, input, workOrderId, globalOperationKeys = new Set()) {
  if (!Array.isArray(input)) return result([`workOrders/${workOrderId}: partsUsed must be an array.`]);
  const errors = [];
  const parts = new Set((state.parts || []).map((part) => part.id));
  const value = input.map((usage, index) => {
    const key = effectiveOperationKey(workOrderId, usage, index);
    if (!usage || typeof usage !== "object" || Array.isArray(usage)) errors.push(`workOrders/${workOrderId}: partsUsed/${index} must be an object.`);
    if (!safeId(usage?.partId) || !parts.has(usage?.partId)) errors.push(`workOrders/${workOrderId}: partsUsed/${index} must reference an existing part.`);
    if (!(Number(usage?.quantity) > 0) || !Number.isFinite(Number(usage?.quantity))) errors.push(`workOrders/${workOrderId}: partsUsed/${index} quantity must be positive and finite.`);
    if (Number(usage?.unitCost) < 0 || !Number.isFinite(Number(usage?.unitCost))) errors.push(`workOrders/${workOrderId}: partsUsed/${index} unit cost must be nonnegative and finite.`);
    if (!validTimestamp(usage?.issuedAt)) errors.push(`workOrders/${workOrderId}: partsUsed/${index} issuedAt must be a valid ISO timestamp.`);
    if (!clean(usage?.actor) || clean(usage?.actor).length > 100) errors.push(`workOrders/${workOrderId}: partsUsed/${index} actor is invalid.`);
    if (!safeId(key) || globalOperationKeys.has(key)) errors.push(`workOrders/${workOrderId}: partsUsed/${index} operation key is invalid or duplicated across the workspace.`);
    globalOperationKeys.add(key);
    return {
      partId: usage?.partId,
      quantity: roundQuantity(usage?.quantity),
      unitCost: roundMoney(usage?.unitCost),
      issuedAt: usage?.issuedAt,
      actor: clean(usage?.actor),
      operationKey: key
    };
  });
  return result(errors, value);
}

function findPriorPartOperation(state, action, payload) {
  if (!["issuePartToWork", "issuePart"].includes(action.type)) return null;
  const operationKey = clean(payload?.operationKey);
  if (!operationKey) return null;
  const workOrderId = clean(action.type === "issuePartToWork" ? payload?.id : payload?.workOrderId);
  const partId = clean(action.type === "issuePartToWork" ? payload?.partId : payload?.id);
  const priorMatch = findPartOperation(state, operationKey);
  if (!priorMatch) return null;
  if (priorMatch.workOrder.id !== workOrderId || priorMatch.usage.partId !== partId || Number(priorMatch.usage.quantity) !== Number(payload?.quantity)) {
    return result(["Operation key was already used for a different part issue."]);
  }
  return { ok: true, idempotent: true };
}

function findPartOperation(state, operationKey) {
  for (const workOrder of state.workOrders || []) {
    const usages = Array.isArray(workOrder.partsUsed) ? workOrder.partsUsed : [];
    const index = usages.findIndex((usage, usageIndex) => effectiveOperationKey(workOrder.id, usage, usageIndex) === operationKey);
    if (index >= 0) return { workOrder, usage: usages[index] };
  }
  return null;
}

function effectiveOperationKey(workOrderId, usage, index) {
  return clean(usage?.operationKey) || `legacy:${workOrderId}:${index}`;
}

function validateActivity(input, state) {
  const errors = [];
  const ids = new Set();
  const value = input.map((event, index) => {
    const prefix = `activity/${index}`;
    if (!event || typeof event !== "object" || Array.isArray(event)) {
      errors.push(`${prefix} must be an object.`);
      return null;
    }
    if (!safeId(event.id) || ids.has(event.id)) errors.push(`${prefix} id is unsafe or duplicated.`);
    ids.add(event.id);
    if (!clean(event.actor) || clean(event.actor).length > 100) errors.push(`${prefix} actor is invalid.`);
    if (!clean(event.action) || clean(event.action).length > 200) errors.push(`${prefix} action is invalid.`);
    if (!activityEntityTypes.has(event.entityType)) errors.push(`${prefix} entityType is invalid.`);
    if (!safeId(event.entityId)) errors.push(`${prefix} entityId is unsafe.`);
    const targetExists = event.entityType === "workspace"
      ? event.entityId === state.workspace.id
      : (state[event.entityType] || []).some((row) => row.id === event.entityId);
    if (!targetExists) errors.push(`${prefix} must reference an existing record.`);
    if (!event.metadata || typeof event.metadata !== "object" || Array.isArray(event.metadata)) errors.push(`${prefix} metadata must be an object.`);
    if (!validTimestamp(event.createdAt)) errors.push(`${prefix} createdAt must be a valid ISO timestamp.`);
    return {
      id: event.id,
      actor: clean(event.actor),
      action: clean(event.action),
      entityType: event.entityType,
      entityId: event.entityId,
      metadata: clone(event.metadata || {}),
      createdAt: event.createdAt
    };
  }).filter(Boolean);
  return result(errors, value);
}

function mergeActivity(current, incoming) {
  const events = new Map((current || []).map((event) => [event.id, clone(event)]));
  for (const event of incoming) {
    const existing = events.get(event.id);
    if (existing && JSON.stringify(existing) !== JSON.stringify(event)) return result([`Activity event ${event.id} conflicts with durable history.`]);
    if (!existing) events.set(event.id, clone(event));
  }
  return result([], [...events.values()].sort((left, right) => right.createdAt.localeCompare(left.createdAt)));
}

function canonicalPartsCost(partsUsed = []) {
  return roundMoney(partsUsed.reduce((sum, usage) => sum + Number(usage.quantity) * Number(usage.unitCost), 0));
}

function compareMeterReadings(left, right) {
  return String(left.readingDate || "").localeCompare(String(right.readingDate || ""))
    || String(left.createdAt || "").localeCompare(String(right.createdAt || ""))
    || String(left.id || "").localeCompare(String(right.id || ""));
}

function rowSummary(collection, row) {
  const summary = { [collection.displayField]: row[collection.displayField] || row.id };
  if (row.number) summary.number = row.number;
  if (row.assetTag) summary.assetTag = row.assetTag;
  if (row.sku) summary.sku = row.sku;
  return summary;
}

function result(errors, value = null, status = 200) {
  return errors.length ? { ok: false, errors, status: status >= 400 ? status : 400 } : { ok: true, value, status };
}

export function addDays(dateValue, days) {
  const date = new Date(`${dateValue}T12:00:00Z`);
  date.setUTCDate(date.getUTCDate() + Number(days));
  return date.toISOString().slice(0, 10);
}

function arrayValue(raw) {
  if (Array.isArray(raw)) return raw;
  if (typeof raw === "string") return raw.split(",");
  return [];
}

function isEmptyValue(value) {
  return value === "" || value === null || value === undefined || (Array.isArray(value) && value.length === 0);
}

function isReasonableUrlOrPath(value) {
  return /^(https?:\/\/|file:\/\/|\/|\.\/|\.\.\/|[a-zA-Z]:\\)/.test(value);
}

function safeId(value) {
  return typeof value === "string" && safeIdPattern.test(value);
}

function validTimestamp(value) {
  if (typeof value !== "string" || !/^\d{4}-\d{2}-\d{2}T/.test(value)) return false;
  const date = new Date(value);
  return !Number.isNaN(date.getTime()) && date.toISOString() === value;
}

function comparable(value) {
  return typeof value === "string" ? value.trim().toLowerCase() : value;
}

function validDate(value) {
  const cleanValue = clean(value);
  if (!isoDatePattern.test(cleanValue)) return false;
  const date = new Date(`${cleanValue}T00:00:00Z`);
  return !Number.isNaN(date.getTime()) && date.toISOString().slice(0, 10) === cleanValue;
}

function dateTime(value) {
  const time = new Date(value).getTime();
  return Number.isFinite(time) ? time : Number.MAX_SAFE_INTEGER;
}

function countBy(rows, field) {
  return rows.reduce((counts, row) => {
    const key = row[field] || "Unspecified";
    counts[key] = (counts[key] || 0) + 1;
    return counts;
  }, {});
}

function roundMoney(value) {
  return Math.round((Number(value) + Number.EPSILON) * 100) / 100;
}

function roundQuantity(value) {
  return Math.round((Number(value) + Number.EPSILON) * 10_000) / 10_000;
}

function flatten(value, prefix = "", output = {}) {
  if (Array.isArray(value)) {
    output[prefix] = value.map((item) => typeof item === "object" ? JSON.stringify(item) : item).join("|");
    return output;
  }
  if (value && typeof value === "object") {
    for (const [key, nested] of Object.entries(value)) flatten(nested, prefix ? `${prefix}.${key}` : key, output);
    return output;
  }
  output[prefix] = value ?? "";
  return output;
}

function csvCell(value) {
  let text = String(value ?? "");
  if (typeof value === "string" && /^[\s\uFEFF]*[=+\-@]/.test(text)) text = `'${text}`;
  if (/[",\n]/.test(text)) return `"${text.replaceAll('"', '""')}"`;
  return text;
}
