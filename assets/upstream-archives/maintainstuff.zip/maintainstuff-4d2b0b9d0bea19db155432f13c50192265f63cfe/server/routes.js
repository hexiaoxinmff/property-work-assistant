import {
  APP_CONFIG
} from "./config.js";
import {
  applyWorkflowAction,
  archiveEntity,
  collectionKeys,
  createEntity,
  exportSnapshot,
  getCollectionConfig,
  importSnapshot,
  shapeState,
  toCsv,
  updateEntity,
  updateSession,
  updateWorkspace,
  restoreEntity
} from "./domain.js";
import { readDb, writeDb } from "./store.js";
import {
  ALL_ROLES,
  compareRecords,
  recordSearchText,
  rolesFor,
  rolesForAction,
  rolesForCollection
} from "../public/contracts.js";

const collectionSet = new Set(collectionKeys());
const allRoles = [...ALL_ROLES];
let mutationQueue = Promise.resolve();

export async function handleApi(req, res, url) {
  try {
    if (["POST", "PATCH", "PUT", "DELETE"].includes(req.method || "")) {
      const guard = validateMutationRequest(req);
      if (!guard.ok) return sendJson(res, guard.status, { errors: guard.errors });
    }

    if (req.method === "GET" && url.pathname === "/api/state") {
      const context = await readAuthorized(req, allRoles);
      if (!context.ok) return sendJson(res, context.status, { errors: context.errors });
      context.db.session = context.identity;
      const value = shapeState(context.db);
      value.config.proxyIdentityActive = trustProxyIdentity();
      return sendJson(res, 200, value);
    }

    if (req.method === "GET" && url.pathname === "/api/export/all.json") {
      const context = await readAuthorized(req, rolesFor("fullData"));
      if (!context.ok) return sendJson(res, context.status, { errors: context.errors });
      return download(res, `${APP_CONFIG.slug}-workspace.json`, "application/json", `${JSON.stringify(exportSnapshot(context.db), null, 2)}\n`);
    }

    const exportMatch = url.pathname.match(/^\/api\/export\/([a-zA-Z0-9]+)\.(json|csv)$/);
    if (req.method === "GET" && exportMatch) {
      const [, collectionKey, format] = exportMatch;
      if (!collectionSet.has(collectionKey)) return sendJson(res, 400, { errors: ["Export collection is not supported."] });
      const context = await readAuthorized(req, rolesForCollection("export", collectionKey));
      if (!context.ok) return sendJson(res, context.status, { errors: context.errors });
      const rows = filterExportRows(context.db, collectionKey, url.searchParams);
      if (format === "json") return download(res, `${APP_CONFIG.slug}-${collectionKey}.json`, "application/json", `${JSON.stringify(rows, null, 2)}\n`);
      return download(res, `${APP_CONFIG.slug}-${collectionKey}.csv`, "text/csv", toCsv(rows));
    }

    if (req.method === "POST" && url.pathname === "/api/import") {
      return await mutate(req, res, rolesFor("fullData"), async (db) => importSnapshot(db, await readJson(req)));
    }

    if (req.method === "PATCH" && url.pathname === "/api/workspace") {
      return await mutate(req, res, rolesFor("workspace"), async (db) => updateWorkspace(db, await readJson(req)));
    }

    if (req.method === "PATCH" && url.pathname === "/api/session") {
      if (trustProxyIdentity()) return sendJson(res, 403, { errors: ["Local session changes are disabled while trusted proxy identity is enabled."] });
      return await mutate(req, res, allRoles, async (db) => updateSession(db, await readJson(req)));
    }

    const actionMatch = url.pathname.match(/^\/api\/actions\/([^/]+)$/);
    if (req.method === "POST" && actionMatch) {
      const actionKey = actionMatch[1];
      return await mutate(req, res, rolesForAction(actionKey), async (db) => applyWorkflowAction(db, actionKey, await readJson(req)));
    }

    const collectionRoot = url.pathname.match(/^\/api\/([a-zA-Z0-9]+)$/);
    if (collectionRoot && req.method === "POST" && collectionSet.has(collectionRoot[1])) {
      return await mutate(req, res, rolesForCollection("create", collectionRoot[1]), async (db) => createEntity(db, collectionRoot[1], await readJson(req)));
    }

    const itemMatch = url.pathname.match(/^\/api\/([a-zA-Z0-9]+)\/([^/]+)(?:\/(archive|restore))?$/);
    if (itemMatch && collectionSet.has(itemMatch[1])) {
      const [, collectionKey, encodedId, operation] = itemMatch;
      const id = decodePathId(encodedId);
      if (!id.ok) return sendJson(res, 400, { errors: id.errors });
      if (req.method === "PATCH" && !operation) return await mutate(req, res, rolesForCollection("edit", collectionKey), async (db) => updateEntity(db, collectionKey, id.value, await readJson(req)));
      if (req.method === "POST" && operation === "archive") return await mutate(req, res, rolesForCollection("lifecycle", collectionKey), async (db) => archiveEntity(db, collectionKey, id.value));
      if (req.method === "POST" && operation === "restore") return await mutate(req, res, rolesForCollection("lifecycle", collectionKey), async (db) => restoreEntity(db, collectionKey, id.value));
      if (req.method === "GET" && !operation) {
        const context = await readAuthorized(req, allRoles);
        if (!context.ok) return sendJson(res, context.status, { errors: context.errors });
        const row = (context.db[collectionKey] || []).find((item) => item.id === id.value);
        if (!row) return sendJson(res, 404, { errors: [`${getCollectionConfig(collectionKey).singular} was not found.`] });
        return sendJson(res, 200, row);
      }
    }

    return sendJson(res, 404, { errors: ["Route was not found."] });
  } catch (error) {
    if (!error.status || error.status >= 500) console.error(error);
    return sendJson(res, error.status || 500, { errors: [error.publicMessage || "Unexpected server error."] });
  }
}

export async function readJson(req) {
  const maximumBodyBytes = maxImportBytes();
  const declaredLength = Number(req.headers?.["content-length"] || 0);
  if (Number.isFinite(declaredLength) && declaredLength > maximumBodyBytes) throw requestError(413, importLimitMessage());
  const chunks = [];
  let bytes = 0;
  for await (const chunk of req) {
    const buffer = Buffer.isBuffer(chunk) ? chunk : Buffer.from(chunk);
    bytes += buffer.length;
    if (bytes > maximumBodyBytes) throw requestError(413, importLimitMessage());
    chunks.push(buffer);
  }
  const body = Buffer.concat(chunks).toString("utf8");
  if (!body.trim()) return {};
  try {
    return JSON.parse(body);
  } catch {
    throw requestError(400, "Request body must be valid JSON.");
  }
}

export function sendJson(res, status, payload) {
  res.writeHead(status, {
    "content-type": "application/json; charset=utf-8",
    "cache-control": "no-store",
    "x-content-type-options": "nosniff"
  });
  res.end(`${JSON.stringify(payload)}\n`);
}

async function mutate(req, res, roles, mutator) {
  const operation = mutationQueue.then(async () => {
    const context = await readAuthorized(req, roles);
    if (!context.ok) return sendJson(res, context.status, { errors: context.errors });
    const storedSession = context.db.session;
    context.db.session = context.identity;
    const result = await mutator(context.db);
    if (!result.ok) return sendJson(res, result.status || 400, { errors: result.errors });
    if (context.proxyIdentity) {
      context.db.session = storedSession;
      if (result.value && typeof result.value === "object" && result.value.config) result.value.session = context.identity;
    }
    if (result.value && typeof result.value === "object" && result.value.config) result.value.config.proxyIdentityActive = trustProxyIdentity();
    await writeDb(context.db);
    return sendJson(res, result.status || 200, result.value);
  });
  mutationQueue = operation.catch(() => undefined);
  return operation;
}

async function readAuthorized(req, roles) {
  const db = await readDb();
  const identity = resolveIdentity(req, db);
  if (!identity.ok) return identity;
  if (roles?.length && !roles.includes(identity.value.role)) {
    return { ok: false, status: 403, errors: [`Role ${identity.value.role || "Unassigned"} is not authorized for this operation.`] };
  }
  return { ok: true, db, identity: identity.value, proxyIdentity: identity.proxyIdentity };
}

function resolveIdentity(req, db) {
  if (!trustProxyIdentity()) return { ok: true, value: { ...db.session }, proxyIdentity: false };
  const userName = cleanHeader(req.headers?.[APP_CONFIG.proxyUserHeader]);
  const role = cleanHeader(req.headers?.[APP_CONFIG.proxyRoleHeader]);
  if (!userName || userName.length > 100 || !allRoles.includes(role)) {
    return { ok: false, status: 401, errors: [`Trusted proxy identity requires valid ${APP_CONFIG.proxyUserHeader} and ${APP_CONFIG.proxyRoleHeader} headers.`] };
  }
  return {
    ok: true,
    value: { userId: `proxy:${userName.toLowerCase().replace(/[^a-z0-9._:-]+/g, "-").slice(0, 120)}`, userName, role },
    proxyIdentity: true
  };
}

function validateMutationRequest(req) {
  const contentType = String(req.headers?.["content-type"] || "").toLowerCase();
  const mediaType = contentType.split(";", 1)[0].trim();
  if (mediaType !== "application/json") return { ok: false, status: 415, errors: ["Mutations require Content-Type: application/json."] };
  const fetchSite = cleanHeader(req.headers?.["sec-fetch-site"]).toLowerCase();
  if (fetchSite && !["same-origin", "none"].includes(fetchSite)) return { ok: false, status: 403, errors: ["Cross-site mutations are not allowed."] };
  const origin = cleanHeader(req.headers?.origin);
  if (origin && origin !== expectedOrigin(req)) return { ok: false, status: 403, errors: ["Mutation origin does not match this MaintainStuff server."] };
  return { ok: true };
}

function expectedOrigin(req) {
  const useProxy = trustProxyIdentity();
  const host = cleanHeader(useProxy ? req.headers?.["x-forwarded-host"] : req.headers?.host).split(",")[0].trim();
  const forwardedProto = cleanHeader(req.headers?.["x-forwarded-proto"]).split(",")[0].trim();
  const protocol = useProxy && forwardedProto ? forwardedProto : req.socket?.encrypted ? "https" : "http";
  return `${protocol}://${host}`;
}

function filterExportRows(db, collectionKey, params) {
  const archive = params.get("archive") || "all";
  const terms = (params.get("search") || "").toLowerCase().split(/\s+/).filter(Boolean);
  const field = params.get("filterField") || "";
  const expected = params.get("filterValue") || "";
  const sortField = params.get("sortField") || "";
  const direction = params.get("direction") === "desc" ? -1 : 1;
  const allowedFields = new Set(["id", "createdAt", "updatedAt", "archivedAt", ...getCollectionConfig(collectionKey).fields.map((item) => item.name)]);
  const rows = (db[collectionKey] || []).filter((row) => {
    if (archive === "active" && row.archivedAt) return false;
    if (archive === "archived" && !row.archivedAt) return false;
    const haystack = recordSearchText(db, APP_CONFIG.collections, row).toLowerCase();
    if (terms.some((term) => !haystack.includes(term))) return false;
    if (field && expected && allowedFields.has(field)) {
      const value = row[field];
      if (Array.isArray(value) ? !value.includes(expected) : String(value ?? "") !== expected) return false;
    }
    return true;
  });
  if (sortField && allowedFields.has(sortField)) rows.sort((left, right) => compareRecords(left, right, sortField, direction === -1 ? "desc" : "asc"));
  return rows;
}

function decodePathId(value) {
  try {
    return { ok: true, value: decodeURIComponent(value) };
  } catch {
    return { ok: false, errors: ["Record id is not valid URL encoding."] };
  }
}

function maxImportMb() {
  const configured = Number(process.env[APP_CONFIG.maxImportMbEnv] || APP_CONFIG.defaultMaxImportMb);
  return Number.isFinite(configured) && configured >= 1 && configured <= 1024 ? configured : APP_CONFIG.defaultMaxImportMb;
}

function maxImportBytes() {
  return Math.floor(maxImportMb() * 1024 * 1024);
}

function importLimitMessage() {
  return `Request body exceeds the ${maxImportMb()} MiB import limit configured by ${APP_CONFIG.maxImportMbEnv}.`;
}

function trustProxyIdentity() {
  return String(process.env[APP_CONFIG.trustProxyIdentityEnv] || "").toLowerCase() === "true";
}

function cleanHeader(value) {
  return Array.isArray(value) ? String(value[0] || "").trim() : String(value || "").trim();
}

function download(res, filename, contentType, body) {
  res.writeHead(200, {
    "content-type": `${contentType}; charset=utf-8`,
    "content-disposition": `attachment; filename="${filename}"`,
    "cache-control": "no-store",
    "x-content-type-options": "nosniff"
  });
  res.end(body);
}

function requestError(status, publicMessage) {
  const error = new Error(publicMessage);
  error.status = status;
  error.publicMessage = publicMessage;
  return error;
}
