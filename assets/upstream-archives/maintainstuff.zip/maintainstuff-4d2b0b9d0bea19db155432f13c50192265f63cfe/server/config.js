const workOrderStatuses = ["Requested", "Approved", "Scheduled", "In progress", "Waiting", "Completed", "Cancelled"];
const assetStatuses = ["Operational", "Limited service", "Down", "Retired"];
const meterUnits = ["Hours", "Cycles", "Miles", "Kilometers"];

export const APP_CONFIG = {
  slug: "maintainstuff",
  name: "MaintainStuff",
  description: "Own every asset, work order, maintenance interval, and service record—without per-technician or export fees.",
  port: 4221,
  dataEnv: "MAINTAINSTUFF_DATA",
  dataFile: "maintainstuff.json",
  maxImportMbEnv: "MAINTAINSTUFF_MAX_IMPORT_MB",
  defaultMaxImportMb: 100,
  trustProxyIdentityEnv: "MAINTAINSTUFF_TRUST_PROXY_IDENTITY",
  proxyUserHeader: "x-maintainstuff-user",
  proxyRoleHeader: "x-maintainstuff-role",
  primaryCollection: "workOrders",
  primaryLabel: "Work order",
  displayDateField: "dueDate",
  theme: {
    accent: "#087f5b",
    accentDark: "#12231f",
    highlight: "#f59e0b",
    danger: "#c2413b"
  },
  workspaceFields: [
    { name: "organizationName", label: "Organization", type: "text", required: true, maxLength: 120 },
    { name: "sites", label: "Sites", type: "tags", required: true },
    { name: "defaultLaborRate", label: "Default labor rate", type: "number", required: true, min: 0, max: 10000, step: 0.01 },
    { name: "currency", label: "Currency", type: "select", options: ["USD", "CAD", "EUR", "GBP"], required: true },
    { name: "workOrderPrefix", label: "Work-order prefix", type: "text", required: true, pattern: "^[A-Za-z0-9-]{2,12}$", patternMessage: "Work-order prefix must be 2–12 letters, numbers, or hyphens." },
    { name: "nextWorkOrderNumber", label: "Next work-order number", type: "number", required: true, min: 1, max: 99999999, integer: true },
    { name: "timezone", label: "Operating timezone", type: "text", required: true, maxLength: 80 },
    { name: "criticalityPolicy", label: "Criticality policy", type: "textarea", required: true, maxLength: 1200 }
  ],
  sessionFields: [
    { name: "userName", label: "Operator name", type: "text", required: true, maxLength: 100 },
    { name: "role", label: "Operating role", type: "select", options: ["Maintenance manager", "Planner", "Technician", "Storeroom", "Administrator"], required: true }
  ],
  collections: [
    {
      key: "assets",
      label: "Asset Registry",
      navLabel: "Assets",
      singular: "Asset",
      prefix: "ast",
      icon: "asset",
      description: "Equipment identity, ownership, condition, location, warranty, and current meter state.",
      displayField: "name",
      defaultSort: "criticality:desc",
      tableFields: ["assetTag", "name", "site", "status", "criticality"],
      filters: ["status", "criticality", "site", "category", "owner"],
      fields: [
        { name: "assetTag", label: "Asset tag", type: "text", required: true, unique: true, maxLength: 40 },
        { name: "name", label: "Asset name", type: "text", required: true, maxLength: 140 },
        { name: "site", label: "Site", type: "workspaceOption", workspaceField: "sites", required: true },
        { name: "status", label: "Status", type: "select", options: assetStatuses, required: true },
        { name: "criticality", label: "Criticality", type: "select", options: ["Low", "Medium", "High", "Critical"], required: true },
        { name: "location", label: "Location", type: "text", required: true, maxLength: 140 },
        { name: "category", label: "Category", type: "select", options: ["Production", "Facilities", "Utilities", "Material handling", "Fleet", "Safety"], required: true },
        { name: "manufacturer", label: "Manufacturer", type: "text", maxLength: 100 },
        { name: "model", label: "Model", type: "text", maxLength: 100 },
        { name: "serialNumber", label: "Serial number", type: "text", maxLength: 100 },
        { name: "owner", label: "Asset owner", type: "text", required: true, maxLength: 100 },
        { name: "installDate", label: "Installed", type: "date" },
        { name: "warrantyDate", label: "Warranty through", type: "date" },
        { name: "meterValue", label: "Current meter", type: "number", required: true, min: 0, max: 1000000000000, step: 0.01 },
        { name: "meterUnit", label: "Meter unit", type: "select", options: meterUnits, required: true },
        { name: "documentationUri", label: "Documentation URI", type: "url" }
      ]
    },
    {
      key: "workOrders",
      label: "Work Orders",
      navLabel: "Work orders",
      singular: "Work order",
      prefix: "wo",
      icon: "work",
      description: "Plan, approve, assign, execute, cost, and close corrective and preventive work.",
      displayField: "title",
      defaultSort: "dueDate:asc",
      tableFields: ["number", "title", "priority", "status", "dueDate"],
      filters: ["status", "priority", "workType", "technician", "assetId"],
      fields: [
        { name: "number", label: "Work-order number", type: "text", required: true, unique: true, generated: true, maxLength: 40 },
        { name: "title", label: "Work summary", type: "text", required: true, maxLength: 180 },
        { name: "assetId", label: "Asset", type: "relation", collection: "assets", required: true },
        { name: "preventiveScheduleId", label: "Preventive schedule", type: "relation", collection: "preventiveSchedules" },
        { name: "workType", label: "Work type", type: "select", options: ["Corrective", "Preventive", "Inspection", "Calibration", "Safety"], required: true },
        { name: "priority", label: "Priority", type: "select", options: ["Low", "Medium", "High", "Emergency"], required: true },
        { name: "status", label: "Status", type: "select", options: workOrderStatuses, required: true, workflowControlled: true, default: "Requested" },
        { name: "requester", label: "Requester", type: "text", required: true, maxLength: 100 },
        { name: "technician", label: "Technician", type: "text", required: true, maxLength: 100 },
        { name: "requestedDate", label: "Requested date", type: "date", required: true },
        { name: "dueDate", label: "Due date", type: "date", required: true },
        { name: "startedDate", label: "Started date", type: "date" },
        { name: "completedDate", label: "Completed date", type: "date" },
        { name: "estimatedHours", label: "Estimated hours", type: "number", required: true, min: 0, max: 100000, step: 0.25 },
        { name: "actualHours", label: "Actual hours", type: "number", required: true, min: 0, max: 100000, step: 0.25, default: 0 },
        { name: "laborCost", label: "Labor cost", type: "number", required: true, min: 0, max: 1000000000, step: 0.01, computed: true, default: 0 },
        { name: "partsCost", label: "Parts cost", type: "number", required: true, min: 0, max: 1000000000, step: 0.01, computed: true, default: 0 },
        { name: "downtimeHours", label: "Downtime hours", type: "number", required: true, min: 0, max: 100000, step: 0.25, default: 0 },
        { name: "findings", label: "Findings", type: "textarea", maxLength: 3000 },
        { name: "resolution", label: "Resolution / completion notes", type: "textarea", maxLength: 3000 },
        { name: "evidenceUri", label: "Evidence URI", type: "url" }
      ]
    },
    {
      key: "preventiveSchedules",
      label: "Preventive Maintenance",
      navLabel: "Preventive",
      singular: "Preventive schedule",
      prefix: "pm",
      icon: "calendar",
      description: "Calendar and meter-based maintenance plans with accountable next-due thresholds.",
      displayField: "name",
      defaultSort: "nextDueDate:asc",
      tableFields: ["name", "assetId", "triggerType", "status", "nextDueDate"],
      filters: ["status", "triggerType", "owner", "assetId"],
      fields: [
        { name: "name", label: "Schedule name", type: "text", required: true, maxLength: 160 },
        { name: "assetId", label: "Asset", type: "relation", collection: "assets", required: true },
        { name: "triggerType", label: "Trigger", type: "select", options: ["Calendar", "Meter", "Calendar + meter"], required: true },
        { name: "status", label: "Status", type: "select", options: ["Active", "Paused", "Retired"], required: true },
        { name: "intervalDays", label: "Calendar interval (days)", type: "number", required: true, min: 0, max: 3650, integer: true },
        { name: "meterInterval", label: "Meter interval", type: "number", required: true, min: 0, max: 1000000000, step: 0.01 },
        { name: "lastDueDate", label: "Last completed date", type: "date" },
        { name: "nextDueDate", label: "Next due date", type: "date" },
        { name: "lastMeter", label: "Last completed meter", type: "number", required: true, min: 0, max: 1000000000000, step: 0.01 },
        { name: "nextMeter", label: "Next due meter", type: "number", required: true, min: 0, max: 1000000000000, step: 0.01 },
        { name: "owner", label: "Plan owner", type: "text", required: true, maxLength: 100 },
        { name: "procedure", label: "Procedure", type: "textarea", required: true, maxLength: 4000 }
      ]
    },
    {
      key: "inspections",
      label: "Inspections",
      navLabel: "Inspections",
      singular: "Inspection",
      prefix: "ins",
      icon: "inspection",
      description: "Record inspection evidence, scoring, failed checks, and corrective follow-up.",
      displayField: "template",
      defaultSort: "inspectionDate:desc",
      tableFields: ["template", "assetId", "result", "score", "inspectionDate"],
      filters: ["result", "inspector", "assetId", "template"],
      fields: [
        { name: "template", label: "Inspection template", type: "text", required: true, maxLength: 160 },
        { name: "assetId", label: "Asset", type: "relation", collection: "assets", required: true },
        { name: "workOrderId", label: "Work order", type: "relation", collection: "workOrders" },
        { name: "followUpWorkOrderId", label: "Follow-up work order", type: "relation", collection: "workOrders", computed: true },
        { name: "inspector", label: "Inspector", type: "text", required: true, maxLength: 100 },
        { name: "inspectionDate", label: "Inspection date", type: "date", required: true },
        { name: "result", label: "Result", type: "select", options: ["Pass", "Conditional", "Fail"], required: true },
        { name: "score", label: "Score", type: "number", required: true, min: 0, max: 100, step: 1 },
        { name: "failedChecks", label: "Failed checks", type: "textarea", maxLength: 2000 },
        { name: "notes", label: "Inspection notes", type: "textarea", maxLength: 3000 },
        { name: "evidenceUri", label: "Evidence URI", type: "url" }
      ]
    },
    {
      key: "parts",
      label: "Parts & Inventory",
      navLabel: "Parts",
      singular: "Part",
      prefix: "prt",
      icon: "parts",
      description: "Track maintenance stock, reorder exposure, unit cost, suppliers, and storeroom movements.",
      displayField: "name",
      defaultSort: "onHand:asc",
      tableFields: ["sku", "name", "onHand", "reorderPoint", "status"],
      filters: ["status", "site", "category", "supplier"],
      fields: [
        { name: "sku", label: "SKU", type: "text", required: true, unique: true, maxLength: 60 },
        { name: "name", label: "Part name", type: "text", required: true, maxLength: 160 },
        { name: "onHand", label: "On hand", type: "number", required: true, min: 0, max: 1000000000, step: 0.01 },
        { name: "reorderPoint", label: "Reorder point", type: "number", required: true, min: 0, max: 1000000000, step: 0.01 },
        { name: "status", label: "Status", type: "select", options: ["In stock", "Low stock", "Out of stock", "Discontinued"], required: true, computed: true },
        { name: "category", label: "Category", type: "select", options: ["Mechanical", "Electrical", "Hydraulic", "Pneumatic", "Lubrication", "Safety", "Consumable"], required: true },
        { name: "site", label: "Site", type: "workspaceOption", workspaceField: "sites", required: true },
        { name: "bin", label: "Storage bin", type: "text", required: true, maxLength: 80 },
        { name: "supplier", label: "Supplier", type: "text", required: true, maxLength: 120 },
        { name: "unitCost", label: "Unit cost", type: "number", required: true, min: 0, max: 100000000, step: 0.01 }
      ]
    },
    {
      key: "meterReadings",
      label: "Meter Readings",
      navLabel: "Meters",
      singular: "Meter reading",
      prefix: "mtr",
      icon: "meter",
      description: "Preserve asset usage readings and synchronize the latest trustworthy meter state.",
      displayField: "readingDate",
      defaultSort: "readingDate:desc",
      tableFields: ["assetId", "value", "unit", "readingDate", "source"],
      filters: ["assetId", "unit", "source", "recordedBy"],
      fields: [
        { name: "assetId", label: "Asset", type: "relation", collection: "assets", required: true },
        { name: "value", label: "Reading", type: "number", required: true, min: 0, max: 1000000000000, step: 0.01 },
        { name: "unit", label: "Unit", type: "select", options: meterUnits, required: true },
        { name: "readingDate", label: "Reading date", type: "date", required: true },
        { name: "source", label: "Source", type: "select", options: ["Manual", "Inspection", "Work order", "Imported device"], required: true },
        { name: "recordedBy", label: "Recorded by", type: "text", required: true, maxLength: 100 },
        { name: "notes", label: "Notes", type: "textarea", maxLength: 2000 }
      ]
    }
  ],
  metrics: [
    { key: "openWorkOrders", label: "Open work", helper: "Excludes completed and cancelled", type: "countWhere", collection: "workOrders", where: { status: { notIn: ["Completed", "Cancelled"] } } },
    { key: "overdueWorkOrders", label: "Overdue work", helper: "Open and past due", type: "overdue", collection: "workOrders", dateField: "dueDate", where: { status: { notIn: ["Completed", "Cancelled"] } } },
    { key: "preventiveCompliance", label: "PM compliance", helper: "Active schedules not overdue", type: "preventiveCompliance", collection: "preventiveSchedules", format: "percent" },
    { key: "downtimeHours", label: "Downtime", helper: "Recorded work-order hours", type: "sum", collection: "workOrders", field: "downtimeHours", format: "hours" },
    { key: "maintenanceCost", label: "Maintenance cost", helper: "Labor and issued parts", type: "sumFields", collection: "workOrders", fields: ["laborCost", "partsCost"], format: "currency" },
    { key: "lowStockParts", label: "Low-stock parts", helper: "At or below reorder point", type: "lowStock", collection: "parts" },
    { key: "assetAvailability", label: "Asset availability", helper: "Operational active assets", type: "assetAvailability", collection: "assets", format: "percent" }
  ],
  actions: [
    { key: "mark-asset-down", label: "Mark down", collection: "assets", type: "assetStatus", value: "Down", activity: "marked asset down", allowedStatuses: ["Operational", "Limited service"] },
    { key: "return-asset-service", label: "Return to service", collection: "assets", type: "assetStatus", value: "Operational", activity: "returned asset to service", allowedStatuses: ["Down", "Limited service"] },
    { key: "approve-work-order", label: "Approve", collection: "workOrders", type: "workOrderStatus", value: "Approved", activity: "approved work order", allowedStatuses: ["Requested"] },
    { key: "schedule-work-order", label: "Schedule", collection: "workOrders", type: "workOrderStatus", value: "Scheduled", activity: "scheduled work order", allowedStatuses: ["Requested", "Approved"] },
    { key: "start-work-order", label: "Start work", collection: "workOrders", type: "startWorkOrder", activity: "started work order", allowedStatuses: ["Requested", "Approved", "Scheduled", "Waiting"] },
    { key: "hold-work-order", label: "Place on hold", collection: "workOrders", type: "holdWorkOrder", activity: "placed work order on hold", allowedStatuses: ["In progress"], fields: [
      { name: "resolution", label: "Hold reason", type: "textarea", required: true, maxLength: 2000 }
    ] },
    { key: "complete-work-order", label: "Complete work", collection: "workOrders", type: "completeWorkOrder", activity: "completed work order", allowedStatuses: ["In progress"], fields: [
      { name: "actualHours", label: "Actual labor hours", type: "number", required: true, minExclusive: 0, max: 100000, step: 0.25 },
      { name: "downtimeHours", label: "Downtime hours", type: "number", required: true, min: 0, max: 100000, step: 0.25 },
      { name: "findings", label: "Findings", type: "textarea", maxLength: 3000 },
      { name: "resolution", label: "Resolution / completion notes", type: "textarea", required: true, maxLength: 3000 },
      { name: "evidenceUri", label: "Evidence URI", type: "url" }
    ] },
    { key: "cancel-work-order", label: "Cancel", collection: "workOrders", type: "cancelWorkOrder", activity: "cancelled work order", allowedStatuses: ["Requested", "Approved", "Scheduled", "In progress", "Waiting"], fields: [
      { name: "resolution", label: "Cancellation reason", type: "textarea", required: true, maxLength: 2000 }
    ] },
    { key: "issue-part-to-work", label: "Issue part", collection: "workOrders", type: "issuePartToWork", activity: "issued part to work order", allowedStatuses: ["Approved", "Scheduled", "In progress", "Waiting"], fields: [
      { name: "partId", label: "Part", type: "relation", collection: "parts", required: true },
      { name: "quantity", label: "Quantity", type: "number", required: true, minExclusive: 0, max: 1000000, step: 0.01 },
      { name: "operationKey", label: "Operation key", type: "text", required: true, maxLength: 128, pattern: "^[A-Za-z0-9][A-Za-z0-9._:-]{0,127}$", hidden: true }
    ] },
    { key: "generate-pm-work", label: "Generate work order", collection: "preventiveSchedules", type: "generatePreventiveWork", activity: "generated preventive work order", allowedStatuses: ["Active"] },
    { key: "pause-pm", label: "Pause schedule", collection: "preventiveSchedules", type: "scheduleStatus", value: "Paused", activity: "paused preventive schedule", allowedStatuses: ["Active"] },
    { key: "resume-pm", label: "Resume schedule", collection: "preventiveSchedules", type: "scheduleStatus", value: "Active", activity: "resumed preventive schedule", allowedStatuses: ["Paused"] },
    { key: "raise-inspection-follow-up", label: "Raise follow-up work", collection: "inspections", type: "inspectionFollowUp", activity: "raised inspection follow-up", allowedStatuses: ["Conditional", "Fail"] },
    { key: "restock-part", label: "Restock", collection: "parts", type: "restockPart", activity: "restocked part", fields: [
      { name: "quantity", label: "Quantity received", type: "number", required: true, minExclusive: 0, max: 1000000, step: 0.01 },
      { name: "unitCost", label: "Updated unit cost", type: "number", min: 0, max: 100000000, step: 0.01 },
      { name: "note", label: "Receipt note", type: "textarea", maxLength: 1000 }
    ] },
    { key: "issue-part", label: "Issue to work order", collection: "parts", type: "issuePart", activity: "issued part", allowedStatuses: ["In stock", "Low stock"], fields: [
      { name: "workOrderId", label: "Work order", type: "relation", collection: "workOrders", required: true },
      { name: "quantity", label: "Quantity", type: "number", required: true, minExclusive: 0, max: 1000000, step: 0.01 },
      { name: "operationKey", label: "Operation key", type: "text", required: true, maxLength: 128, pattern: "^[A-Za-z0-9][A-Za-z0-9._:-]{0,127}$", hidden: true }
    ] },
    { key: "apply-meter-reading", label: "Apply to asset", collection: "meterReadings", type: "applyMeter", activity: "applied meter reading" }
  ],
  seeds: {
    session: { userId: "usr_local_admin", userName: "Avery Morgan", role: "Maintenance manager" },
    workspace: {
      id: "workspace_maintainstuff",
      organizationName: "Harborline Components",
      sites: ["Detroit Plant", "Ann Arbor Warehouse"],
      defaultLaborRate: 95,
      currency: "USD",
      workOrderPrefix: "MNT",
      nextWorkOrderNumber: 1047,
      timezone: "America/Detroit",
      criticalityPolicy: "Critical assets stop production or protect life safety. High assets constrain throughput. Medium assets have a documented workaround. Low assets have no immediate operational impact.",
      createdAt: "2026-01-02T13:00:00.000Z",
      updatedAt: "2026-07-15T12:00:00.000Z"
    },
    assets: [
      { id: "ast_compressor_7", assetTag: "UTIL-AC-007", name: "Air compressor AC-7", site: "Detroit Plant", status: "Limited service", criticality: "Critical", location: "Utility mezzanine", category: "Utilities", manufacturer: "Atlas Copco", model: "GA37 VSD+", serialNumber: "AII-37-88412", owner: "Morgan Lee", installDate: "2021-08-16", warrantyDate: "2026-08-15", meterValue: 18420.5, meterUnit: "Hours", documentationUri: "/manuals/ga37-vsd", archivedAt: null, createdAt: "2026-01-02T13:10:00.000Z", updatedAt: "2026-07-15T10:35:00.000Z" },
      { id: "ast_pack_line_2", assetTag: "PROD-PKG-002", name: "Packaging line 2", site: "Detroit Plant", status: "Down", criticality: "Critical", location: "Packaging bay B", category: "Production", manufacturer: "Douglas Machine", model: "Axiom IM", serialNumber: "DM-AX-20491", owner: "Priya Shah", installDate: "2019-04-08", warrantyDate: "2024-04-08", meterValue: 412840, meterUnit: "Cycles", documentationUri: "/manuals/pack-line-2", archivedAt: null, createdAt: "2026-01-02T13:11:00.000Z", updatedAt: "2026-07-15T09:20:00.000Z" },
      { id: "ast_boiler_pump_4", assetTag: "UTIL-BP-004", name: "Boiler feed pump P-4", site: "Detroit Plant", status: "Operational", criticality: "High", location: "Boiler room", category: "Utilities", manufacturer: "Grundfos", model: "CR 32-4", serialNumber: "GF-CR32-7731", owner: "Morgan Lee", installDate: "2022-02-22", warrantyDate: "2027-02-21", meterValue: 12840, meterUnit: "Hours", documentationUri: "/manuals/grundfos-cr32", archivedAt: null, createdAt: "2026-01-02T13:12:00.000Z", updatedAt: "2026-07-14T14:30:00.000Z" },
      { id: "ast_forklift_12", assetTag: "MH-FL-012", name: "Forklift 12", site: "Ann Arbor Warehouse", status: "Operational", criticality: "Medium", location: "Receiving", category: "Material handling", manufacturer: "Toyota", model: "8FBCU25", serialNumber: "TY8F-99214", owner: "Elena Ruiz", installDate: "2023-06-12", warrantyDate: "2028-06-11", meterValue: 3265.4, meterUnit: "Hours", documentationUri: "/manuals/forklift-12", archivedAt: null, createdAt: "2026-01-02T13:13:00.000Z", updatedAt: "2026-07-13T16:45:00.000Z" }
    ],
    workOrders: [
      { id: "wo_compressor_leak", number: "MNT-1042", title: "Repair compressor oil separator leak", assetId: "ast_compressor_7", preventiveScheduleId: "", workType: "Corrective", priority: "Emergency", status: "In progress", requester: "Utilities desk", technician: "Morgan Lee", requestedDate: "2026-07-15", dueDate: "2026-07-15", startedDate: "2026-07-15", completedDate: "", estimatedHours: 4, actualHours: 1.5, laborCost: 0, partsCost: 0, downtimeHours: 2.25, findings: "Oil mist at separator flange; temporary containment installed.", resolution: "", evidenceUri: "/evidence/mnt-1042", partsUsed: [], archivedAt: null, createdAt: "2026-07-15T08:10:00.000Z", updatedAt: "2026-07-15T10:35:00.000Z" },
      { id: "wo_pack_guard", number: "MNT-1043", title: "Replace damaged discharge guard", assetId: "ast_pack_line_2", preventiveScheduleId: "", workType: "Safety", priority: "Emergency", status: "Requested", requester: "Nina Patel", technician: "Sam Okafor", requestedDate: "2026-07-13", dueDate: "2026-07-14", startedDate: "", completedDate: "", estimatedHours: 3, actualHours: 0, laborCost: 0, partsCost: 0, downtimeHours: 6.5, findings: "Guard interlock bracket is bent and will not positively latch.", resolution: "", evidenceUri: "/evidence/mnt-1043", partsUsed: [], archivedAt: null, createdAt: "2026-07-13T15:20:00.000Z", updatedAt: "2026-07-15T09:20:00.000Z" },
      { id: "wo_boiler_pm", number: "MNT-1044", title: "Quarterly boiler pump inspection", assetId: "ast_boiler_pump_4", preventiveScheduleId: "pm_boiler_quarterly", workType: "Preventive", priority: "Medium", status: "Scheduled", requester: "Avery Morgan", technician: "Morgan Lee", requestedDate: "2026-07-12", dueDate: "2026-07-16", startedDate: "", completedDate: "", estimatedHours: 2.5, actualHours: 0, laborCost: 0, partsCost: 0, downtimeHours: 0, findings: "", resolution: "", evidenceUri: "", partsUsed: [], archivedAt: null, createdAt: "2026-07-12T12:00:00.000Z", updatedAt: "2026-07-12T12:00:00.000Z" },
      { id: "wo_forklift_brake", number: "MNT-1045", title: "Diagnose intermittent parking brake alarm", assetId: "ast_forklift_12", preventiveScheduleId: "", workType: "Corrective", priority: "High", status: "Waiting", requester: "Elena Ruiz", technician: "Sam Okafor", requestedDate: "2026-07-11", dueDate: "2026-07-17", startedDate: "2026-07-12", completedDate: "", estimatedHours: 3, actualHours: 1.25, laborCost: 0, partsCost: 0, downtimeHours: 0, findings: "Alarm reproduced after warm restart; switch harness ordered.", resolution: "Waiting for replacement switch harness.", evidenceUri: "/evidence/mnt-1045", partsUsed: [], archivedAt: null, createdAt: "2026-07-11T13:30:00.000Z", updatedAt: "2026-07-12T17:00:00.000Z" },
      { id: "wo_compressor_filter", number: "MNT-1046", title: "Replace compressor intake filter", assetId: "ast_compressor_7", preventiveScheduleId: "pm_compressor_monthly", workType: "Preventive", priority: "Medium", status: "Completed", requester: "Avery Morgan", technician: "Morgan Lee", requestedDate: "2026-07-07", dueDate: "2026-07-10", startedDate: "2026-07-10", completedDate: "2026-07-10", estimatedHours: 3, actualHours: 3.5, laborCost: 332.5, partsCost: 168, downtimeHours: 1.2, findings: "Filter differential pressure exceeded service limit.", resolution: "Replaced intake filter and cleaned housing; post-service pressure normal.", evidenceUri: "/evidence/mnt-1046", partsUsed: [{ partId: "prt_compressor_filter", quantity: 1, unitCost: 168, issuedAt: "2026-07-10T16:20:00.000Z", actor: "Morgan Lee" }], archivedAt: null, createdAt: "2026-07-07T11:00:00.000Z", updatedAt: "2026-07-10T17:15:00.000Z" }
    ],
    preventiveSchedules: [
      { id: "pm_compressor_monthly", name: "Compressor monthly service", assetId: "ast_compressor_7", triggerType: "Calendar", status: "Active", intervalDays: 30, meterInterval: 0, lastDueDate: "2026-07-10", nextDueDate: "2026-08-09", lastMeter: 18382, nextMeter: 0, owner: "Morgan Lee", procedure: "Lock out compressor, inspect separator and belts, replace intake filter when differential pressure exceeds limit, check drains, record operating hours.", archivedAt: null, createdAt: "2026-01-03T09:00:00.000Z", updatedAt: "2026-07-10T17:15:00.000Z" },
      { id: "pm_boiler_quarterly", name: "Boiler pump quarterly inspection", assetId: "ast_boiler_pump_4", triggerType: "Calendar + meter", status: "Active", intervalDays: 90, meterInterval: 750, lastDueDate: "2026-04-17", nextDueDate: "2026-07-16", lastMeter: 12150, nextMeter: 12900, owner: "Morgan Lee", procedure: "Inspect seal leakage, verify alignment, measure vibration, confirm bearing temperature, test standby switchover, and record operating hours.", archivedAt: null, createdAt: "2026-01-03T09:05:00.000Z", updatedAt: "2026-07-12T12:00:00.000Z" },
      { id: "pm_packaging_weekly", name: "Packaging line guarding check", assetId: "ast_pack_line_2", triggerType: "Calendar + meter", status: "Active", intervalDays: 7, meterInterval: 10000, lastDueDate: "2026-07-05", nextDueDate: "2026-07-12", lastMeter: 401300, nextMeter: 411300, owner: "Priya Shah", procedure: "Inspect fixed and interlocked guards, challenge each safety switch, verify emergency stops, photograph deficiencies, and stop operation for any failed guard.", archivedAt: null, createdAt: "2026-01-03T09:10:00.000Z", updatedAt: "2026-07-13T15:20:00.000Z" }
    ],
    inspections: [
      { id: "ins_pack_guard", template: "Weekly machine guarding", assetId: "ast_pack_line_2", workOrderId: "wo_pack_guard", followUpWorkOrderId: "", inspector: "Nina Patel", inspectionDate: "2026-07-13", result: "Fail", score: 68, failedChecks: "Discharge guard will not latch; interlock bracket visibly bent.", notes: "Line locked out pending repair and verification.", evidenceUri: "/evidence/ins-pack-0713", archivedAt: null, createdAt: "2026-07-13T15:05:00.000Z", updatedAt: "2026-07-13T15:20:00.000Z" },
      { id: "ins_boiler", template: "Boiler room daily round", assetId: "ast_boiler_pump_4", workOrderId: "", followUpWorkOrderId: "", inspector: "Morgan Lee", inspectionDate: "2026-07-14", result: "Pass", score: 96, failedChecks: "", notes: "Seal dry, vibration normal, standby pump available.", evidenceUri: "/evidence/ins-boiler-0714", archivedAt: null, createdAt: "2026-07-14T14:30:00.000Z", updatedAt: "2026-07-14T14:30:00.000Z" },
      { id: "ins_forklift", template: "Forklift pre-shift inspection", assetId: "ast_forklift_12", workOrderId: "wo_forklift_brake", followUpWorkOrderId: "", inspector: "Elena Ruiz", inspectionDate: "2026-07-12", result: "Conditional", score: 84, failedChecks: "Parking brake warning alarm appeared after restart.", notes: "Mechanical brake holds; unit restricted to receiving until alarm circuit is repaired.", evidenceUri: "/evidence/ins-fl12-0712", archivedAt: null, createdAt: "2026-07-12T07:20:00.000Z", updatedAt: "2026-07-12T07:20:00.000Z" }
    ],
    parts: [
      { id: "prt_compressor_filter", sku: "FLT-GA37-INT", name: "GA37 intake filter", onHand: 4, reorderPoint: 8, status: "Low stock", category: "Consumable", site: "Detroit Plant", bin: "U-14-B", supplier: "Air Systems Midwest", unitCost: 168, archivedAt: null, createdAt: "2026-01-04T10:00:00.000Z", updatedAt: "2026-07-10T16:20:00.000Z" },
      { id: "prt_guard_switch", sku: "SW-440N-G02018", name: "Guard interlock switch", onHand: 0, reorderPoint: 2, status: "Out of stock", category: "Safety", site: "Detroit Plant", bin: "E-02-A", supplier: "Rockwell Automation", unitCost: 286.5, archivedAt: null, createdAt: "2026-01-04T10:05:00.000Z", updatedAt: "2026-07-15T09:15:00.000Z" },
      { id: "prt_vbelt_b62", sku: "BLT-B62-5L", name: "B62 matched V-belt", onHand: 12, reorderPoint: 6, status: "In stock", category: "Mechanical", site: "Detroit Plant", bin: "M-08-C", supplier: "Motion Industries", unitCost: 34.75, archivedAt: null, createdAt: "2026-01-04T10:10:00.000Z", updatedAt: "2026-06-28T13:00:00.000Z" },
      { id: "prt_pump_seal", sku: "SEAL-CR32-KIT", name: "CR32 mechanical seal kit", onHand: 2, reorderPoint: 2, status: "Low stock", category: "Mechanical", site: "Detroit Plant", bin: "M-03-D", supplier: "Grundfos Service", unitCost: 412, archivedAt: null, createdAt: "2026-01-04T10:15:00.000Z", updatedAt: "2026-06-19T10:30:00.000Z" },
      { id: "prt_brake_switch", sku: "TY-8F-BRK-SW", name: "Forklift parking brake switch", onHand: 1, reorderPoint: 1, status: "Low stock", category: "Electrical", site: "Ann Arbor Warehouse", bin: "AA-E-11", supplier: "Toyota Material Handling", unitCost: 119.25, archivedAt: null, createdAt: "2026-01-04T10:20:00.000Z", updatedAt: "2026-07-12T16:40:00.000Z" }
    ],
    meterReadings: [
      { id: "mtr_comp_0715", assetId: "ast_compressor_7", value: 18420.5, unit: "Hours", readingDate: "2026-07-15", source: "Work order", recordedBy: "Morgan Lee", notes: "Recorded while troubleshooting separator leak.", archivedAt: null, createdAt: "2026-07-15T10:35:00.000Z", updatedAt: "2026-07-15T10:35:00.000Z" },
      { id: "mtr_pack_0713", assetId: "ast_pack_line_2", value: 412840, unit: "Cycles", readingDate: "2026-07-13", source: "Inspection", recordedBy: "Nina Patel", notes: "Line stopped after failed guarding check.", archivedAt: null, createdAt: "2026-07-13T15:05:00.000Z", updatedAt: "2026-07-13T15:05:00.000Z" },
      { id: "mtr_boiler_0714", assetId: "ast_boiler_pump_4", value: 12840, unit: "Hours", readingDate: "2026-07-14", source: "Inspection", recordedBy: "Morgan Lee", notes: "Daily boiler room round.", archivedAt: null, createdAt: "2026-07-14T14:30:00.000Z", updatedAt: "2026-07-14T14:30:00.000Z" },
      { id: "mtr_forklift_0712", assetId: "ast_forklift_12", value: 3265.4, unit: "Hours", readingDate: "2026-07-12", source: "Inspection", recordedBy: "Elena Ruiz", notes: "Pre-shift reading.", archivedAt: null, createdAt: "2026-07-12T07:20:00.000Z", updatedAt: "2026-07-12T07:20:00.000Z" }
    ],
    activity: [
      { id: "act_maint_1", actor: "Morgan Lee", action: "started work order", entityType: "workOrders", entityId: "wo_compressor_leak", metadata: { number: "MNT-1042", title: "Repair compressor oil separator leak" }, createdAt: "2026-07-15T10:35:00.000Z" },
      { id: "act_maint_2", actor: "Avery Morgan", action: "marked asset down", entityType: "assets", entityId: "ast_pack_line_2", metadata: { assetTag: "PROD-PKG-002" }, createdAt: "2026-07-15T09:20:00.000Z" },
      { id: "act_maint_3", actor: "Nina Patel", action: "recorded failed inspection", entityType: "inspections", entityId: "ins_pack_guard", metadata: { template: "Weekly machine guarding" }, createdAt: "2026-07-13T15:20:00.000Z" },
      { id: "act_maint_4", actor: "Morgan Lee", action: "completed work order", entityType: "workOrders", entityId: "wo_compressor_filter", metadata: { number: "MNT-1046" }, createdAt: "2026-07-10T17:15:00.000Z" },
      { id: "act_maint_5", actor: "Morgan Lee", action: "issued part to work order", entityType: "parts", entityId: "prt_compressor_filter", metadata: { quantity: 1, workOrder: "MNT-1046" }, createdAt: "2026-07-10T16:20:00.000Z" }
    ]
  }
};
