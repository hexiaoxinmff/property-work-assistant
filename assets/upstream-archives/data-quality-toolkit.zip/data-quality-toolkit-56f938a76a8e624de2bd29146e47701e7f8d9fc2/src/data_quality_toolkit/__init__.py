"""Data Quality Toolkit."""

__version__ = "1.0.0"