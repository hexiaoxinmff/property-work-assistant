# data-reconcile

[![CI](https://github.com/ccrumptonai/data-reconcile/actions/workflows/ci.yml/badge.svg)](https://github.com/ccrumptonai/data-reconcile/actions/workflows/ci.yml)

Compare two tabular datasets — CSV or Excel — on a key column and get a clear
report of what was **added**, **removed**, and **changed** (down to the
individual cell). Built for data migrations, audits, and reconciliation work.
**Runs locally; no data leaves your machine.**

## Why
"Which rows changed between last month's extract and this month's?" is a
constant question in government data work. Eyeballing two spreadsheets doesn't
scale and isn't auditable. `reconcile` answers it deterministically and produces
a report you can hand to a reviewer.

## Install

```bash
python -m venv .venv
.venv\Scripts\activate        # Windows  (use: source .venv/bin/activate on macOS/Linux)
pip install -e .
```

Only dependency is `openpyxl` (for Excel I/O). No pandas required.

## Usage

```bash
reconcile OLD NEW --key id --out diff.xlsx
```

```
$ reconcile examples/employees_old.csv examples/employees_new.csv --key id --out diff.xlsx
Added:    1 rows
Removed:  1 rows
Changed:  2 rows  (3 cell changes)
Unchanged:1 rows
Wrote diff.xlsx
```

The Excel report has four sheets: **Summary**, **Added**, **Removed**, and
**Changed** (one row per changed cell — `key, column, old_value, new_value`).

### Options

| Flag | Meaning |
| ---- | ------- |
| `--key COL[,COL...]` | key column, or composite key (required) |
| `--ignore COL,...` | columns to exclude from change detection (e.g. timestamps) |
| `--out PATH` | report path; extension picks the format (`.xlsx`/`.csv`/`.html`) |
| `--format excel\|csv\|html` | force the output format |
| `--no-trim` | don't strip surrounding whitespace before comparing |
| `--ignore-case` | compare values case-insensitively |

CSV output is a flat change log (`change_type, key…, column, old_value, new_value`)
that's easy to grep or load elsewhere. HTML is a self-contained report.

**Exit codes:** `0` identical · `1` differences found · `2` error.
Handy in scripts: `reconcile a.csv b.csv --key id && echo "no changes"`.

## What the report looks like

For the bundled example (`examples/employees_old.csv` vs `employees_new.csv`),
the Excel report's **Summary** sheet gives the headline counts:

![Reconciliation summary sheet](docs/report-summary.png)

…and the **Changed** sheet lists every changed cell with its old and new value —
the auditable detail:

![Changed sheet — one row per changed cell](docs/report-changed.png)

## Behavior notes

- Inputs may mix formats (compare a `.csv` against an `.xlsx`).
- Values are normalized before comparison, so Excel `1000.0` equals CSV `1000`,
  and dates match their ISO text form. Whitespace is trimmed by default.
- A **non-unique key fails loudly** — reconciliation is ambiguous otherwise.
- Columns present in only one file are reported as schema changes, not per-row
  changes.

## Develop / test

```bash
pip install -e ".[dev]"
pytest
```

## License

MIT
