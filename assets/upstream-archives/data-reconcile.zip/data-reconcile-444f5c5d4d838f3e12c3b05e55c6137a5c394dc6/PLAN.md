# data-reconcile — Implementation Plan

## Goal
A Python CLI + library that compares two tabular datasets (CSV or Excel) on a
key column (or composite key) and reports what was **added**, **removed**, and
**changed** (down to the individual cell), plus an unchanged count. Built for
data migrations, audits, and reconciliation in a government data context.
Runs locally — no data leaves the machine.

## Why no pandas
Target machine is Python 3.14, where pandas/numpy wheels are not reliably
available yet. The reconciliation logic is a key-based set diff + cell compare,
which is clean stdlib work. Only dependency: `openpyxl` (pure-Python) for Excel.

## Success Criteria (loop until all green — Rule 4)
- [ ] `reconcile A.csv B.xlsx --key id --out diff.xlsx` produces a 4-sheet report
- [ ] Detects **added** rows (key present in B, absent in A)
- [ ] Detects **removed** rows (key in A, absent in B)
- [ ] Detects **changed** rows with per-cell old→new values
- [ ] Reports an accurate **unchanged** count
- [ ] Composite keys (`--key a,b`) work
- [ ] `--ignore col1,col2` excludes columns from change detection (e.g. timestamps)
- [ ] Duplicate keys within a file raise a clear error (fail loud — Rule 12)
- [ ] Columns added/removed between versions are surfaced in the summary
- [ ] Reads both `.csv` and `.xlsx`; writes `.xlsx` (default), `.csv`, or `.html`
- [ ] `pytest` suite passes and encodes WHY each behavior matters (Rule 9)

## CLI
```
reconcile OLD NEW --key COL[,COL...] [--ignore COL,...]
                  [--out PATH] [--format excel|csv|html]
                  [--trim/--no-trim] [--ignore-case]
```
Exit code 0 if identical, 1 if differences found (script-friendly), 2 on error.

## Architecture
```
pyproject.toml          # console_scripts: reconcile = reconcile.cli:main; dep openpyxl
reconcile/
  __init__.py           # exports reconcile(), ReconcileResult
  tabular.py            # load_table(path) -> (headers, rows[list[dict]]); csv + xlsx
  core.py               # reconcile(a, b, keys, ignore, opts) -> ReconcileResult
  report.py             # write_excel / write_csv / write_html
  cli.py                # argparse front-end
tests/
  test_core.py          # added/removed/changed/composite/ignore/dup-key/columns
  test_tabular.py       # csv + xlsx loading, type normalization
examples/
  employees_old.csv
  employees_new.csv     # demonstrates 1 add, 1 remove, 2 changes
README.md  LICENSE  .gitignore
```

## Data model
- `ReconcileResult`: added[list[row]], removed[list[row]], changed[list[Change]],
  unchanged_count[int], columns_added[list], columns_removed[list], keys, value_cols
- `Change`: key, cells[list[CellChange{column, old, new}]], full old/new rows

## Comparison rules (documented, deterministic — Rule 1)
- Values normalized to strings for comparison; `--trim` (default on) strips
  whitespace; `--ignore-case` optional. Numbers compared by normalized string.
- Compared columns = (union of columns) − keys − ignored. Columns present in
  only one file are reported separately and not treated as per-row changes.

## Build Sequence
1. `tabular.load_table` (csv + xlsx) + tests
2. `core.reconcile` + tests (the heart — test first)
3. `report.write_excel` (summary/added/removed/changed sheets)
4. csv + html reporters
5. `cli.main` wiring + exit codes
6. `pyproject.toml`, example data, README
7. `pip install -e .`, run `reconcile` on examples end-to-end, `pytest`

## Out of Scope (v1)
- Direct database inputs (file inputs only; DB extract → file is the workflow)
- Fuzzy/near matching; JSON/nested inputs
- Multi-file (3+) reconciliation
