"""Tests for report rendering — the output is what a reviewer actually reads,
so its structure must be stable (Rule 9)."""
from openpyxl import load_workbook

from reconcile import reconcile
from reconcile.report import write_csv, write_excel, write_html


def _result():
    headers = ["id", "name", "salary"]
    ra = [{"id": "1", "name": "Ada", "salary": "100"},
          {"id": "2", "name": "Linus", "salary": "200"}]
    rb = [{"id": "1", "name": "Ada", "salary": "150"},   # changed
          {"id": "3", "name": "Grace", "salary": "300"}]  # added; id 2 removed
    return reconcile(headers, ra, headers, rb, keys=["id"])


def test_excel_has_expected_sheets_and_changed_cell(tmp_path):
    out = tmp_path / "diff.xlsx"
    write_excel(_result(), out)
    wb = load_workbook(out)
    assert wb.sheetnames == ["Summary", "Added", "Removed", "Changed"]
    changed = wb["Changed"]
    header = [c.value for c in changed[1]]
    assert header == ["id", "column", "old_value", "new_value"]
    # The one changed cell: id 1 salary 100 -> 150.
    data = [[c.value for c in row] for row in changed.iter_rows(min_row=2)]
    assert ["1", "salary", "100", "150"] in data


def test_csv_change_log(tmp_path):
    out = tmp_path / "diff.csv"
    write_csv(_result(), out)
    text = out.read_text(encoding="utf-8")
    assert "added,3,,," in text
    assert "removed,2,,," in text
    assert "changed,1,salary,100,150" in text


def test_html_is_self_contained(tmp_path):
    out = tmp_path / "diff.html"
    write_html(_result(), out)
    text = out.read_text(encoding="utf-8")
    assert text.startswith("<!DOCTYPE html>")
    assert "Reconciliation report" in text
    assert "salary" in text
