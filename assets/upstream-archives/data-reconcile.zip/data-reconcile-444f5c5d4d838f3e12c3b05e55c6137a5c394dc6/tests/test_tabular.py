"""Tests for loading CSV and Excel into the common (headers, rows) shape."""
from openpyxl import Workbook

from reconcile import load_table, reconcile


def test_load_csv(tmp_path):
    p = tmp_path / "t.csv"
    p.write_text("id,name\n1,Ada\n2,Linus\n", encoding="utf-8")
    headers, rows = load_table(p)
    assert headers == ["id", "name"]
    assert rows == [{"id": "1", "name": "Ada"}, {"id": "2", "name": "Linus"}]


def test_load_csv_strips_bom(tmp_path):
    # Gov exports frequently carry a UTF-8 BOM; the first header must stay clean.
    p = tmp_path / "bom.csv"
    p.write_bytes("﻿id,name\n1,Ada\n".encode("utf-8"))
    headers, _ = load_table(p)
    assert headers[0] == "id"


def test_load_xlsx(tmp_path):
    p = tmp_path / "t.xlsx"
    wb = Workbook()
    ws = wb.active
    ws.append(["id", "name", "salary"])
    ws.append([1, "Ada", 1000])
    ws.append([2, "Linus", 2000])
    wb.save(p)
    headers, rows = load_table(p)
    assert headers == ["id", "name", "salary"]
    assert rows[0]["name"] == "Ada"
    assert rows[1]["salary"] == 2000


def test_csv_and_xlsx_reconcile_across_formats(tmp_path):
    # The whole point: compare a CSV baseline against an Excel update.
    csv_p = tmp_path / "old.csv"
    csv_p.write_text("id,amount\n1,1000\n2,2000\n", encoding="utf-8")
    xlsx_p = tmp_path / "new.xlsx"
    wb = Workbook(); ws = wb.active
    ws.append(["id", "amount"]); ws.append([1, 1000]); ws.append([2, 2500])
    wb.save(xlsx_p)

    ha, ra = load_table(csv_p)
    hb, rb = load_table(xlsx_p)
    r = reconcile(ha, ra, hb, rb, keys=["id"])
    assert len(r.changed) == 1
    assert r.changed[0].cells[0].column == "amount"
