"""Tests for the reconciliation engine.

Each test states WHY the behavior matters for real reconciliation/audit work,
not merely what the code does (Rule 9).
"""
import pytest

from reconcile import reconcile

HEADERS = ["id", "name", "salary", "updated"]


def rows(*tuples):
    return [dict(zip(HEADERS, t)) for t in tuples]


def base():
    # A small "old" table reused across tests.
    return HEADERS, rows(
        ("1", "Ada", "100", "2024-01-01"),
        ("2", "Linus", "200", "2024-01-01"),
        ("3", "Grace", "300", "2024-01-01"),
    )


def test_added_row_detected():
    # New records appear in migrations; missing them would understate growth.
    ha, ra = base()
    hb, rb = HEADERS, rows(
        ("1", "Ada", "100", "2024-01-01"),
        ("2", "Linus", "200", "2024-01-01"),
        ("3", "Grace", "300", "2024-01-01"),
        ("4", "Edsger", "400", "2024-02-01"),
    )
    r = reconcile(ha, ra, hb, rb, keys=["id"])
    assert [row["id"] for row in r.added] == ["4"]
    assert not r.removed and not r.changed
    assert r.unchanged_count == 3


def test_removed_row_detected():
    # Dropped records must be flagged — they often signal data loss.
    ha, ra = base()
    hb, rb = HEADERS, rows(
        ("1", "Ada", "100", "2024-01-01"),
        ("3", "Grace", "300", "2024-01-01"),
    )
    r = reconcile(ha, ra, hb, rb, keys=["id"])
    assert [row["id"] for row in r.removed] == ["2"]
    assert r.unchanged_count == 2


def test_changed_cell_detected_with_old_and_new():
    # The audit value is knowing exactly which field changed and from/to what.
    ha, ra = base()
    hb, rb = HEADERS, rows(
        ("1", "Ada", "150", "2024-03-01"),  # salary + updated changed
        ("2", "Linus", "200", "2024-01-01"),
        ("3", "Grace", "300", "2024-01-01"),
    )
    r = reconcile(ha, ra, hb, rb, keys=["id"])
    assert len(r.changed) == 1
    change = r.changed[0]
    cols = {c.column: (c.old, c.new) for c in change.cells}
    assert cols["salary"] == ("100", "150")
    assert cols["updated"] == ("2024-01-01", "2024-03-01")
    assert r.cell_change_count == 2


def test_ignore_column_excludes_it_from_changes():
    # A bookkeeping timestamp shouldn't count as a substantive change.
    ha, ra = base()
    hb, rb = HEADERS, rows(
        ("1", "Ada", "100", "2099-12-31"),  # only `updated` differs
        ("2", "Linus", "200", "2024-01-01"),
        ("3", "Grace", "300", "2024-01-01"),
    )
    r = reconcile(ha, ra, hb, rb, keys=["id"], ignore=["updated"])
    assert not r.changed
    assert r.unchanged_count == 3
    assert r.identical


def test_composite_key():
    # Real feeds are often keyed on more than one column.
    headers = ["region", "id", "value"]
    ra = [dict(zip(headers, t)) for t in [("E", "1", "x"), ("W", "1", "y")]]
    rb = [dict(zip(headers, t)) for t in [("E", "1", "x"), ("W", "1", "z")]]
    r = reconcile(headers, ra, headers, rb, keys=["region", "id"])
    assert len(r.changed) == 1
    assert r.changed[0].key == ("W", "1")


def test_numeric_string_equivalence():
    # Excel 1000.0 vs CSV "1000" must NOT be reported as a change.
    ha = ["id", "amount"]
    ra = [{"id": "1", "amount": 1000.0}]
    rb = [{"id": "1", "amount": "1000"}]
    r = reconcile(ha, ra, ha, rb, keys=["id"])
    assert r.identical


def test_duplicate_key_raises_clearly():
    # A non-unique key makes reconciliation ambiguous; fail loud (Rule 12).
    ha = ["id", "v"]
    ra = [{"id": "1", "v": "a"}, {"id": "1", "v": "b"}]
    with pytest.raises(ValueError, match="Duplicate key"):
        reconcile(ha, ra, ha, ra, keys=["id"])


def test_missing_key_column_raises():
    with pytest.raises(ValueError, match="Key column"):
        reconcile(["id"], [], ["other"], [], keys=["id"])


def test_added_and_removed_columns_surfaced():
    # Schema drift between versions is itself a finding.
    ra = [{"id": "1", "name": "Ada"}]
    rb = [{"id": "1", "email": "ada@x.gov"}]
    r = reconcile(["id", "name"], ra, ["id", "email"], rb, keys=["id"])
    assert r.columns_added == ["email"]
    assert r.columns_removed == ["name"]
    # `name`/`email` exist on only one side, so they aren't per-row changes.
    assert not r.changed
