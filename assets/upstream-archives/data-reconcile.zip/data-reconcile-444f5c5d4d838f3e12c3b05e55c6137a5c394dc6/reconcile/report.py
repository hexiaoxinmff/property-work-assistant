"""Render a ReconcileResult to Excel, CSV, or HTML."""
from __future__ import annotations

import csv
import html
from datetime import datetime
from pathlib import Path

from .core import ReconcileResult


def _display(value) -> str:
    return "" if value is None else str(value)


# --------------------------------------------------------------------------- #
# Excel
# --------------------------------------------------------------------------- #
def write_excel(result: ReconcileResult, path: str | Path) -> None:
    from openpyxl import Workbook
    from openpyxl.styles import Font, PatternFill
    from openpyxl.utils import get_column_letter

    wb = Workbook()
    header_font = Font(bold=True)
    tints = {
        "Added": PatternFill("solid", fgColor="C6EFCE"),
        "Removed": PatternFill("solid", fgColor="FFC7CE"),
        "Changed": PatternFill("solid", fgColor="FFEB9C"),
        "Summary": PatternFill("solid", fgColor="D9E1F2"),
    }

    def style_header(ws, ncols, fill):
        for c in range(1, ncols + 1):
            cell = ws.cell(row=1, column=c)
            cell.font = header_font
            cell.fill = fill
        ws.freeze_panes = "A2"

    def autosize(ws, headers, sample_rows):
        for i, h in enumerate(headers, start=1):
            width = len(str(h))
            for r in sample_rows[:200]:
                width = max(width, len(str(r[i - 1])))
            ws.column_dimensions[get_column_letter(i)].width = min(max(width + 2, 8), 60)

    # Summary
    ws = wb.active
    ws.title = "Summary"
    s = result.summary()
    pairs = [
        ("Generated", datetime.now().isoformat(timespec="seconds")),
        ("Key column(s)", ", ".join(s["keys"])),
        ("Rows added", s["added"]),
        ("Rows removed", s["removed"]),
        ("Rows changed", s["changed"]),
        ("Cell changes", s["cell_changes"]),
        ("Rows unchanged", s["unchanged"]),
        ("Columns added (in new only)", ", ".join(s["columns_added"]) or "—"),
        ("Columns removed (in old only)", ", ".join(s["columns_removed"]) or "—"),
        ("Identical", "yes" if s["identical"] else "no"),
    ]
    ws.cell(row=1, column=1, value="Metric")
    ws.cell(row=1, column=2, value="Value")
    style_header(ws, 2, tints["Summary"])
    for r, (label, value) in enumerate(pairs, start=2):
        ws.cell(row=r, column=1, value=label)
        ws.cell(row=r, column=2, value=value)
    ws.column_dimensions["A"].width = 32
    ws.column_dimensions["B"].width = 40

    # Added / Removed (full rows, using each side's column order)
    def write_rows_sheet(title, headers, rows):
        sheet = wb.create_sheet(title)
        sheet.append(headers)
        data = []
        for row in rows:
            line = [row.get(h, "") for h in headers]
            sheet.append(line)
            data.append(line)
        style_header(sheet, len(headers), tints[title])
        autosize(sheet, headers, data)

    added_cols = result.keys + [c for c in result.compared_columns] + result.columns_added
    removed_cols = result.keys + [c for c in result.compared_columns] + result.columns_removed
    write_rows_sheet("Added", added_cols, result.added)
    write_rows_sheet("Removed", removed_cols, result.removed)

    # Changed (one row per changed cell — the audit view)
    ws_c = wb.create_sheet("Changed")
    changed_headers = result.keys + ["column", "old_value", "new_value"]
    ws_c.append(changed_headers)
    cdata = []
    for change in result.changed:
        for cell in change.cells:
            line = list(change.key) + [cell.column, _display(cell.old), _display(cell.new)]
            ws_c.append(line)
            cdata.append(line)
    style_header(ws_c, len(changed_headers), tints["Changed"])
    autosize(ws_c, changed_headers, cdata)

    Path(path).parent.mkdir(parents=True, exist_ok=True)
    wb.save(path)


# --------------------------------------------------------------------------- #
# CSV — a flat change log (scriptable)
# --------------------------------------------------------------------------- #
def write_csv(result: ReconcileResult, path: str | Path) -> None:
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    with Path(path).open("w", newline="", encoding="utf-8") as fh:
        w = csv.writer(fh)
        w.writerow(["change_type", *result.keys, "column", "old_value", "new_value"])
        for row in result.added:
            w.writerow(["added", *[row.get(k, "") for k in result.keys], "", "", ""])
        for row in result.removed:
            w.writerow(["removed", *[row.get(k, "") for k in result.keys], "", "", ""])
        for change in result.changed:
            for cell in change.cells:
                w.writerow(["changed", *change.key, cell.column,
                            _display(cell.old), _display(cell.new)])


# --------------------------------------------------------------------------- #
# HTML — a self-contained report
# --------------------------------------------------------------------------- #
def write_html(result: ReconcileResult, path: str | Path) -> None:
    s = result.summary()
    esc = html.escape

    def table(headers, row_lists):
        out = ["<table><thead><tr>"]
        out += [f"<th>{esc(str(h))}</th>" for h in headers]
        out.append("</tr></thead><tbody>")
        for r in row_lists:
            out.append("<tr>" + "".join(f"<td>{esc(str(c))}</td>" for c in r) + "</tr>")
        out.append("</tbody></table>")
        return "".join(out)

    changed_rows = [[*c.key, cell.column, _display(cell.old), _display(cell.new)]
                    for c in result.changed for cell in c.cells]

    doc = f"""<!DOCTYPE html><html lang="en"><head><meta charset="utf-8">
<title>Reconciliation report</title>
<style>
body{{font-family:system-ui,Segoe UI,sans-serif;margin:2rem;color:#1c2030}}
h1{{margin:0 0 .5rem}} h2{{margin-top:2rem}}
table{{border-collapse:collapse;margin:.5rem 0;font-size:.9rem}}
th,td{{border:1px solid #d0d7de;padding:.35rem .6rem;text-align:left}}
th{{background:#f3f5f9}}
.kpi{{display:inline-block;margin:.25rem 1rem .25rem 0}}
.kpi b{{font-size:1.4rem}}
.added b{{color:#1a7f37}} .removed b{{color:#cf222e}} .changed b{{color:#9a6700}}
</style></head><body>
<h1>Reconciliation report</h1>
<p>Generated {datetime.now().isoformat(timespec='seconds')} · key
<code>{esc(', '.join(s['keys']))}</code></p>
<div>
<span class="kpi added"><b>{s['added']}</b><br>added</span>
<span class="kpi removed"><b>{s['removed']}</b><br>removed</span>
<span class="kpi changed"><b>{s['changed']}</b><br>changed rows</span>
<span class="kpi"><b>{s['cell_changes']}</b><br>cell changes</span>
<span class="kpi"><b>{s['unchanged']}</b><br>unchanged</span>
</div>
<p>Columns added: <code>{esc(', '.join(s['columns_added']) or '—')}</code> ·
Columns removed: <code>{esc(', '.join(s['columns_removed']) or '—')}</code></p>
<h2>Changed cells</h2>
{table(result.keys + ['column', 'old', 'new'], changed_rows)}
<h2>Added rows</h2>
{table(result.keys + result.compared_columns + result.columns_added,
        [[r.get(h, '') for h in result.keys + result.compared_columns + result.columns_added] for r in result.added])}
<h2>Removed rows</h2>
{table(result.keys + result.compared_columns + result.columns_removed,
        [[r.get(h, '') for h in result.keys + result.compared_columns + result.columns_removed] for r in result.removed])}
</body></html>"""
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    Path(path).write_text(doc, encoding="utf-8")


def write_report(result: ReconcileResult, path: str | Path, fmt: str) -> None:
    if fmt == "excel":
        write_excel(result, path)
    elif fmt == "csv":
        write_csv(result, path)
    elif fmt == "html":
        write_html(result, path)
    else:
        raise ValueError(f"Unknown format {fmt!r} (use excel, csv, or html)")
