"""data-reconcile — compare two tabular datasets on a key and report differences."""
from .core import reconcile, ReconcileResult, Change, CellChange
from .tabular import load_table

__all__ = ["reconcile", "ReconcileResult", "Change", "CellChange", "load_table"]
__version__ = "0.1.0"
