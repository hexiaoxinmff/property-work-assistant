"""Command-line front-end for data-reconcile."""
from __future__ import annotations

import argparse
import sys
from pathlib import Path

from .core import reconcile
from .report import write_report
from .tabular import load_table

_EXT_FORMAT = {".xlsx": "excel", ".csv": "csv", ".html": "html", ".htm": "html"}


def _split(arg: str | None) -> list[str]:
    return [s.strip() for s in arg.split(",")] if arg else []


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        prog="reconcile",
        description="Compare two tabular files (CSV/Excel) on a key and report "
                    "added, removed, and changed rows.")
    p.add_argument("old", help="the baseline file (.csv/.tsv/.xlsx)")
    p.add_argument("new", help="the comparison file (.csv/.tsv/.xlsx)")
    p.add_argument("--key", required=True,
                   help="key column, or comma-separated columns for a composite key")
    p.add_argument("--ignore", help="comma-separated columns to ignore when detecting changes")
    p.add_argument("--out", help="output report path (extension picks the format)")
    p.add_argument("--format", choices=["excel", "csv", "html"],
                   help="override the output format (default: inferred from --out, else excel)")
    p.add_argument("--no-trim", dest="trim", action="store_false",
                   help="do not strip surrounding whitespace before comparing")
    p.add_argument("--ignore-case", action="store_true",
                   help="compare values case-insensitively")
    return p


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    try:
        headers_a, rows_a = load_table(args.old)
        headers_b, rows_b = load_table(args.new)
        result = reconcile(headers_a, rows_a, headers_b, rows_b,
                           keys=_split(args.key), ignore=_split(args.ignore),
                           trim=args.trim, ignore_case=args.ignore_case)
    except (ValueError, FileNotFoundError) as exc:
        print(f"error: {exc}", file=sys.stderr)
        return 2

    s = result.summary()
    print(f"Added:    {s['added']} rows")
    print(f"Removed:  {s['removed']} rows")
    print(f"Changed:  {s['changed']} rows  ({s['cell_changes']} cell changes)")
    print(f"Unchanged:{s['unchanged']} rows")
    if s["columns_added"]:
        print(f"Columns only in new: {', '.join(s['columns_added'])}")
    if s["columns_removed"]:
        print(f"Columns only in old: {', '.join(s['columns_removed'])}")

    if args.out:
        fmt = args.format or _EXT_FORMAT.get(Path(args.out).suffix.lower(), "excel")
        try:
            write_report(result, args.out, fmt)
        except (ValueError, OSError) as exc:
            print(f"error writing report: {exc}", file=sys.stderr)
            return 2
        print(f"Wrote {args.out}")

    return 0 if result.identical else 1


if __name__ == "__main__":
    raise SystemExit(main())
