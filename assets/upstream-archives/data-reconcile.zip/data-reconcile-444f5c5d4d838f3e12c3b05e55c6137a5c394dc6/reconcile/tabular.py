"""Load tabular files (CSV / Excel) into a common (headers, rows) shape.

Rows are lists of dicts keyed by header name. Cell values keep their natural
Python type (str from CSV; str/int/float/datetime from Excel); the comparison
layer in core.py normalizes them, so callers don't need to pre-clean.
"""
from __future__ import annotations

import csv
from pathlib import Path


def load_table(path: str | Path) -> tuple[list[str], list[dict]]:
    """Return (headers, rows) for a .csv/.tsv or .xlsx/.xlsm file."""
    path = Path(path)
    suffix = path.suffix.lower()
    if suffix in (".csv", ".txt"):
        return _load_delimited(path, ",")
    if suffix == ".tsv":
        return _load_delimited(path, "\t")
    if suffix in (".xlsx", ".xlsm"):
        return _load_xlsx(path)
    raise ValueError(f"Unsupported file type {path.suffix!r} (use .csv, .tsv, or .xlsx)")


def _load_delimited(path: Path, delimiter: str) -> tuple[list[str], list[dict]]:
    # utf-8-sig transparently strips a BOM if present (common in gov exports).
    with path.open("r", newline="", encoding="utf-8-sig") as fh:
        reader = csv.DictReader(fh, delimiter=delimiter)
        headers = list(reader.fieldnames or [])
        if not headers:
            raise ValueError(f"{path} has no header row")
        rows = [{h: (row.get(h) if row.get(h) is not None else "") for h in headers}
                for row in reader]
    return headers, rows


def _load_xlsx(path: Path) -> tuple[list[str], list[dict]]:
    from openpyxl import load_workbook  # imported lazily so CSV-only use needs no dep

    wb = load_workbook(path, read_only=True, data_only=True)
    ws = wb.active
    rows_iter = ws.iter_rows(values_only=True)
    try:
        header_row = next(rows_iter)
    except StopIteration:
        wb.close()
        raise ValueError(f"{path} is empty")
    headers = [("" if h is None else str(h)) for h in header_row]
    if not any(headers):
        wb.close()
        raise ValueError(f"{path} has no header row")

    rows: list[dict] = []
    for raw in rows_iter:
        # Skip fully-blank trailing rows that read-only mode can yield.
        if raw is None or all(c is None for c in raw):
            continue
        row = {}
        for i, h in enumerate(headers):
            row[h] = raw[i] if i < len(raw) and raw[i] is not None else ""
        rows.append(row)
    wb.close()
    return headers, rows
