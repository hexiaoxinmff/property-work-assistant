"""The reconciliation engine: a key-based set diff plus per-cell comparison.

Deterministic and dependency-free. Given two tables and a key, it classifies
every row as added, removed, changed (with the exact cells that differ), or
unchanged, and surfaces columns that exist in only one of the two files.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from datetime import date, datetime


@dataclass
class CellChange:
    column: str
    old: object
    new: object


@dataclass
class Change:
    key: tuple
    cells: list[CellChange]
    old: dict
    new: dict


@dataclass
class ReconcileResult:
    keys: list[str]
    compared_columns: list[str]
    added: list[dict] = field(default_factory=list)
    removed: list[dict] = field(default_factory=list)
    changed: list[Change] = field(default_factory=list)
    unchanged_count: int = 0
    columns_added: list[str] = field(default_factory=list)
    columns_removed: list[str] = field(default_factory=list)

    @property
    def identical(self) -> bool:
        return not (self.added or self.removed or self.changed
                    or self.columns_added or self.columns_removed)

    @property
    def cell_change_count(self) -> int:
        return sum(len(c.cells) for c in self.changed)

    def summary(self) -> dict:
        return {
            "keys": self.keys,
            "added": len(self.added),
            "removed": len(self.removed),
            "changed": len(self.changed),
            "cell_changes": self.cell_change_count,
            "unchanged": self.unchanged_count,
            "columns_added": self.columns_added,
            "columns_removed": self.columns_removed,
            "identical": self.identical,
        }


def _normalize(value, *, trim: bool, ignore_case: bool) -> str:
    """Render a value to a canonical string so equivalent values compare equal.

    Notably, an Excel 1000.0 and a CSV "1000" must reconcile as the same value,
    and a Python date must match its ISO text form.
    """
    if value is None:
        s = ""
    elif isinstance(value, bool):
        s = str(value)
    elif isinstance(value, float) and value.is_integer():
        s = str(int(value))
    elif isinstance(value, datetime):
        # Drop a midnight time component so dates and datetimes align.
        s = value.date().isoformat() if value.time() == datetime.min.time() else value.isoformat()
    elif isinstance(value, date):
        s = value.isoformat()
    else:
        s = str(value)
    if trim:
        s = s.strip()
    if ignore_case:
        s = s.lower()
    return s


def _index(rows: list[dict], keys: list[str], *, trim: bool, ignore_case: bool,
           side: str) -> dict[tuple, dict]:
    index: dict[tuple, dict] = {}
    dups: list[tuple] = []
    for row in rows:
        ktuple = tuple(_normalize(row.get(k), trim=trim, ignore_case=ignore_case) for k in keys)
        if ktuple in index:
            dups.append(ktuple)
        index[ktuple] = row
    if dups:
        shown = ", ".join("|".join(d) for d in dups[:10])
        raise ValueError(
            f"Duplicate key(s) in the {side} file ({len(dups)} found); a key must be "
            f"unique to reconcile. Examples: {shown}"
        )
    return index


def reconcile(headers_a, rows_a, headers_b, rows_b, keys, *,
              ignore=(), trim: bool = True, ignore_case: bool = False) -> ReconcileResult:
    """Compare table A (old) against table B (new) on `keys`."""
    keys = list(keys)
    ignore = set(ignore)

    missing_a = [k for k in keys if k not in headers_a]
    missing_b = [k for k in keys if k not in headers_b]
    if missing_a or missing_b:
        where = []
        if missing_a:
            where.append(f"old file missing {missing_a}")
        if missing_b:
            where.append(f"new file missing {missing_b}")
        raise ValueError("Key column(s) not found: " + "; ".join(where))

    columns_added = [c for c in headers_b if c not in headers_a]
    columns_removed = [c for c in headers_a if c not in headers_b]
    compared = [c for c in headers_a
                if c in headers_b and c not in keys and c not in ignore]

    idx_a = _index(rows_a, keys, trim=trim, ignore_case=ignore_case, side="old")
    idx_b = _index(rows_b, keys, trim=trim, ignore_case=ignore_case, side="new")

    result = ReconcileResult(keys=keys, compared_columns=compared,
                             columns_added=columns_added, columns_removed=columns_removed)

    for k, row in idx_b.items():
        if k not in idx_a:
            result.added.append(row)
    for k, row in idx_a.items():
        if k not in idx_b:
            result.removed.append(row)

    for k in idx_a.keys() & idx_b.keys():
        ra, rb = idx_a[k], idx_b[k]
        cells = []
        for col in compared:
            va, vb = ra.get(col), rb.get(col)
            if _normalize(va, trim=trim, ignore_case=ignore_case) != \
               _normalize(vb, trim=trim, ignore_case=ignore_case):
                cells.append(CellChange(column=col, old=va, new=vb))
        if cells:
            result.changed.append(Change(key=k, cells=cells, old=ra, new=rb))
        else:
            result.unchanged_count += 1

    return result
